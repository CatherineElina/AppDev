﻿namespace TH05_Catherine_Elina_0706022310009
{
    partial class Form_TH05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_TH05));
            this.lbl_Product = new System.Windows.Forms.Label();
            this.lbl_Details = new System.Windows.Forms.Label();
            this.dgvr_Product = new System.Windows.Forms.DataGridView();
            this.lbl_Category = new System.Windows.Forms.Label();
            this.dgvr_Category = new System.Windows.Forms.DataGridView();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Kategory = new System.Windows.Forms.Label();
            this.lbl_Price = new System.Windows.Forms.Label();
            this.lbl_Stock = new System.Windows.Forms.Label();
            this.tb_NamaDetail = new System.Windows.Forms.TextBox();
            this.cb_CategoryDetail = new System.Windows.Forms.ComboBox();
            this.tb_Harga = new System.Windows.Forms.TextBox();
            this.tb_Stock = new System.Windows.Forms.TextBox();
            this.btn_Addproduct = new System.Windows.Forms.Button();
            this.btn_EditProduct = new System.Windows.Forms.Button();
            this.btn_DeleteProduct = new System.Windows.Forms.Button();
            this.lbl_NameCategory = new System.Windows.Forms.Label();
            this.tb_NamaCategory = new System.Windows.Forms.TextBox();
            this.btn_AddCategory = new System.Windows.Forms.Button();
            this.btn_DeleteCategory = new System.Windows.Forms.Button();
            this.btn_All = new System.Windows.Forms.Button();
            this.btn_Filter = new System.Windows.Forms.Button();
            this.cb_Filter = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvr_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvr_Category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Product
            // 
            this.lbl_Product.AutoSize = true;
            this.lbl_Product.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product.Location = new System.Drawing.Point(34, 49);
            this.lbl_Product.Name = "lbl_Product";
            this.lbl_Product.Size = new System.Drawing.Size(95, 26);
            this.lbl_Product.TabIndex = 0;
            this.lbl_Product.Text = "Product";
            // 
            // lbl_Details
            // 
            this.lbl_Details.AutoSize = true;
            this.lbl_Details.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Details.Location = new System.Drawing.Point(34, 373);
            this.lbl_Details.Name = "lbl_Details";
            this.lbl_Details.Size = new System.Drawing.Size(83, 26);
            this.lbl_Details.TabIndex = 1;
            this.lbl_Details.Text = "Details";
            // 
            // dgvr_Product
            // 
            this.dgvr_Product.AllowUserToAddRows = false;
            this.dgvr_Product.AllowUserToDeleteRows = false;
            this.dgvr_Product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvr_Product.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvr_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvr_Product.Location = new System.Drawing.Point(39, 87);
            this.dgvr_Product.Name = "dgvr_Product";
            this.dgvr_Product.ReadOnly = true;
            this.dgvr_Product.RowHeadersWidth = 62;
            this.dgvr_Product.RowTemplate.Height = 28;
            this.dgvr_Product.Size = new System.Drawing.Size(581, 271);
            this.dgvr_Product.TabIndex = 2;
            this.dgvr_Product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvr_Product_CellClick);
            // 
            // lbl_Category
            // 
            this.lbl_Category.AutoSize = true;
            this.lbl_Category.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category.Location = new System.Drawing.Point(680, 49);
            this.lbl_Category.Name = "lbl_Category";
            this.lbl_Category.Size = new System.Drawing.Size(107, 26);
            this.lbl_Category.TabIndex = 3;
            this.lbl_Category.Text = "Category";
            // 
            // dgvr_Category
            // 
            this.dgvr_Category.AllowUserToAddRows = false;
            this.dgvr_Category.AllowUserToDeleteRows = false;
            this.dgvr_Category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvr_Category.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvr_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvr_Category.Location = new System.Drawing.Point(685, 87);
            this.dgvr_Category.Name = "dgvr_Category";
            this.dgvr_Category.ReadOnly = true;
            this.dgvr_Category.RowHeadersWidth = 62;
            this.dgvr_Category.RowTemplate.Height = 28;
            this.dgvr_Category.Size = new System.Drawing.Size(300, 232);
            this.dgvr_Category.TabIndex = 4;
            this.dgvr_Category.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvr_Category_CellMouseClick);
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Location = new System.Drawing.Point(35, 429);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(55, 20);
            this.lbl_Name.TabIndex = 5;
            this.lbl_Name.Text = "Name:";
            // 
            // lbl_Kategory
            // 
            this.lbl_Kategory.AutoSize = true;
            this.lbl_Kategory.Location = new System.Drawing.Point(35, 481);
            this.lbl_Kategory.Name = "lbl_Kategory";
            this.lbl_Kategory.Size = new System.Drawing.Size(77, 20);
            this.lbl_Kategory.TabIndex = 6;
            this.lbl_Kategory.Text = "Category:";
            // 
            // lbl_Price
            // 
            this.lbl_Price.AutoSize = true;
            this.lbl_Price.Location = new System.Drawing.Point(35, 536);
            this.lbl_Price.Name = "lbl_Price";
            this.lbl_Price.Size = new System.Drawing.Size(48, 20);
            this.lbl_Price.TabIndex = 7;
            this.lbl_Price.Text = "Price:";
            // 
            // lbl_Stock
            // 
            this.lbl_Stock.AutoSize = true;
            this.lbl_Stock.Location = new System.Drawing.Point(35, 596);
            this.lbl_Stock.Name = "lbl_Stock";
            this.lbl_Stock.Size = new System.Drawing.Size(54, 20);
            this.lbl_Stock.TabIndex = 8;
            this.lbl_Stock.Text = "Stock:";
            // 
            // tb_NamaDetail
            // 
            this.tb_NamaDetail.Location = new System.Drawing.Point(137, 429);
            this.tb_NamaDetail.Name = "tb_NamaDetail";
            this.tb_NamaDetail.Size = new System.Drawing.Size(483, 26);
            this.tb_NamaDetail.TabIndex = 9;
            // 
            // cb_CategoryDetail
            // 
            this.cb_CategoryDetail.FormattingEnabled = true;
            this.cb_CategoryDetail.Location = new System.Drawing.Point(137, 478);
            this.cb_CategoryDetail.Name = "cb_CategoryDetail";
            this.cb_CategoryDetail.Size = new System.Drawing.Size(150, 28);
            this.cb_CategoryDetail.TabIndex = 10;
            // 
            // tb_Harga
            // 
            this.tb_Harga.Location = new System.Drawing.Point(137, 536);
            this.tb_Harga.Name = "tb_Harga";
            this.tb_Harga.Size = new System.Drawing.Size(150, 26);
            this.tb_Harga.TabIndex = 11;
            this.tb_Harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Harga_KeyPress);
            // 
            // tb_Stock
            // 
            this.tb_Stock.Location = new System.Drawing.Point(137, 590);
            this.tb_Stock.Name = "tb_Stock";
            this.tb_Stock.Size = new System.Drawing.Size(150, 26);
            this.tb_Stock.TabIndex = 12;
            this.tb_Stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Stock_KeyPress);
            // 
            // btn_Addproduct
            // 
            this.btn_Addproduct.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_Addproduct.Location = new System.Drawing.Point(308, 514);
            this.btn_Addproduct.Name = "btn_Addproduct";
            this.btn_Addproduct.Size = new System.Drawing.Size(100, 64);
            this.btn_Addproduct.TabIndex = 13;
            this.btn_Addproduct.Text = "Add Product";
            this.btn_Addproduct.UseVisualStyleBackColor = false;
            this.btn_Addproduct.Click += new System.EventHandler(this.btn_Addproduct_Click);
            // 
            // btn_EditProduct
            // 
            this.btn_EditProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_EditProduct.Location = new System.Drawing.Point(414, 514);
            this.btn_EditProduct.Name = "btn_EditProduct";
            this.btn_EditProduct.Size = new System.Drawing.Size(100, 64);
            this.btn_EditProduct.TabIndex = 14;
            this.btn_EditProduct.Text = "Edit Product";
            this.btn_EditProduct.UseVisualStyleBackColor = false;
            this.btn_EditProduct.Click += new System.EventHandler(this.btn_EditProduct_Click);
            // 
            // btn_DeleteProduct
            // 
            this.btn_DeleteProduct.BackColor = System.Drawing.Color.Crimson;
            this.btn_DeleteProduct.Location = new System.Drawing.Point(520, 514);
            this.btn_DeleteProduct.Name = "btn_DeleteProduct";
            this.btn_DeleteProduct.Size = new System.Drawing.Size(100, 64);
            this.btn_DeleteProduct.TabIndex = 15;
            this.btn_DeleteProduct.Text = "Delete Product";
            this.btn_DeleteProduct.UseVisualStyleBackColor = false;
            this.btn_DeleteProduct.Click += new System.EventHandler(this.btn_DeleteProduct_Click);
            // 
            // lbl_NameCategory
            // 
            this.lbl_NameCategory.AutoSize = true;
            this.lbl_NameCategory.Location = new System.Drawing.Point(681, 338);
            this.lbl_NameCategory.Name = "lbl_NameCategory";
            this.lbl_NameCategory.Size = new System.Drawing.Size(59, 20);
            this.lbl_NameCategory.TabIndex = 16;
            this.lbl_NameCategory.Text = "Name: ";
            // 
            // tb_NamaCategory
            // 
            this.tb_NamaCategory.Location = new System.Drawing.Point(746, 335);
            this.tb_NamaCategory.Name = "tb_NamaCategory";
            this.tb_NamaCategory.Size = new System.Drawing.Size(239, 26);
            this.tb_NamaCategory.TabIndex = 17;
            // 
            // btn_AddCategory
            // 
            this.btn_AddCategory.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_AddCategory.Location = new System.Drawing.Point(779, 385);
            this.btn_AddCategory.Name = "btn_AddCategory";
            this.btn_AddCategory.Size = new System.Drawing.Size(100, 64);
            this.btn_AddCategory.TabIndex = 18;
            this.btn_AddCategory.Text = "Add Category";
            this.btn_AddCategory.UseVisualStyleBackColor = false;
            this.btn_AddCategory.Click += new System.EventHandler(this.btn_AddCategory_Click);
            // 
            // btn_DeleteCategory
            // 
            this.btn_DeleteCategory.BackColor = System.Drawing.Color.Crimson;
            this.btn_DeleteCategory.Location = new System.Drawing.Point(885, 385);
            this.btn_DeleteCategory.Name = "btn_DeleteCategory";
            this.btn_DeleteCategory.Size = new System.Drawing.Size(100, 64);
            this.btn_DeleteCategory.TabIndex = 19;
            this.btn_DeleteCategory.Text = "Delete Category";
            this.btn_DeleteCategory.UseVisualStyleBackColor = false;
            this.btn_DeleteCategory.Click += new System.EventHandler(this.btn_DeleteCategory_Click);
            // 
            // btn_All
            // 
            this.btn_All.Location = new System.Drawing.Point(321, 54);
            this.btn_All.Name = "btn_All";
            this.btn_All.Size = new System.Drawing.Size(76, 33);
            this.btn_All.TabIndex = 20;
            this.btn_All.Text = "All";
            this.btn_All.UseVisualStyleBackColor = true;
            this.btn_All.Click += new System.EventHandler(this.btn_All_Click);
            // 
            // btn_Filter
            // 
            this.btn_Filter.Location = new System.Drawing.Point(403, 54);
            this.btn_Filter.Name = "btn_Filter";
            this.btn_Filter.Size = new System.Drawing.Size(76, 33);
            this.btn_Filter.TabIndex = 21;
            this.btn_Filter.Text = "Filter";
            this.btn_Filter.UseVisualStyleBackColor = true;
            this.btn_Filter.Click += new System.EventHandler(this.btn_Filter_Click);
            // 
            // cb_Filter
            // 
            this.cb_Filter.FormattingEnabled = true;
            this.cb_Filter.Location = new System.Drawing.Point(485, 54);
            this.cb_Filter.Name = "cb_Filter";
            this.cb_Filter.Size = new System.Drawing.Size(135, 28);
            this.cb_Filter.TabIndex = 22;
            this.cb_Filter.SelectionChangeCommitted += new System.EventHandler(this.cb_Filter_SelectionChangeCommitted);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(685, 455);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(232, 177);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(680, 635);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(304, 25);
            this.label1.TabIndex = 24;
            this.label1.Text = "Ce, Pleasee jangan pelit nilai :(";
            // 
            // Form_TH05
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSalmon;
            this.ClientSize = new System.Drawing.Size(1040, 719);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.cb_Filter);
            this.Controls.Add(this.btn_Filter);
            this.Controls.Add(this.btn_All);
            this.Controls.Add(this.btn_DeleteCategory);
            this.Controls.Add(this.btn_AddCategory);
            this.Controls.Add(this.tb_NamaCategory);
            this.Controls.Add(this.lbl_NameCategory);
            this.Controls.Add(this.btn_DeleteProduct);
            this.Controls.Add(this.btn_EditProduct);
            this.Controls.Add(this.btn_Addproduct);
            this.Controls.Add(this.tb_Stock);
            this.Controls.Add(this.tb_Harga);
            this.Controls.Add(this.cb_CategoryDetail);
            this.Controls.Add(this.tb_NamaDetail);
            this.Controls.Add(this.lbl_Stock);
            this.Controls.Add(this.lbl_Price);
            this.Controls.Add(this.lbl_Kategory);
            this.Controls.Add(this.lbl_Name);
            this.Controls.Add(this.dgvr_Category);
            this.Controls.Add(this.lbl_Category);
            this.Controls.Add(this.dgvr_Product);
            this.Controls.Add(this.lbl_Details);
            this.Controls.Add(this.lbl_Product);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Form_TH05";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form_TH05_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvr_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvr_Category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Product;
        private System.Windows.Forms.Label lbl_Details;
        private System.Windows.Forms.DataGridView dgvr_Product;
        private System.Windows.Forms.Label lbl_Category;
        private System.Windows.Forms.DataGridView dgvr_Category;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Kategory;
        private System.Windows.Forms.Label lbl_Price;
        private System.Windows.Forms.Label lbl_Stock;
        private System.Windows.Forms.TextBox tb_NamaDetail;
        private System.Windows.Forms.ComboBox cb_CategoryDetail;
        private System.Windows.Forms.TextBox tb_Harga;
        private System.Windows.Forms.TextBox tb_Stock;
        private System.Windows.Forms.Button btn_Addproduct;
        private System.Windows.Forms.Button btn_EditProduct;
        private System.Windows.Forms.Button btn_DeleteProduct;
        private System.Windows.Forms.Label lbl_NameCategory;
        private System.Windows.Forms.TextBox tb_NamaCategory;
        private System.Windows.Forms.Button btn_AddCategory;
        private System.Windows.Forms.Button btn_DeleteCategory;
        private System.Windows.Forms.Button btn_All;
        private System.Windows.Forms.Button btn_Filter;
        private System.Windows.Forms.ComboBox cb_Filter;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}

