﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05_Catherine_Elina_0706022310009
{
    public partial class Form_TH05 : Form
    {
        public Form_TH05()
        {
            InitializeComponent();
        }
        private DataTable dtKategori = new DataTable();
        private DataTable dtKategoriDisimpan = new DataTable();
        private DataTable dtProdukDisimpan = new DataTable();
        private DataTable dtProdukShow = new DataTable();
        private DataColumn column = new DataColumn();
        private DataRow row;
        private List<string> IDProduk = new List<string>() { "J001", "J002", "T001", "T002", "R001", "R002", "C001", "C002" };
        private List<string> listNamaProduk = new List<string>() { "Jas Hitam", "Jeans Biru", "T-Shirt Black Pink", "T-Shirt Obsessive", "Rok mini", "Rocca Shirt", "Celana Pendek Coklat", "Cawat Blink-blink" };
        private List<string> Harga = new List<string>() { "100000", "70000", "75000", "82000", "90000", "60000", "50000", "550000" };
        private List<int> Stock = new List<int>() { 10, 20, 30, 5, 11, 17, 8, 12 };
        private List<string> IDKategoriProduk = new List<string>() { "C1", "C4", "C2", "C2", "C3", "C2", "C4", "C5" };
        private List<string> IDKategori = new List<string>() { "C1", "C2", "C3", "C4", "C5" };
        private List<string> NamaKategori = new List<string>() { "Jas", "T-Shirt", "Rok", "Celana", "Cawat" };
        private string categorys = "";
        private string IDs = "";
        private void Form_TH05_Load(object sender, EventArgs e)
        {
            cb_Filter.Enabled = false;
            column = new DataColumn();
            column.ColumnName = "ID Product";
            dtProdukDisimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "Product Name";
            dtProdukDisimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "Price";
            dtProdukDisimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "Stock";
            dtProdukDisimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "ID Category";
            dtProdukDisimpan.Columns.Add(column);

            for (int i = 0; i < IDProduk.Count; i++)
            {
                row = dtProdukDisimpan.NewRow();
                row[0] = IDProduk[i];
                row[1] = listNamaProduk[i];
                row[2] = Harga[i];
                row[3] = Stock[i];
                row[4] = IDKategoriProduk[i];
                dtProdukDisimpan.Rows.Add(row);
            }

            column = new DataColumn();
            column.ColumnName = "ID Category";
            dtKategoriDisimpan.Columns.Add(column);
            column = new DataColumn();
            column.ColumnName = "Category Name";
            dtKategoriDisimpan.Columns.Add(column);

            for (int i = 0; i < IDKategori.Count; i++)
            {
                row = dtKategoriDisimpan.NewRow();
                row[0] = IDKategori[i];
                row[1] = NamaKategori[i];
                dtKategoriDisimpan.Rows.Add(row);
            }

            dtProdukShow = dtProdukDisimpan.Copy();
            dgvr_Product.DataSource = dtProdukShow;
            dgvr_Category.DataSource = dtKategoriDisimpan;
            cb_Filter.DataSource = dtKategoriDisimpan.Copy();
            cb_Filter.DisplayMember = "Category Name";
            cb_Filter.ValueMember = "ID Category";
            cb_CategoryDetail.DataSource = dtKategoriDisimpan.Copy();
            cb_CategoryDetail.DisplayMember = "Category Name";
            cb_CategoryDetail.ValueMember = "ID Category";


        }

        private void btn_Addproduct_Click(object sender, EventArgs e)
        {
            if (tb_NamaDetail.Text == "" || tb_Harga.Text == "" || tb_Stock.Text == "")
            {
                MessageBox.Show("Tolong diinput ya :)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (cb_CategoryDetail.SelectedValue == null || cb_CategoryDetail.Text == "")
            {
                MessageBox.Show("Tolong dipilih categorynya ya :)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string NamaProduk = new string(tb_NamaDetail.Text.ToString().ToUpper()[0], 1);
                int count = 0;
                foreach (DataRow row in (InternalDataCollectionBase)dtProdukDisimpan.Rows)
                {
                    if (row[0].ToString()[0].ToString() == NamaProduk)
                    {
                        int counts = Convert.ToInt32(row[0].ToString().Substring(1));
                        if (count <= counts)
                        {
                            count = counts;
                        }
                    }
                }

                int angka = count + 1;
                string NProduks = NamaProduk.ToString();
                for (int i = angka.ToString().Length; i < 3; i++)
                {
                    NProduks += "0";
                }
                string NProdukID = NProduks + angka.ToString();

                row = dtProdukDisimpan.NewRow();
                row[0] = NProdukID;
                row[1] = tb_NamaDetail.Text;
                row[2] = tb_Harga.Text;
                row[3] = tb_Stock.Text;
                row[4] = cb_CategoryDetail.SelectedValue;
                dtProdukDisimpan.Rows.Add(row);
                Filter("");
            }

        }

        private void btn_EditProduct_Click(object sender, EventArgs e)
        {
            if (IDs != "")
            {
                if (tb_NamaDetail.Text == "" || tb_Harga.Text == "" || tb_Stock.Text == "")
                {
                    MessageBox.Show("Tolong diinput ya :)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (cb_CategoryDetail.SelectedValue == null || cb_CategoryDetail.Text == "")
                {
                    MessageBox.Show("Tolong diinput kategorinya :)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    foreach (DataRow row in (InternalDataCollectionBase)dtProdukDisimpan.Rows)
                    {
                        if (row[0].ToString() == IDs)
                        {
                            row[1] = tb_NamaDetail.Text;
                            row[2] = tb_Harga.Text;
                            row[3] = tb_Stock.Text;
                            row[4] = cb_CategoryDetail.SelectedValue;
                            if (row[3].ToString() == "0")
                            {
                                dtProdukDisimpan.Rows.Remove(row);
                                break;
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Silahkan select produk yang mau di edit", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            Filter("");
        }

        private void btn_DeleteProduct_Click(object sender, EventArgs e)
        {
            foreach (DataRow row in (InternalDataCollectionBase)dtProdukDisimpan.Rows)
            {
                if (row[0].ToString() == IDs)
                {
                    dtProdukDisimpan.Rows.Remove(row);
                    break;
                }
            }
            Filter("");
        }

        private void btn_AddCategory_Click(object sender, EventArgs e)
        {
            if (tb_NamaCategory.Text == "")
            {
                MessageBox.Show("Tolong diisi kategorinya", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool kluar = true;
                foreach (DataRow row in (InternalDataCollectionBase)dtKategoriDisimpan.Rows)
                {
                    if (tb_NamaCategory.Text == row[1].ToString())
                    {
                        kluar = false;
                    }
                }
                if (!kluar)
                {
                    MessageBox.Show("Kategori sudah ada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    int count = 0;
                    foreach (DataRow row in (InternalDataCollectionBase)dtKategoriDisimpan.Rows)
                    {
                        int counts = Convert.ToInt32(row[0].ToString().Substring(1));
                        if (count <= counts)
                        {
                            count = counts;
                        }
                    }
                    string Kode = "C" + (count + 1).ToString();
                    row = dtKategoriDisimpan.NewRow();
                    row[0] = Kode;
                    row[1] = tb_NamaCategory.Text;
                    dtKategoriDisimpan.Rows.Add(row);
                    Filter("");
                }
            }
        }

        private void btn_DeleteCategory_Click(object sender, EventArgs e)
        {
            foreach (DataRow row in (InternalDataCollectionBase)dtKategoriDisimpan.Rows)
            {
                if (row[0].ToString() == categorys)
                {
                    dtKategoriDisimpan.Rows.Remove(row);
                    break;
                }
            }
            for (int i = dtKategoriDisimpan.Rows.Count - 1; i >= 0; i--)
            {
                if (dtProdukDisimpan.Rows[i]["ID Category"] == categorys)
                {
                    dtProdukDisimpan.Rows.Remove(dtProdukDisimpan.Rows[i]);
                }
            }
            Filter("");
        }

        private void btn_All_Click(object sender, EventArgs e)
        {
            cb_Filter.Enabled = false;
            Filter("");
            dgvr_Category.CurrentCell = (DataGridViewCell)null;
            dgvr_Product.CurrentCell = (DataGridViewCell)null;
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            cb_Filter.Enabled = true;
        }

        public void Filter(string klik)
        {
            if (klik != "")
            {
                dtProdukShow.Rows.Clear();
                for (int i = 0; i < dtProdukDisimpan.Rows.Count; i++)
                {
                    if (dtProdukDisimpan.Rows[i][4].ToString() == klik)
                    {
                        row = dtProdukShow.NewRow();
                        row[0] = dtProdukDisimpan.Rows[i][0];
                        row[1] = dtProdukDisimpan.Rows[i][1];
                        row[2] = dtProdukDisimpan.Rows[i][2];
                        row[3] = dtProdukDisimpan.Rows[i][3];
                        row[4] = dtProdukDisimpan.Rows[i][4];
                        dtProdukShow.Rows.Add(row);
                    }
                }
            }
            else
            {
                dtProdukShow.Rows.Clear();
                for (int i = 0; i < dtProdukDisimpan.Rows.Count; i++)
                {
                    row = dtProdukShow.NewRow();
                    row[0] = dtProdukDisimpan.Rows[i][0];
                    row[1] = dtProdukDisimpan.Rows[i][1];
                    row[2] = dtProdukDisimpan.Rows[i][2];
                    row[3] = dtProdukDisimpan.Rows[i][3];
                    row[4] = dtProdukDisimpan.Rows[i][4];
                    dtProdukShow.Rows.Add(row);
                }
            }
            dgvr_Category.CurrentCell = (DataGridViewCell)null;
            dgvr_Product.CurrentCell = (DataGridViewCell)null;
            tb_NamaDetail.Clear();
            tb_Harga.Clear();
            tb_Stock.Clear();
            categorys = "";
            IDs = "";
            cb_CategoryDetail.DataSource = dtKategoriDisimpan.Copy();
            cb_Filter.DataSource = dtKategoriDisimpan.Copy();
            cb_CategoryDetail.Text = "";
            cb_Filter.Text = "";
            tb_NamaCategory.Text = "";
        }

        private void cb_Filter_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Filter(cb_Filter.SelectedValue.ToString());
        }

        private void dgvr_Category_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                categorys = dgvr_Category.Rows[e.RowIndex].Cells[0].Value.ToString();
                tb_NamaCategory.Text = dgvr_Category.Rows[e.RowIndex].Cells[1].Value.ToString();
            }
        }

        private void dgvr_Product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                IDs = dgvr_Product.Rows[e.RowIndex].Cells[0].Value.ToString();
                tb_NamaDetail.Text = dgvr_Product.Rows[e.RowIndex].Cells[1].Value.ToString();
                tb_Harga.Text = dgvr_Product.Rows[e.RowIndex].Cells[2].Value.ToString();
                tb_Stock.Text = dgvr_Product.Rows[e.RowIndex].Cells[3].Value.ToString();
                string categoryValue = dgvr_Product.Rows[e.RowIndex].Cells[4].Value.ToString();
                cb_CategoryDetail.SelectedValue = (object)categoryValue;

                if (cb_CategoryDetail.Text == string.Empty && cb_CategoryDetail.Items.Count > 0)
                {
                    foreach (DataRow row in (InternalDataCollectionBase)dtKategoriDisimpan.Rows)
                    {
                        if (row[0].ToString() == categoryValue)
                            cb_CategoryDetail.Text = row[1].ToString();
                    }
                }
            }
            else
            {
                IDs = string.Empty;
                tb_NamaDetail.Clear();
                tb_Harga.Clear();
                tb_Stock.Clear();
                cb_CategoryDetail.SelectedIndex = -1;
            }
        }

        private void tb_Harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar) || e.KeyChar == '.')
            {
                return;
            }
            e.Handled = true;
        }

        private void tb_Stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar) || e.KeyChar == '.')
            {
                return;
            }
            e.Handled = true;
        }
    }
    
    
}
