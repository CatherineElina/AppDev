﻿namespace TH03_Catherine_Elina_0706022310009
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_UCBank = new System.Windows.Forms.Label();
            this.label_Username = new System.Windows.Forms.Label();
            this.label_Password = new System.Windows.Forms.Label();
            this.tb_Username = new System.Windows.Forms.TextBox();
            this.tb_Password = new System.Windows.Forms.TextBox();
            this.btn_Login = new System.Windows.Forms.Button();
            this.btn_Register = new System.Windows.Forms.Button();
            this.panel_01 = new System.Windows.Forms.Panel();
            this.panel_02 = new System.Windows.Forms.Panel();
            this.label_Uang = new System.Windows.Forms.Label();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.label_Balance = new System.Windows.Forms.Label();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.panel_03 = new System.Windows.Forms.Panel();
            this.btn_DepoInDepo = new System.Windows.Forms.Button();
            this.tb_Deposit = new System.Windows.Forms.TextBox();
            this.label_InputDepo = new System.Windows.Forms.Label();
            this.panel_04 = new System.Windows.Forms.Panel();
            this.label_UangInWithdraw = new System.Windows.Forms.Label();
            this.label_BalanceInWithdraw = new System.Windows.Forms.Label();
            this.btn_WdInWd = new System.Windows.Forms.Button();
            this.tb_Withdraw = new System.Windows.Forms.TextBox();
            this.label_InputWithdraw = new System.Windows.Forms.Label();
            this.btn_RegisInRegis = new System.Windows.Forms.Button();
            this.lbl_Username = new System.Windows.Forms.Label();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.tb_Password1 = new System.Windows.Forms.TextBox();
            this.tb_Username1 = new System.Windows.Forms.TextBox();
            this.panel_05 = new System.Windows.Forms.Panel();
            this.panel_01.SuspendLayout();
            this.panel_02.SuspendLayout();
            this.panel_03.SuspendLayout();
            this.panel_04.SuspendLayout();
            this.panel_05.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_UCBank
            // 
            this.label_UCBank.AutoSize = true;
            this.label_UCBank.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_UCBank.Location = new System.Drawing.Point(54, 30);
            this.label_UCBank.Name = "label_UCBank";
            this.label_UCBank.Size = new System.Drawing.Size(144, 32);
            this.label_UCBank.TabIndex = 0;
            this.label_UCBank.Text = "UC BANK";
            // 
            // label_Username
            // 
            this.label_Username.AutoSize = true;
            this.label_Username.Location = new System.Drawing.Point(19, 27);
            this.label_Username.Name = "label_Username";
            this.label_Username.Size = new System.Drawing.Size(87, 20);
            this.label_Username.TabIndex = 1;
            this.label_Username.Text = "Username:";
            // 
            // label_Password
            // 
            this.label_Password.AutoSize = true;
            this.label_Password.Location = new System.Drawing.Point(19, 75);
            this.label_Password.Name = "label_Password";
            this.label_Password.Size = new System.Drawing.Size(86, 20);
            this.label_Password.TabIndex = 2;
            this.label_Password.Text = "Password: ";
            // 
            // tb_Username
            // 
            this.tb_Username.Location = new System.Drawing.Point(119, 21);
            this.tb_Username.Name = "tb_Username";
            this.tb_Username.Size = new System.Drawing.Size(100, 26);
            this.tb_Username.TabIndex = 3;
            // 
            // tb_Password
            // 
            this.tb_Password.Location = new System.Drawing.Point(119, 75);
            this.tb_Password.Name = "tb_Password";
            this.tb_Password.Size = new System.Drawing.Size(100, 26);
            this.tb_Password.TabIndex = 4;
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(119, 185);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(100, 32);
            this.btn_Login.TabIndex = 5;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // btn_Register
            // 
            this.btn_Register.Location = new System.Drawing.Point(119, 131);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(101, 33);
            this.btn_Register.TabIndex = 6;
            this.btn_Register.Text = "Register";
            this.btn_Register.UseVisualStyleBackColor = true;
            this.btn_Register.Click += new System.EventHandler(this.btn_Register_Click);
            // 
            // panel_01
            // 
            this.panel_01.Controls.Add(this.btn_Login);
            this.panel_01.Controls.Add(this.btn_Register);
            this.panel_01.Controls.Add(this.label_Username);
            this.panel_01.Controls.Add(this.label_Password);
            this.panel_01.Controls.Add(this.tb_Password);
            this.panel_01.Controls.Add(this.tb_Username);
            this.panel_01.Location = new System.Drawing.Point(12, 95);
            this.panel_01.Name = "panel_01";
            this.panel_01.Size = new System.Drawing.Size(265, 249);
            this.panel_01.TabIndex = 7;
            // 
            // panel_02
            // 
            this.panel_02.Controls.Add(this.label_Uang);
            this.panel_02.Controls.Add(this.btn_Withdraw);
            this.panel_02.Controls.Add(this.btn_Deposit);
            this.panel_02.Controls.Add(this.label_Balance);
            this.panel_02.Location = new System.Drawing.Point(0, 6);
            this.panel_02.Name = "panel_02";
            this.panel_02.Size = new System.Drawing.Size(276, 196);
            this.panel_02.TabIndex = 8;
            // 
            // label_Uang
            // 
            this.label_Uang.AutoSize = true;
            this.label_Uang.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Uang.Location = new System.Drawing.Point(104, 27);
            this.label_Uang.Name = "label_Uang";
            this.label_Uang.Size = new System.Drawing.Size(68, 22);
            this.label_Uang.TabIndex = 8;
            this.label_Uang.Text = "Rp0,00";
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(89, 131);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(100, 32);
            this.btn_Withdraw.TabIndex = 7;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(88, 77);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(101, 33);
            this.btn_Deposit.TabIndex = 7;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // label_Balance
            // 
            this.label_Balance.AutoSize = true;
            this.label_Balance.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Balance.Location = new System.Drawing.Point(16, 27);
            this.label_Balance.Name = "label_Balance";
            this.label_Balance.Size = new System.Drawing.Size(82, 25);
            this.label_Balance.TabIndex = 7;
            this.label_Balance.Text = "Balance";
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(224, 30);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(101, 33);
            this.btn_LogOut.TabIndex = 9;
            this.btn_LogOut.Text = "Logout";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // panel_03
            // 
            this.panel_03.Controls.Add(this.btn_DepoInDepo);
            this.panel_03.Controls.Add(this.tb_Deposit);
            this.panel_03.Controls.Add(this.label_InputDepo);
            this.panel_03.Location = new System.Drawing.Point(12, 92);
            this.panel_03.Name = "panel_03";
            this.panel_03.Size = new System.Drawing.Size(265, 143);
            this.panel_03.TabIndex = 9;
            // 
            // btn_DepoInDepo
            // 
            this.btn_DepoInDepo.Location = new System.Drawing.Point(85, 98);
            this.btn_DepoInDepo.Name = "btn_DepoInDepo";
            this.btn_DepoInDepo.Size = new System.Drawing.Size(101, 33);
            this.btn_DepoInDepo.TabIndex = 9;
            this.btn_DepoInDepo.Text = "Deposit";
            this.btn_DepoInDepo.UseVisualStyleBackColor = true;
            this.btn_DepoInDepo.Click += new System.EventHandler(this.btn_DepoInDepo_Click);
            // 
            // tb_Deposit
            // 
            this.tb_Deposit.Location = new System.Drawing.Point(86, 51);
            this.tb_Deposit.Name = "tb_Deposit";
            this.tb_Deposit.Size = new System.Drawing.Size(100, 26);
            this.tb_Deposit.TabIndex = 8;
            // 
            // label_InputDepo
            // 
            this.label_InputDepo.AutoSize = true;
            this.label_InputDepo.Location = new System.Drawing.Point(51, 14);
            this.label_InputDepo.Name = "label_InputDepo";
            this.label_InputDepo.Size = new System.Drawing.Size(169, 20);
            this.label_InputDepo.TabIndex = 7;
            this.label_InputDepo.Text = "Input Deposit Amount:";
            // 
            // panel_04
            // 
            this.panel_04.Controls.Add(this.label_UangInWithdraw);
            this.panel_04.Controls.Add(this.label_BalanceInWithdraw);
            this.panel_04.Controls.Add(this.btn_WdInWd);
            this.panel_04.Controls.Add(this.tb_Withdraw);
            this.panel_04.Controls.Add(this.panel_02);
            this.panel_04.Controls.Add(this.label_InputWithdraw);
            this.panel_04.Location = new System.Drawing.Point(12, 89);
            this.panel_04.Name = "panel_04";
            this.panel_04.Size = new System.Drawing.Size(276, 185);
            this.panel_04.TabIndex = 10;
            // 
            // label_UangInWithdraw
            // 
            this.label_UangInWithdraw.AutoSize = true;
            this.label_UangInWithdraw.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_UangInWithdraw.Location = new System.Drawing.Point(106, 17);
            this.label_UangInWithdraw.Name = "label_UangInWithdraw";
            this.label_UangInWithdraw.Size = new System.Drawing.Size(68, 22);
            this.label_UangInWithdraw.TabIndex = 9;
            this.label_UangInWithdraw.Text = "Rp0,00";
            // 
            // label_BalanceInWithdraw
            // 
            this.label_BalanceInWithdraw.AutoSize = true;
            this.label_BalanceInWithdraw.Font = new System.Drawing.Font("Times New Roman", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_BalanceInWithdraw.Location = new System.Drawing.Point(18, 17);
            this.label_BalanceInWithdraw.Name = "label_BalanceInWithdraw";
            this.label_BalanceInWithdraw.Size = new System.Drawing.Size(82, 25);
            this.label_BalanceInWithdraw.TabIndex = 9;
            this.label_BalanceInWithdraw.Text = "Balance";
            // 
            // btn_WdInWd
            // 
            this.btn_WdInWd.Location = new System.Drawing.Point(94, 141);
            this.btn_WdInWd.Name = "btn_WdInWd";
            this.btn_WdInWd.Size = new System.Drawing.Size(101, 33);
            this.btn_WdInWd.TabIndex = 9;
            this.btn_WdInWd.Text = "Withdraw";
            this.btn_WdInWd.UseVisualStyleBackColor = true;
            this.btn_WdInWd.Click += new System.EventHandler(this.btn_WdInWd_Click);
            // 
            // tb_Withdraw
            // 
            this.tb_Withdraw.Location = new System.Drawing.Point(95, 94);
            this.tb_Withdraw.Name = "tb_Withdraw";
            this.tb_Withdraw.Size = new System.Drawing.Size(100, 26);
            this.tb_Withdraw.TabIndex = 8;
            // 
            // label_InputWithdraw
            // 
            this.label_InputWithdraw.AutoSize = true;
            this.label_InputWithdraw.Location = new System.Drawing.Point(60, 57);
            this.label_InputWithdraw.Name = "label_InputWithdraw";
            this.label_InputWithdraw.Size = new System.Drawing.Size(180, 20);
            this.label_InputWithdraw.TabIndex = 7;
            this.label_InputWithdraw.Text = "Input Withdraw Amount:";
            // 
            // btn_RegisInRegis
            // 
            this.btn_RegisInRegis.Location = new System.Drawing.Point(118, 125);
            this.btn_RegisInRegis.Name = "btn_RegisInRegis";
            this.btn_RegisInRegis.Size = new System.Drawing.Size(101, 33);
            this.btn_RegisInRegis.TabIndex = 12;
            this.btn_RegisInRegis.Text = "Register";
            this.btn_RegisInRegis.UseVisualStyleBackColor = true;
            this.btn_RegisInRegis.Click += new System.EventHandler(this.btn_RegisInRegis_Click);
            // 
            // lbl_Username
            // 
            this.lbl_Username.AutoSize = true;
            this.lbl_Username.Location = new System.Drawing.Point(18, 21);
            this.lbl_Username.Name = "lbl_Username";
            this.lbl_Username.Size = new System.Drawing.Size(87, 20);
            this.lbl_Username.TabIndex = 7;
            this.lbl_Username.Text = "Username:";
            // 
            // lbl_Password
            // 
            this.lbl_Password.AutoSize = true;
            this.lbl_Password.Location = new System.Drawing.Point(18, 69);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.Size = new System.Drawing.Size(86, 20);
            this.lbl_Password.TabIndex = 8;
            this.lbl_Password.Text = "Password: ";
            // 
            // tb_Password1
            // 
            this.tb_Password1.Location = new System.Drawing.Point(118, 69);
            this.tb_Password1.Name = "tb_Password1";
            this.tb_Password1.Size = new System.Drawing.Size(100, 26);
            this.tb_Password1.TabIndex = 10;
            // 
            // tb_Username1
            // 
            this.tb_Username1.Location = new System.Drawing.Point(118, 15);
            this.tb_Username1.Name = "tb_Username1";
            this.tb_Username1.Size = new System.Drawing.Size(100, 26);
            this.tb_Username1.TabIndex = 9;
            // 
            // panel_05
            // 
            this.panel_05.Controls.Add(this.tb_Username1);
            this.panel_05.Controls.Add(this.btn_RegisInRegis);
            this.panel_05.Controls.Add(this.tb_Password1);
            this.panel_05.Controls.Add(this.lbl_Password);
            this.panel_05.Controls.Add(this.lbl_Username);
            this.panel_05.Location = new System.Drawing.Point(12, 95);
            this.panel_05.Name = "panel_05";
            this.panel_05.Size = new System.Drawing.Size(276, 196);
            this.panel_05.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 527);
            this.Controls.Add(this.panel_05);
            this.Controls.Add(this.panel_04);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.panel_03);
            this.Controls.Add(this.label_UCBank);
            this.Controls.Add(this.panel_01);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_01.ResumeLayout(false);
            this.panel_01.PerformLayout();
            this.panel_02.ResumeLayout(false);
            this.panel_02.PerformLayout();
            this.panel_03.ResumeLayout(false);
            this.panel_03.PerformLayout();
            this.panel_04.ResumeLayout(false);
            this.panel_04.PerformLayout();
            this.panel_05.ResumeLayout(false);
            this.panel_05.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_UCBank;
        private System.Windows.Forms.Label label_Username;
        private System.Windows.Forms.Label label_Password;
        private System.Windows.Forms.TextBox tb_Username;
        private System.Windows.Forms.TextBox tb_Password;
        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.Button btn_Register;
        private System.Windows.Forms.Panel panel_01;
        private System.Windows.Forms.Panel panel_02;
        private System.Windows.Forms.Label label_Balance;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Label label_Uang;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Panel panel_03;
        private System.Windows.Forms.Label label_InputDepo;
        private System.Windows.Forms.Button btn_DepoInDepo;
        private System.Windows.Forms.TextBox tb_Deposit;
        private System.Windows.Forms.Panel panel_04;
        private System.Windows.Forms.Button btn_WdInWd;
        private System.Windows.Forms.TextBox tb_Withdraw;
        private System.Windows.Forms.Label label_InputWithdraw;
        private System.Windows.Forms.Label label_UangInWithdraw;
        private System.Windows.Forms.Label label_BalanceInWithdraw;
        private System.Windows.Forms.Button btn_RegisInRegis;
        private System.Windows.Forms.Label lbl_Username;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.TextBox tb_Password1;
        private System.Windows.Forms.TextBox tb_Username1;
        private System.Windows.Forms.Panel panel_05;
    }
}

