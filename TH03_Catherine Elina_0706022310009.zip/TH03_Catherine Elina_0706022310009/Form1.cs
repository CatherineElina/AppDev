﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_Catherine_Elina_0706022310009
{
    public partial class Form1 : Form
    {
        List<string> Usernames = new List<string>();
        List<string> Passwords = new List<string>();
        List<int> Balances = new List<int>();

        public int index;
        
        public Form1()
        {
            InitializeComponent();
            panel_02.Visible = false;
            panel_03.Visible = false;
            panel_04.Visible = false;
            panel_05.Visible = false;
            btn_LogOut.Visible = false;
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            panel_05.Visible = true;
            panel_01.Visible = false;
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            string username = tb_Username.Text;
            string password = tb_Password.Text;
            index = Usernames.IndexOf(username);
            if (index != -1 && Passwords[index] == password)
            {
                MessageBox.Show("Login Successful!");
                panel_01.Visible = false;
                panel_02.Visible = true;
                btn_LogOut.Visible = true;
                label_Uang.Text = String.Format("Rp. {0:N}" , Balances[index]);
            }
            else
            {
                MessageBox.Show("Invalid usernames or password");
            }

        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            panel_02.Visible = false;
            panel_03.Visible = true;
        }

        private void btn_DepoInDepo_Click(object sender, EventArgs e)
        {
            int depositAmount = 0;
            
            if (int.TryParse(tb_Deposit.Text, out depositAmount))
            {
                if (depositAmount > 0)
                {
                    int index = Usernames.IndexOf(tb_Username.Text);
                    Balances[index] += depositAmount;
                    
                    MessageBox.Show("Deposit Successful!");
                    panel_03.Visible = false;
                    panel_02.Visible = true;
                    label_Uang.Text = String.Format("Rp. {0:N}", Balances[index]);
                }
                else
                {
                    MessageBox.Show("Unable to deposit the amount due to the amount is less than or equal to 0");
                }
            }
            else
            {
                MessageBox.Show("Invalid deposit amount");
            }
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            int index = Usernames.IndexOf(tb_Username.Text);
            
            if (index != -1)
            {
                panel_02.Visible = false;
                panel_04.Visible = true;
                label_Uang.Text = String.Format("Rp. {0:N}", Balances[index]);
            }
            else
            {
                MessageBox.Show("Invalid user");
            }
        }

        private void btn_WdInWd_Click(object sender, EventArgs e)
        {
            int withdrawAmount = 0;
            if (int.TryParse(tb_Withdraw.Text, out withdrawAmount))
            {
                if (withdrawAmount > 0 && withdrawAmount <= Balances[Usernames.IndexOf(tb_Username.Text)])
                {
                    int index = Usernames.IndexOf(tb_Username.Text);
                    Balances[index] -= withdrawAmount;
                    MessageBox.Show("Withdrawal Successful!");
                    panel_04.Visible = false;
                    panel_02.Visible = true;
                    label_Uang.Text = String.Format("Rp. {0:N}", Balances[index]);
                }
                else
                {
                    MessageBox.Show("Unable to process withdrawal. Insufficient balance or invalid amount.");
                }
            }
            else
            {
                MessageBox.Show("Invalid withdrawal amount.");
            }
        }

        private void btn_RegisInRegis_Click(object sender, EventArgs e)
        {
            string username = tb_Username1.Text;
            string password = tb_Password1.Text;

            if (Usernames.Contains(username))
            {
                MessageBox.Show("Username already exists! Please choose a different one.");
            }
            else
            {
                Usernames.Add(username);
                Passwords.Add(password);
                Balances.Add(0);
                MessageBox.Show("Registration Successful!");
                panel_05.Visible = false;
                panel_01.Visible = true;
            }
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            tb_Username.Clear();
            tb_Password.Clear();
            tb_Deposit.Clear();
            tb_Withdraw.Clear();
            tb_Username1.Clear();
            tb_Password1.Clear();
            panel_01.Visible = true;
            panel_02.Visible = false;
            panel_03.Visible = false;
            panel_04.Visible = false;
            panel_05.Visible = false;
            btn_LogOut.Visible = false;
        }
    }
}
