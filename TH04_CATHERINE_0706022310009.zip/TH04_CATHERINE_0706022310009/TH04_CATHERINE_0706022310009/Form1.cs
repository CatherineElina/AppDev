﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH04_CATHERINE_0706022310009
{
    public partial class Form1 : Form
    {
        private List<Team> teams;
        public Form1()
        {
            InitializeComponent();
            lBox_Name.Items.Clear();
            cBox_PlayerPosition.Items.AddRange(new[] { "GK", "DF", "MF", "FW" });
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            NamePlayers();
            ComboBoxCountry();
        }

        private void NamePlayers()
        {
            teams = new List<Team>();
            teams.Add(new Team
            {
                City = "Manchester",
                Country = "England",
                TeamName = "Manchester United",
                Players = new List<Player>
                {
                    new Player { Name = "David De Gea", Number = "01", Position = "GK" },
                    new Player { Name = "Victor Lindelof", Number = "02", Position = "DF" },
                    new Player { Name = "Phil Jones", Number = "04", Position = "DF" },
                    new Player { Name = "Harry Maguire", Number = "05", Position = "DF" },
                    new Player { Name = "Lisandro Martinez", Number = "06", Position = "DF" },
                    new Player { Name = "Bruno Fernandez", Number = "08", Position = "MF" },
                    new Player { Name = "Anthony Martial", Number = "09", Position = "FW" },
                    new Player { Name = "Marcus Rashford", Number = "10", Position = "FW" },
                    new Player { Name = "Tyrell Malacia", Number = "12", Position = "DF" },
                    new Player { Name = "Christian Eriksen", Number = "14", Position = "MF" },
                    new Player { Name = "Casemiro", Number = "18", Position = "MF" },
                }
            });
            teams.Add(new Team
            {
                City = "Fulham",
                Country = "England",
                TeamName = "Chelsea",
                Players = new List<Player>
                {
                    new Player { Name = "Kepa Arrizabalaga", Number = "01", Position = "GK" },
                    new Player { Name = "Benoît Badiashile", Number = "04", Position = "DF" },
                    new Player { Name = "Enzo Fernández", Number = "05", Position = "MF" },
                    new Player { Name = "Thiago Silva", Number = "06", Position = "DF" },
                    new Player { Name = "N'Golo Kanté", Number = "07", Position = "MF" },
                    new Player { Name = "Mateo Kovačić", Number = "08", Position = "MF" },
                    new Player { Name = "Pierre-Emerick Aubameyang", Number = "09", Position = "FW" },
                    new Player { Name = "Christian Pulisic", Number = "10", Position = "MF" },
                    new Player { Name = "João Félix", Number = "11", Position = "FW" },
                    new Player { Name = "Ruben Loftus-Cheek", Number = "12", Position = "MF" },
                    new Player { Name = "Raheem Sterling", Number = "17", Position = "MF" },
                }
            });
            teams.Add(new Team
            {
                City = "Munich",
                Country = "Germany",
                TeamName = "Bayern Munich",
                Players = new List<Player>
                {
                    new Player { Name = "Manuel Neuer", Number = "01", Position = "GK" },
                    new Player { Name = "Benjamin Pavard", Number = "05", Position = "DF" },
                    new Player { Name = "Dayot Upamecano", Number = "14", Position = "DF" },
                    new Player { Name = "Lucas Hernandez", Number = "21", Position = "DF" },
                    new Player { Name = "Alphonso Davies", Number = "19", Position = "DF" },
                    new Player { Name = "Joshua Kimmich", Number = "06", Position = "MF" },
                    new Player { Name = "Leon Goretzka", Number = "08", Position = "MF" },
                    new Player { Name = "Thomas Müller", Number = "25", Position = "MF" },
                    new Player { Name = "Leroy Sane", Number = "10", Position = "FW" },
                    new Player { Name = "Serge Gnabry", Number = "07", Position = "FW" },
                    new Player { Name = "Robert Lewandowski", Number = "09", Position = "FW" }
                }
            });
        }
        private void ComboBoxCountry()
        {
            cBox_ChoosenCountry.Items.Clear();
            var countries = teams.Select(t => t.Country).Distinct().ToList();
            foreach (var country in countries)
            {
                cBox_ChoosenCountry.Items.Add(country);
            }
        }

        private void cBox_ChoosenCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            cBox_ChoosenTeam.Items.Clear();

            if (cBox_ChoosenCountry.SelectedItem != null)
            {
                var country = cBox_ChoosenCountry.SelectedItem.ToString();
                var teamsInCountry = teams.Where(t => t.Country == country).ToList();

                foreach (var team in teamsInCountry)
                {
                    cBox_ChoosenTeam.Items.Add(team.TeamName);
                }
            }

        }

        private void cBox_ChoosenTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplayPlayers();
        }
        private void DisplayPlayers()
        {

            if (cBox_ChoosenTeam.SelectedItem != null)
            {
                lBox_Name.Items.Clear();
                var teamName = cBox_ChoosenTeam.SelectedItem.ToString();
                var team = teams.FirstOrDefault(t => t.TeamName == teamName);

                if (team != null)
                {
                    foreach (var player in team.Players)
                    {
                        lBox_Name.Items.Add($"{player.Number}). {player.Name} - {player.Position}");
                    }
                }
            }
        }
        private void AddTeam()
        {
            if (string.IsNullOrEmpty(tBox_TeamCountry.Text) || string.IsNullOrEmpty(tBox_TeamCity.Text) || string.IsNullOrEmpty(tBox_TeamName.Text))
            {
                MessageBox.Show("Please fill in all the fields to add a new team.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var teamName = tBox_TeamName.Text;
            var team = teams.FirstOrDefault(t => t.TeamName == teamName);

            if (team != null)
            {
                MessageBox.Show("A team with the same name already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            teams.Add(new Team
            {
                Country = tBox_TeamCountry.Text,
                City = tBox_TeamCity.Text,
                TeamName = tBox_TeamName.Text,
                Players = new List<Player>()
            });
            teams = teams.OrderBy(t => t.Country).ToList();
            ComboBoxTeam();
            ComboBoxCountry();
            ClearTeamFields();
        }
        private void ComboBoxTeam()
        {
            cBox_ChoosenTeam.Items.Clear();

            if (cBox_ChoosenCountry.SelectedItem != null)
            {
                var country = cBox_ChoosenCountry.SelectedItem.ToString();
                var teamsInCountry = teams.Where(t => t.Country == country).ToList();

                foreach (var team in teamsInCountry)
                {
                    cBox_ChoosenTeam.Items.Add(team.TeamName);
                }
            }
        }
        private void ClearTeamFields()
        {
            tBox_TeamCountry.Clear();
            tBox_TeamCity.Clear();
            tBox_TeamName.Clear();
        }

        private void btn_AddTeam_Click(object sender, EventArgs e)
        {
            AddTeam();
        }
        private void AddPlayer()
        {
            if (string.IsNullOrEmpty(tBox_PlayerName.Text) || string.IsNullOrEmpty(tBox_PlayerNumber.Text) || string.IsNullOrEmpty(cBox_PlayerPosition.Text) || cBox_ChoosenTeam.SelectedItem == null)
            {
                MessageBox.Show("Please fill in all the fields to add a new player.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var team = teams.FirstOrDefault(t => t.TeamName == cBox_ChoosenTeam.SelectedItem.ToString());

            if (team == null)
            {
                MessageBox.Show("Please select a team to add a player to.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var player = team.Players.FirstOrDefault(p => p.Number == tBox_PlayerNumber.Text);

            if (player != null)
            {
                MessageBox.Show("A player with the same number already exists on this team.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            team.Players.Add(new Player { Name = tBox_PlayerName.Text, Number = tBox_PlayerNumber.Text, Position = cBox_PlayerPosition.SelectedItem.ToString() });
            team.Players = team.Players.OrderBy(p => p.Number).ToList();
            DisplayPlayers();
            ClearPlayerFields();
        }
        private void ClearPlayerFields()
        {
            tBox_PlayerName.Clear();
            tBox_PlayerNumber.Clear();
            cBox_PlayerPosition.SelectedIndex = -1;
        }
        private void btn_AddPlayers_Click(object sender, EventArgs e)
        {
            AddPlayer();
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (cBox_ChoosenTeam.SelectedItem == null || lBox_Name.SelectedItem == null)
            {
                MessageBox.Show("Please select a team and a player to remove.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var teamName = cBox_ChoosenTeam.SelectedItem.ToString();
            var team = teams.FirstOrDefault(t => t.TeamName == teamName);
            if (team == null)
            {
                MessageBox.Show("Please select a valid team to remove a player from.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var selectedPlayer = lBox_Name.SelectedItem.ToString();
            var playerName = "";
            string[] split = selectedPlayer.ToString().Split(' ');
            for (int i = 1; i<split.Length-2; i++)
            {
                playerName += split[i];
                if(i < split.Length - 3)
                {
                    playerName += " ";
                }
            }
            var playerNumber = selectedPlayer.Split(' ')[0].Substring(0,2);

            var playerToRemove = team.Players.FirstOrDefault(p => p.Number == playerNumber && p.Name == playerName);
            if (playerToRemove == null)
            {
                MessageBox.Show("Please select a valid player to remove.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (team.Players.Count <= 11)
            {
                MessageBox.Show("You cannot remove a player when the total number of players in a team is less than 11.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            team.Players.Remove(playerToRemove);

            DisplayPlayers();
        }
    }
}