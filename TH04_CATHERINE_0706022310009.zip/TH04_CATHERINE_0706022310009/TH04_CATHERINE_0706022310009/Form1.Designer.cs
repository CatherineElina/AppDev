﻿namespace TH04_CATHERINE_0706022310009
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_SoccerTeamList = new System.Windows.Forms.Label();
            this.lbl_ChoosenCountry = new System.Windows.Forms.Label();
            this.lbl_ChoosenTeam = new System.Windows.Forms.Label();
            this.cBox_ChoosenCountry = new System.Windows.Forms.ComboBox();
            this.cBox_ChoosenTeam = new System.Windows.Forms.ComboBox();
            this.lBox_Name = new System.Windows.Forms.ListBox();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.lbl_AddingTeam = new System.Windows.Forms.Label();
            this.lbl_TeamName = new System.Windows.Forms.Label();
            this.lbl_TeamCountry = new System.Windows.Forms.Label();
            this.lbl_TeamCity = new System.Windows.Forms.Label();
            this.btn_AddTeam = new System.Windows.Forms.Button();
            this.btn_AddPlayers = new System.Windows.Forms.Button();
            this.cBox_PlayerPosition = new System.Windows.Forms.ComboBox();
            this.lbl_PlayerPosition = new System.Windows.Forms.Label();
            this.lbl_PlayerNumber = new System.Windows.Forms.Label();
            this.lbl_PlayerName = new System.Windows.Forms.Label();
            this.lbl_AddingPlayer = new System.Windows.Forms.Label();
            this.tBox_PlayerNumber = new System.Windows.Forms.TextBox();
            this.tBox_PlayerName = new System.Windows.Forms.TextBox();
            this.tBox_TeamCity = new System.Windows.Forms.TextBox();
            this.tBox_TeamCountry = new System.Windows.Forms.TextBox();
            this.tBox_TeamName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_SoccerTeamList
            // 
            this.lbl_SoccerTeamList.AutoSize = true;
            this.lbl_SoccerTeamList.Location = new System.Drawing.Point(12, 35);
            this.lbl_SoccerTeamList.Name = "lbl_SoccerTeamList";
            this.lbl_SoccerTeamList.Size = new System.Drawing.Size(132, 20);
            this.lbl_SoccerTeamList.TabIndex = 0;
            this.lbl_SoccerTeamList.Text = "Soccer Team List";
            // 
            // lbl_ChoosenCountry
            // 
            this.lbl_ChoosenCountry.AutoSize = true;
            this.lbl_ChoosenCountry.Location = new System.Drawing.Point(12, 85);
            this.lbl_ChoosenCountry.Name = "lbl_ChoosenCountry";
            this.lbl_ChoosenCountry.Size = new System.Drawing.Size(136, 20);
            this.lbl_ChoosenCountry.TabIndex = 1;
            this.lbl_ChoosenCountry.Text = "Choosen Country:";
            // 
            // lbl_ChoosenTeam
            // 
            this.lbl_ChoosenTeam.AutoSize = true;
            this.lbl_ChoosenTeam.Location = new System.Drawing.Point(12, 138);
            this.lbl_ChoosenTeam.Name = "lbl_ChoosenTeam";
            this.lbl_ChoosenTeam.Size = new System.Drawing.Size(125, 20);
            this.lbl_ChoosenTeam.TabIndex = 2;
            this.lbl_ChoosenTeam.Text = "Choosen Team: ";
            // 
            // cBox_ChoosenCountry
            // 
            this.cBox_ChoosenCountry.FormattingEnabled = true;
            this.cBox_ChoosenCountry.Location = new System.Drawing.Point(165, 77);
            this.cBox_ChoosenCountry.Name = "cBox_ChoosenCountry";
            this.cBox_ChoosenCountry.Size = new System.Drawing.Size(149, 28);
            this.cBox_ChoosenCountry.TabIndex = 3;
            this.cBox_ChoosenCountry.SelectedIndexChanged += new System.EventHandler(this.cBox_ChoosenCountry_SelectedIndexChanged);
            // 
            // cBox_ChoosenTeam
            // 
            this.cBox_ChoosenTeam.FormattingEnabled = true;
            this.cBox_ChoosenTeam.Location = new System.Drawing.Point(165, 130);
            this.cBox_ChoosenTeam.Name = "cBox_ChoosenTeam";
            this.cBox_ChoosenTeam.Size = new System.Drawing.Size(149, 28);
            this.cBox_ChoosenTeam.TabIndex = 4;
            this.cBox_ChoosenTeam.SelectedIndexChanged += new System.EventHandler(this.cBox_ChoosenTeam_SelectedIndexChanged);
            // 
            // lBox_Name
            // 
            this.lBox_Name.FormattingEnabled = true;
            this.lBox_Name.ItemHeight = 20;
            this.lBox_Name.Location = new System.Drawing.Point(16, 193);
            this.lBox_Name.Name = "lBox_Name";
            this.lBox_Name.Size = new System.Drawing.Size(298, 184);
            this.lBox_Name.TabIndex = 5;
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(16, 392);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(98, 45);
            this.btn_Remove.TabIndex = 6;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // lbl_AddingTeam
            // 
            this.lbl_AddingTeam.AutoSize = true;
            this.lbl_AddingTeam.Location = new System.Drawing.Point(338, 35);
            this.lbl_AddingTeam.Name = "lbl_AddingTeam";
            this.lbl_AddingTeam.Size = new System.Drawing.Size(103, 20);
            this.lbl_AddingTeam.TabIndex = 7;
            this.lbl_AddingTeam.Text = "Adding Team";
            // 
            // lbl_TeamName
            // 
            this.lbl_TeamName.AutoSize = true;
            this.lbl_TeamName.Location = new System.Drawing.Point(338, 85);
            this.lbl_TeamName.Name = "lbl_TeamName";
            this.lbl_TeamName.Size = new System.Drawing.Size(103, 20);
            this.lbl_TeamName.TabIndex = 8;
            this.lbl_TeamName.Text = "Team Name: ";
            // 
            // lbl_TeamCountry
            // 
            this.lbl_TeamCountry.AutoSize = true;
            this.lbl_TeamCountry.Location = new System.Drawing.Point(338, 138);
            this.lbl_TeamCountry.Name = "lbl_TeamCountry";
            this.lbl_TeamCountry.Size = new System.Drawing.Size(116, 20);
            this.lbl_TeamCountry.TabIndex = 9;
            this.lbl_TeamCountry.Text = "Team Country: ";
            // 
            // lbl_TeamCity
            // 
            this.lbl_TeamCity.AutoSize = true;
            this.lbl_TeamCity.Location = new System.Drawing.Point(338, 188);
            this.lbl_TeamCity.Name = "lbl_TeamCity";
            this.lbl_TeamCity.Size = new System.Drawing.Size(87, 20);
            this.lbl_TeamCity.TabIndex = 12;
            this.lbl_TeamCity.Text = "Team City: ";
            // 
            // btn_AddTeam
            // 
            this.btn_AddTeam.Location = new System.Drawing.Point(460, 225);
            this.btn_AddTeam.Name = "btn_AddTeam";
            this.btn_AddTeam.Size = new System.Drawing.Size(75, 29);
            this.btn_AddTeam.TabIndex = 14;
            this.btn_AddTeam.Text = "Add";
            this.btn_AddTeam.UseVisualStyleBackColor = true;
            this.btn_AddTeam.Click += new System.EventHandler(this.btn_AddTeam_Click);
            // 
            // btn_AddPlayers
            // 
            this.btn_AddPlayers.Location = new System.Drawing.Point(782, 225);
            this.btn_AddPlayers.Name = "btn_AddPlayers";
            this.btn_AddPlayers.Size = new System.Drawing.Size(75, 29);
            this.btn_AddPlayers.TabIndex = 22;
            this.btn_AddPlayers.Text = "Add";
            this.btn_AddPlayers.UseVisualStyleBackColor = true;
            this.btn_AddPlayers.Click += new System.EventHandler(this.btn_AddPlayers_Click);
            // 
            // cBox_PlayerPosition
            // 
            this.cBox_PlayerPosition.FormattingEnabled = true;
            this.cBox_PlayerPosition.Location = new System.Drawing.Point(782, 180);
            this.cBox_PlayerPosition.Name = "cBox_PlayerPosition";
            this.cBox_PlayerPosition.Size = new System.Drawing.Size(149, 28);
            this.cBox_PlayerPosition.TabIndex = 21;
            // 
            // lbl_PlayerPosition
            // 
            this.lbl_PlayerPosition.AutoSize = true;
            this.lbl_PlayerPosition.Location = new System.Drawing.Point(660, 188);
            this.lbl_PlayerPosition.Name = "lbl_PlayerPosition";
            this.lbl_PlayerPosition.Size = new System.Drawing.Size(120, 20);
            this.lbl_PlayerPosition.TabIndex = 20;
            this.lbl_PlayerPosition.Text = "Player Position: ";
            // 
            // lbl_PlayerNumber
            // 
            this.lbl_PlayerNumber.AutoSize = true;
            this.lbl_PlayerNumber.Location = new System.Drawing.Point(660, 138);
            this.lbl_PlayerNumber.Name = "lbl_PlayerNumber";
            this.lbl_PlayerNumber.Size = new System.Drawing.Size(120, 20);
            this.lbl_PlayerNumber.TabIndex = 17;
            this.lbl_PlayerNumber.Text = "Player Number: ";
            // 
            // lbl_PlayerName
            // 
            this.lbl_PlayerName.AutoSize = true;
            this.lbl_PlayerName.Location = new System.Drawing.Point(660, 85);
            this.lbl_PlayerName.Name = "lbl_PlayerName";
            this.lbl_PlayerName.Size = new System.Drawing.Size(106, 20);
            this.lbl_PlayerName.TabIndex = 16;
            this.lbl_PlayerName.Text = "Player Name: ";
            // 
            // lbl_AddingPlayer
            // 
            this.lbl_AddingPlayer.AutoSize = true;
            this.lbl_AddingPlayer.Location = new System.Drawing.Point(660, 35);
            this.lbl_AddingPlayer.Name = "lbl_AddingPlayer";
            this.lbl_AddingPlayer.Size = new System.Drawing.Size(114, 20);
            this.lbl_AddingPlayer.TabIndex = 15;
            this.lbl_AddingPlayer.Text = "Adding Players";
            // 
            // tBox_PlayerNumber
            // 
            this.tBox_PlayerNumber.Location = new System.Drawing.Point(782, 130);
            this.tBox_PlayerNumber.Name = "tBox_PlayerNumber";
            this.tBox_PlayerNumber.Size = new System.Drawing.Size(149, 26);
            this.tBox_PlayerNumber.TabIndex = 23;
            // 
            // tBox_PlayerName
            // 
            this.tBox_PlayerName.Location = new System.Drawing.Point(782, 82);
            this.tBox_PlayerName.Name = "tBox_PlayerName";
            this.tBox_PlayerName.Size = new System.Drawing.Size(149, 26);
            this.tBox_PlayerName.TabIndex = 24;
            // 
            // tBox_TeamCity
            // 
            this.tBox_TeamCity.Location = new System.Drawing.Point(460, 182);
            this.tBox_TeamCity.Name = "tBox_TeamCity";
            this.tBox_TeamCity.Size = new System.Drawing.Size(149, 26);
            this.tBox_TeamCity.TabIndex = 25;
            // 
            // tBox_TeamCountry
            // 
            this.tBox_TeamCountry.Location = new System.Drawing.Point(460, 135);
            this.tBox_TeamCountry.Name = "tBox_TeamCountry";
            this.tBox_TeamCountry.Size = new System.Drawing.Size(149, 26);
            this.tBox_TeamCountry.TabIndex = 26;
            // 
            // tBox_TeamName
            // 
            this.tBox_TeamName.Location = new System.Drawing.Point(460, 82);
            this.tBox_TeamName.Name = "tBox_TeamName";
            this.tBox_TeamName.Size = new System.Drawing.Size(149, 26);
            this.tBox_TeamName.TabIndex = 27;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 467);
            this.Controls.Add(this.tBox_TeamName);
            this.Controls.Add(this.tBox_TeamCountry);
            this.Controls.Add(this.tBox_TeamCity);
            this.Controls.Add(this.tBox_PlayerName);
            this.Controls.Add(this.tBox_PlayerNumber);
            this.Controls.Add(this.btn_AddPlayers);
            this.Controls.Add(this.cBox_PlayerPosition);
            this.Controls.Add(this.lbl_PlayerPosition);
            this.Controls.Add(this.lbl_PlayerNumber);
            this.Controls.Add(this.lbl_PlayerName);
            this.Controls.Add(this.lbl_AddingPlayer);
            this.Controls.Add(this.btn_AddTeam);
            this.Controls.Add(this.lbl_TeamCity);
            this.Controls.Add(this.lbl_TeamCountry);
            this.Controls.Add(this.lbl_TeamName);
            this.Controls.Add(this.lbl_AddingTeam);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.lBox_Name);
            this.Controls.Add(this.cBox_ChoosenTeam);
            this.Controls.Add(this.cBox_ChoosenCountry);
            this.Controls.Add(this.lbl_ChoosenTeam);
            this.Controls.Add(this.lbl_ChoosenCountry);
            this.Controls.Add(this.lbl_SoccerTeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_SoccerTeamList;
        private System.Windows.Forms.Label lbl_ChoosenCountry;
        private System.Windows.Forms.Label lbl_ChoosenTeam;
        private System.Windows.Forms.ComboBox cBox_ChoosenCountry;
        private System.Windows.Forms.ComboBox cBox_ChoosenTeam;
        private System.Windows.Forms.ListBox lBox_Name;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.Label lbl_AddingTeam;
        private System.Windows.Forms.Label lbl_TeamName;
        private System.Windows.Forms.Label lbl_TeamCountry;
        private System.Windows.Forms.Label lbl_TeamCity;
        private System.Windows.Forms.Button btn_AddTeam;
        private System.Windows.Forms.Button btn_AddPlayers;
        private System.Windows.Forms.ComboBox cBox_PlayerPosition;
        private System.Windows.Forms.Label lbl_PlayerPosition;
        private System.Windows.Forms.Label lbl_PlayerNumber;
        private System.Windows.Forms.Label lbl_PlayerName;
        private System.Windows.Forms.Label lbl_AddingPlayer;
        private System.Windows.Forms.TextBox tBox_PlayerNumber;
        private System.Windows.Forms.TextBox tBox_PlayerName;
        private System.Windows.Forms.TextBox tBox_TeamCity;
        private System.Windows.Forms.TextBox tBox_TeamCountry;
        private System.Windows.Forms.TextBox tBox_TeamName;
    }
}

