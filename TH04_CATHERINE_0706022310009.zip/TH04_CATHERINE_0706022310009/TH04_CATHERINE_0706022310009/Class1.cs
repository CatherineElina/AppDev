﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TH04_CATHERINE_0706022310009
{

    public class Player
    {
        public string Name { get; set; }
        public string Number { get; set; }
        public string Position { get; set; }
    }
    public class Team
    {
        public string TeamName { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public List<Player> Players { get; set; }
    }
}
