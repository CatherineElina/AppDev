﻿namespace TH01_Catherine_Elina
{
    partial class form_01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_word01 = new System.Windows.Forms.Label();
            this.lb_word02 = new System.Windows.Forms.Label();
            this.lb_word03 = new System.Windows.Forms.Label();
            this.lb_word04 = new System.Windows.Forms.Label();
            this.lb_word05 = new System.Windows.Forms.Label();
            this.tb_01 = new System.Windows.Forms.TextBox();
            this.tb_04 = new System.Windows.Forms.TextBox();
            this.tb_05 = new System.Windows.Forms.TextBox();
            this.tb_03 = new System.Windows.Forms.TextBox();
            this.tb_02 = new System.Windows.Forms.TextBox();
            this.panel_01 = new System.Windows.Forms.Panel();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_keyQ = new System.Windows.Forms.Button();
            this.btn_keyW = new System.Windows.Forms.Button();
            this.btn_keyR = new System.Windows.Forms.Button();
            this.btn_keyE = new System.Windows.Forms.Button();
            this.btn_keyY = new System.Windows.Forms.Button();
            this.btn_keyT = new System.Windows.Forms.Button();
            this.btn_keyI = new System.Windows.Forms.Button();
            this.btn_keyU = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btn_keyO = new System.Windows.Forms.Button();
            this.btn_keyL = new System.Windows.Forms.Button();
            this.btn_keyK = new System.Windows.Forms.Button();
            this.btn_keyJ = new System.Windows.Forms.Button();
            this.btn_keyH = new System.Windows.Forms.Button();
            this.btn_keyG = new System.Windows.Forms.Button();
            this.btn_keyF = new System.Windows.Forms.Button();
            this.btn_keyD = new System.Windows.Forms.Button();
            this.btn_keyS = new System.Windows.Forms.Button();
            this.btn_keyA = new System.Windows.Forms.Button();
            this.btn_keyM = new System.Windows.Forms.Button();
            this.btn_keyN = new System.Windows.Forms.Button();
            this.btn_keyB = new System.Windows.Forms.Button();
            this.btn_keyV = new System.Windows.Forms.Button();
            this.btn_keyC = new System.Windows.Forms.Button();
            this.btn_keyX = new System.Windows.Forms.Button();
            this.btn_keyZ = new System.Windows.Forms.Button();
            this.panel_02 = new System.Windows.Forms.Panel();
            this.lb_text = new System.Windows.Forms.Label();
            this.lb_blank05 = new System.Windows.Forms.Label();
            this.lb_blank04 = new System.Windows.Forms.Label();
            this.lb_blank03 = new System.Windows.Forms.Label();
            this.lb_blank02 = new System.Windows.Forms.Label();
            this.lb_blank01 = new System.Windows.Forms.Label();
            this.btn_keyP = new System.Windows.Forms.Button();
            this.panel_01.SuspendLayout();
            this.panel_02.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_word01
            // 
            this.lb_word01.AutoSize = true;
            this.lb_word01.Location = new System.Drawing.Point(16, 25);
            this.lb_word01.Name = "lb_word01";
            this.lb_word01.Size = new System.Drawing.Size(69, 20);
            this.lb_word01.TabIndex = 0;
            this.lb_word01.Text = "Word 01";
            // 
            // lb_word02
            // 
            this.lb_word02.AutoSize = true;
            this.lb_word02.Location = new System.Drawing.Point(16, 73);
            this.lb_word02.Name = "lb_word02";
            this.lb_word02.Size = new System.Drawing.Size(69, 20);
            this.lb_word02.TabIndex = 1;
            this.lb_word02.Text = "Word 02";
            // 
            // lb_word03
            // 
            this.lb_word03.AutoSize = true;
            this.lb_word03.Location = new System.Drawing.Point(16, 124);
            this.lb_word03.Name = "lb_word03";
            this.lb_word03.Size = new System.Drawing.Size(69, 20);
            this.lb_word03.TabIndex = 2;
            this.lb_word03.Text = "Word 03";
            // 
            // lb_word04
            // 
            this.lb_word04.AutoSize = true;
            this.lb_word04.Location = new System.Drawing.Point(16, 171);
            this.lb_word04.Name = "lb_word04";
            this.lb_word04.Size = new System.Drawing.Size(69, 20);
            this.lb_word04.TabIndex = 4;
            this.lb_word04.Text = "Word 04";
            // 
            // lb_word05
            // 
            this.lb_word05.AutoSize = true;
            this.lb_word05.Location = new System.Drawing.Point(16, 219);
            this.lb_word05.Name = "lb_word05";
            this.lb_word05.Size = new System.Drawing.Size(69, 20);
            this.lb_word05.TabIndex = 3;
            this.lb_word05.Text = "Word 05";
            // 
            // tb_01
            // 
            this.tb_01.Location = new System.Drawing.Point(101, 19);
            this.tb_01.Name = "tb_01";
            this.tb_01.Size = new System.Drawing.Size(100, 26);
            this.tb_01.TabIndex = 5;
            // 
            // tb_04
            // 
            this.tb_04.Location = new System.Drawing.Point(101, 165);
            this.tb_04.Name = "tb_04";
            this.tb_04.Size = new System.Drawing.Size(100, 26);
            this.tb_04.TabIndex = 6;
            // 
            // tb_05
            // 
            this.tb_05.Location = new System.Drawing.Point(101, 213);
            this.tb_05.Name = "tb_05";
            this.tb_05.Size = new System.Drawing.Size(100, 26);
            this.tb_05.TabIndex = 7;
            // 
            // tb_03
            // 
            this.tb_03.Location = new System.Drawing.Point(101, 118);
            this.tb_03.Name = "tb_03";
            this.tb_03.Size = new System.Drawing.Size(100, 26);
            this.tb_03.TabIndex = 8;
            // 
            // tb_02
            // 
            this.tb_02.Location = new System.Drawing.Point(101, 67);
            this.tb_02.Name = "tb_02";
            this.tb_02.Size = new System.Drawing.Size(100, 26);
            this.tb_02.TabIndex = 9;
            // 
            // panel_01
            // 
            this.panel_01.Controls.Add(this.btn_next);
            this.panel_01.Controls.Add(this.tb_05);
            this.panel_01.Controls.Add(this.tb_02);
            this.panel_01.Controls.Add(this.tb_04);
            this.panel_01.Controls.Add(this.lb_word03);
            this.panel_01.Controls.Add(this.lb_word01);
            this.panel_01.Controls.Add(this.lb_word05);
            this.panel_01.Controls.Add(this.lb_word04);
            this.panel_01.Controls.Add(this.lb_word02);
            this.panel_01.Controls.Add(this.tb_03);
            this.panel_01.Controls.Add(this.tb_01);
            this.panel_01.Location = new System.Drawing.Point(24, 12);
            this.panel_01.Name = "panel_01";
            this.panel_01.Size = new System.Drawing.Size(336, 268);
            this.panel_01.TabIndex = 10;
            // 
            // btn_next
            // 
            this.btn_next.Location = new System.Drawing.Point(240, 124);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(75, 32);
            this.btn_next.TabIndex = 10;
            this.btn_next.Text = "Next";
            this.btn_next.UseVisualStyleBackColor = true;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_keyQ
            // 
            this.btn_keyQ.Location = new System.Drawing.Point(13, 162);
            this.btn_keyQ.Name = "btn_keyQ";
            this.btn_keyQ.Size = new System.Drawing.Size(63, 42);
            this.btn_keyQ.TabIndex = 11;
            this.btn_keyQ.Text = "Q";
            this.btn_keyQ.UseVisualStyleBackColor = true;
            this.btn_keyQ.Click += new System.EventHandler(this.btn_keyQ_Click);
            // 
            // btn_keyW
            // 
            this.btn_keyW.Location = new System.Drawing.Point(84, 162);
            this.btn_keyW.Name = "btn_keyW";
            this.btn_keyW.Size = new System.Drawing.Size(63, 42);
            this.btn_keyW.TabIndex = 12;
            this.btn_keyW.Text = "W";
            this.btn_keyW.UseVisualStyleBackColor = true;
            this.btn_keyW.Click += new System.EventHandler(this.btn_keyW_Click);
            // 
            // btn_keyR
            // 
            this.btn_keyR.Location = new System.Drawing.Point(223, 162);
            this.btn_keyR.Name = "btn_keyR";
            this.btn_keyR.Size = new System.Drawing.Size(63, 42);
            this.btn_keyR.TabIndex = 14;
            this.btn_keyR.Text = "R";
            this.btn_keyR.UseVisualStyleBackColor = true;
            this.btn_keyR.Click += new System.EventHandler(this.btn_keyR_Click);
            // 
            // btn_keyE
            // 
            this.btn_keyE.Location = new System.Drawing.Point(152, 162);
            this.btn_keyE.Name = "btn_keyE";
            this.btn_keyE.Size = new System.Drawing.Size(63, 42);
            this.btn_keyE.TabIndex = 13;
            this.btn_keyE.Text = "E";
            this.btn_keyE.UseVisualStyleBackColor = true;
            this.btn_keyE.Click += new System.EventHandler(this.btn_keyE_Click);
            // 
            // btn_keyY
            // 
            this.btn_keyY.Location = new System.Drawing.Point(366, 162);
            this.btn_keyY.Name = "btn_keyY";
            this.btn_keyY.Size = new System.Drawing.Size(63, 42);
            this.btn_keyY.TabIndex = 16;
            this.btn_keyY.Text = "Y";
            this.btn_keyY.UseVisualStyleBackColor = true;
            this.btn_keyY.Click += new System.EventHandler(this.btn_keyY_Click);
            // 
            // btn_keyT
            // 
            this.btn_keyT.Location = new System.Drawing.Point(295, 162);
            this.btn_keyT.Name = "btn_keyT";
            this.btn_keyT.Size = new System.Drawing.Size(63, 42);
            this.btn_keyT.TabIndex = 15;
            this.btn_keyT.Text = "T";
            this.btn_keyT.UseVisualStyleBackColor = true;
            this.btn_keyT.Click += new System.EventHandler(this.btn_keyT_Click);
            // 
            // btn_keyI
            // 
            this.btn_keyI.Location = new System.Drawing.Point(511, 162);
            this.btn_keyI.Name = "btn_keyI";
            this.btn_keyI.Size = new System.Drawing.Size(63, 42);
            this.btn_keyI.TabIndex = 18;
            this.btn_keyI.Text = "I";
            this.btn_keyI.UseVisualStyleBackColor = true;
            this.btn_keyI.Click += new System.EventHandler(this.btn_keyI_Click);
            // 
            // btn_keyU
            // 
            this.btn_keyU.Location = new System.Drawing.Point(440, 162);
            this.btn_keyU.Name = "btn_keyU";
            this.btn_keyU.Size = new System.Drawing.Size(63, 42);
            this.btn_keyU.TabIndex = 17;
            this.btn_keyU.Text = "U";
            this.btn_keyU.UseVisualStyleBackColor = true;
            this.btn_keyU.Click += new System.EventHandler(this.btn_keyU_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(883, 63);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(24, 27);
            this.button9.TabIndex = 20;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // btn_keyO
            // 
            this.btn_keyO.Location = new System.Drawing.Point(588, 162);
            this.btn_keyO.Name = "btn_keyO";
            this.btn_keyO.Size = new System.Drawing.Size(63, 42);
            this.btn_keyO.TabIndex = 19;
            this.btn_keyO.Text = "O";
            this.btn_keyO.UseVisualStyleBackColor = true;
            this.btn_keyO.Click += new System.EventHandler(this.btn_keyO_Click);
            // 
            // btn_keyL
            // 
            this.btn_keyL.Location = new System.Drawing.Point(603, 210);
            this.btn_keyL.Name = "btn_keyL";
            this.btn_keyL.Size = new System.Drawing.Size(63, 42);
            this.btn_keyL.TabIndex = 29;
            this.btn_keyL.Text = "L";
            this.btn_keyL.UseVisualStyleBackColor = true;
            this.btn_keyL.Click += new System.EventHandler(this.btn_keyL_Click);
            // 
            // btn_keyK
            // 
            this.btn_keyK.Location = new System.Drawing.Point(526, 210);
            this.btn_keyK.Name = "btn_keyK";
            this.btn_keyK.Size = new System.Drawing.Size(63, 42);
            this.btn_keyK.TabIndex = 28;
            this.btn_keyK.Text = "K";
            this.btn_keyK.UseVisualStyleBackColor = true;
            this.btn_keyK.Click += new System.EventHandler(this.btn_keyK_Click);
            // 
            // btn_keyJ
            // 
            this.btn_keyJ.Location = new System.Drawing.Point(457, 210);
            this.btn_keyJ.Name = "btn_keyJ";
            this.btn_keyJ.Size = new System.Drawing.Size(63, 42);
            this.btn_keyJ.TabIndex = 27;
            this.btn_keyJ.Text = "J";
            this.btn_keyJ.UseVisualStyleBackColor = true;
            this.btn_keyJ.Click += new System.EventHandler(this.btn_keyJ_Click);
            // 
            // btn_keyH
            // 
            this.btn_keyH.Location = new System.Drawing.Point(383, 210);
            this.btn_keyH.Name = "btn_keyH";
            this.btn_keyH.Size = new System.Drawing.Size(63, 42);
            this.btn_keyH.TabIndex = 26;
            this.btn_keyH.Text = "H";
            this.btn_keyH.UseVisualStyleBackColor = true;
            this.btn_keyH.Click += new System.EventHandler(this.btn_keyH_Click);
            // 
            // btn_keyG
            // 
            this.btn_keyG.Location = new System.Drawing.Point(312, 210);
            this.btn_keyG.Name = "btn_keyG";
            this.btn_keyG.Size = new System.Drawing.Size(63, 42);
            this.btn_keyG.TabIndex = 25;
            this.btn_keyG.Text = "G";
            this.btn_keyG.UseVisualStyleBackColor = true;
            this.btn_keyG.Click += new System.EventHandler(this.btn_keyG_Click);
            // 
            // btn_keyF
            // 
            this.btn_keyF.Location = new System.Drawing.Point(240, 210);
            this.btn_keyF.Name = "btn_keyF";
            this.btn_keyF.Size = new System.Drawing.Size(63, 42);
            this.btn_keyF.TabIndex = 24;
            this.btn_keyF.Text = "F";
            this.btn_keyF.UseVisualStyleBackColor = true;
            this.btn_keyF.Click += new System.EventHandler(this.btn_keyF_Click);
            // 
            // btn_keyD
            // 
            this.btn_keyD.Location = new System.Drawing.Point(169, 210);
            this.btn_keyD.Name = "btn_keyD";
            this.btn_keyD.Size = new System.Drawing.Size(63, 42);
            this.btn_keyD.TabIndex = 23;
            this.btn_keyD.Text = "D";
            this.btn_keyD.UseVisualStyleBackColor = true;
            this.btn_keyD.Click += new System.EventHandler(this.btn_keyD_Click);
            // 
            // btn_keyS
            // 
            this.btn_keyS.Location = new System.Drawing.Point(101, 210);
            this.btn_keyS.Name = "btn_keyS";
            this.btn_keyS.Size = new System.Drawing.Size(63, 42);
            this.btn_keyS.TabIndex = 22;
            this.btn_keyS.Text = "S";
            this.btn_keyS.UseVisualStyleBackColor = true;
            this.btn_keyS.Click += new System.EventHandler(this.btn_keyS_Click);
            // 
            // btn_keyA
            // 
            this.btn_keyA.Location = new System.Drawing.Point(30, 210);
            this.btn_keyA.Name = "btn_keyA";
            this.btn_keyA.Size = new System.Drawing.Size(63, 42);
            this.btn_keyA.TabIndex = 21;
            this.btn_keyA.Text = "A";
            this.btn_keyA.UseVisualStyleBackColor = true;
            this.btn_keyA.Click += new System.EventHandler(this.btn_keyA_Click);
            // 
            // btn_keyM
            // 
            this.btn_keyM.Location = new System.Drawing.Point(511, 257);
            this.btn_keyM.Name = "btn_keyM";
            this.btn_keyM.Size = new System.Drawing.Size(63, 42);
            this.btn_keyM.TabIndex = 36;
            this.btn_keyM.Text = "M";
            this.btn_keyM.UseVisualStyleBackColor = true;
            this.btn_keyM.Click += new System.EventHandler(this.btn_keyM_Click);
            // 
            // btn_keyN
            // 
            this.btn_keyN.Location = new System.Drawing.Point(442, 257);
            this.btn_keyN.Name = "btn_keyN";
            this.btn_keyN.Size = new System.Drawing.Size(63, 42);
            this.btn_keyN.TabIndex = 35;
            this.btn_keyN.Text = "N";
            this.btn_keyN.UseVisualStyleBackColor = true;
            this.btn_keyN.Click += new System.EventHandler(this.btn_keyN_Click);
            // 
            // btn_keyB
            // 
            this.btn_keyB.Location = new System.Drawing.Point(371, 257);
            this.btn_keyB.Name = "btn_keyB";
            this.btn_keyB.Size = new System.Drawing.Size(63, 42);
            this.btn_keyB.TabIndex = 34;
            this.btn_keyB.Text = "B";
            this.btn_keyB.UseVisualStyleBackColor = true;
            this.btn_keyB.Click += new System.EventHandler(this.btn_keyB_Click);
            // 
            // btn_keyV
            // 
            this.btn_keyV.Location = new System.Drawing.Point(299, 257);
            this.btn_keyV.Name = "btn_keyV";
            this.btn_keyV.Size = new System.Drawing.Size(63, 42);
            this.btn_keyV.TabIndex = 33;
            this.btn_keyV.Text = "V";
            this.btn_keyV.UseVisualStyleBackColor = true;
            this.btn_keyV.Click += new System.EventHandler(this.btn_keyV_Click);
            // 
            // btn_keyC
            // 
            this.btn_keyC.Location = new System.Drawing.Point(228, 257);
            this.btn_keyC.Name = "btn_keyC";
            this.btn_keyC.Size = new System.Drawing.Size(63, 42);
            this.btn_keyC.TabIndex = 32;
            this.btn_keyC.Text = "C";
            this.btn_keyC.UseVisualStyleBackColor = true;
            this.btn_keyC.Click += new System.EventHandler(this.btn_keyC_Click);
            // 
            // btn_keyX
            // 
            this.btn_keyX.Location = new System.Drawing.Point(160, 257);
            this.btn_keyX.Name = "btn_keyX";
            this.btn_keyX.Size = new System.Drawing.Size(63, 42);
            this.btn_keyX.TabIndex = 31;
            this.btn_keyX.Text = "X";
            this.btn_keyX.UseVisualStyleBackColor = true;
            this.btn_keyX.Click += new System.EventHandler(this.btn_keyX_Click);
            // 
            // btn_keyZ
            // 
            this.btn_keyZ.Location = new System.Drawing.Point(89, 257);
            this.btn_keyZ.Name = "btn_keyZ";
            this.btn_keyZ.Size = new System.Drawing.Size(63, 42);
            this.btn_keyZ.TabIndex = 30;
            this.btn_keyZ.Text = "Z";
            this.btn_keyZ.UseVisualStyleBackColor = true;
            this.btn_keyZ.Click += new System.EventHandler(this.btn_keyZ_Click);
            // 
            // panel_02
            // 
            this.panel_02.Controls.Add(this.lb_text);
            this.panel_02.Controls.Add(this.lb_blank05);
            this.panel_02.Controls.Add(this.lb_blank04);
            this.panel_02.Controls.Add(this.lb_blank03);
            this.panel_02.Controls.Add(this.lb_blank02);
            this.panel_02.Controls.Add(this.lb_blank01);
            this.panel_02.Controls.Add(this.btn_keyP);
            this.panel_02.Controls.Add(this.btn_keyM);
            this.panel_02.Controls.Add(this.btn_keyY);
            this.panel_02.Controls.Add(this.btn_keyI);
            this.panel_02.Controls.Add(this.btn_keyL);
            this.panel_02.Controls.Add(this.btn_keyQ);
            this.panel_02.Controls.Add(this.btn_keyZ);
            this.panel_02.Controls.Add(this.btn_keyO);
            this.panel_02.Controls.Add(this.btn_keyN);
            this.panel_02.Controls.Add(this.btn_keyU);
            this.panel_02.Controls.Add(this.btn_keyF);
            this.panel_02.Controls.Add(this.btn_keyK);
            this.panel_02.Controls.Add(this.btn_keyW);
            this.panel_02.Controls.Add(this.btn_keyX);
            this.panel_02.Controls.Add(this.btn_keyD);
            this.panel_02.Controls.Add(this.btn_keyT);
            this.panel_02.Controls.Add(this.btn_keyB);
            this.panel_02.Controls.Add(this.btn_keyJ);
            this.panel_02.Controls.Add(this.btn_keyG);
            this.panel_02.Controls.Add(this.btn_keyC);
            this.panel_02.Controls.Add(this.btn_keyE);
            this.panel_02.Controls.Add(this.btn_keyA);
            this.panel_02.Controls.Add(this.btn_keyS);
            this.panel_02.Controls.Add(this.btn_keyR);
            this.panel_02.Controls.Add(this.btn_keyV);
            this.panel_02.Controls.Add(this.btn_keyH);
            this.panel_02.Location = new System.Drawing.Point(24, 111);
            this.panel_02.Name = "panel_02";
            this.panel_02.Size = new System.Drawing.Size(735, 318);
            this.panel_02.TabIndex = 37;
            this.panel_02.Visible = false;
            // 
            // lb_text
            // 
            this.lb_text.AutoSize = true;
            this.lb_text.Location = new System.Drawing.Point(615, 22);
            this.lb_text.Name = "lb_text";
            this.lb_text.Size = new System.Drawing.Size(39, 20);
            this.lb_text.TabIndex = 43;
            this.lb_text.Text = "Text";
            // 
            // lb_blank05
            // 
            this.lb_blank05.AutoSize = true;
            this.lb_blank05.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank05.Location = new System.Drawing.Point(476, 76);
            this.lb_blank05.Name = "lb_blank05";
            this.lb_blank05.Size = new System.Drawing.Size(29, 33);
            this.lb_blank05.TabIndex = 42;
            this.lb_blank05.Text = "_";
            // 
            // lb_blank04
            // 
            this.lb_blank04.AutoSize = true;
            this.lb_blank04.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank04.Location = new System.Drawing.Point(405, 76);
            this.lb_blank04.Name = "lb_blank04";
            this.lb_blank04.Size = new System.Drawing.Size(29, 33);
            this.lb_blank04.TabIndex = 41;
            this.lb_blank04.Text = "_";
            // 
            // lb_blank03
            // 
            this.lb_blank03.AutoSize = true;
            this.lb_blank03.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank03.Location = new System.Drawing.Point(333, 76);
            this.lb_blank03.Name = "lb_blank03";
            this.lb_blank03.Size = new System.Drawing.Size(29, 33);
            this.lb_blank03.TabIndex = 40;
            this.lb_blank03.Text = "_";
            // 
            // lb_blank02
            // 
            this.lb_blank02.AutoSize = true;
            this.lb_blank02.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank02.Location = new System.Drawing.Point(262, 76);
            this.lb_blank02.Name = "lb_blank02";
            this.lb_blank02.Size = new System.Drawing.Size(29, 33);
            this.lb_blank02.TabIndex = 39;
            this.lb_blank02.Text = "_";
            // 
            // lb_blank01
            // 
            this.lb_blank01.AutoSize = true;
            this.lb_blank01.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blank01.Location = new System.Drawing.Point(194, 76);
            this.lb_blank01.Name = "lb_blank01";
            this.lb_blank01.Size = new System.Drawing.Size(29, 33);
            this.lb_blank01.TabIndex = 38;
            this.lb_blank01.Text = "_";
            // 
            // btn_keyP
            // 
            this.btn_keyP.Location = new System.Drawing.Point(657, 162);
            this.btn_keyP.Name = "btn_keyP";
            this.btn_keyP.Size = new System.Drawing.Size(63, 42);
            this.btn_keyP.TabIndex = 37;
            this.btn_keyP.Text = "P";
            this.btn_keyP.UseVisualStyleBackColor = true;
            this.btn_keyP.Click += new System.EventHandler(this.btn_keyP_Click);
            // 
            // form_01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 451);
            this.Controls.Add(this.panel_02);
            this.Controls.Add(this.panel_01);
            this.Controls.Add(this.button9);
            this.Name = "form_01";
            this.Text = "form";
            this.panel_01.ResumeLayout(false);
            this.panel_01.PerformLayout();
            this.panel_02.ResumeLayout(false);
            this.panel_02.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_word01;
        private System.Windows.Forms.Label lb_word02;
        private System.Windows.Forms.Label lb_word03;
        private System.Windows.Forms.Label lb_word04;
        private System.Windows.Forms.Label lb_word05;
        private System.Windows.Forms.TextBox tb_01;
        private System.Windows.Forms.TextBox tb_04;
        private System.Windows.Forms.TextBox tb_05;
        private System.Windows.Forms.TextBox tb_03;
        private System.Windows.Forms.TextBox tb_02;
        private System.Windows.Forms.Panel panel_01;
        private System.Windows.Forms.Button btn_keyQ;
        private System.Windows.Forms.Button btn_keyW;
        private System.Windows.Forms.Button btn_keyR;
        private System.Windows.Forms.Button btn_keyE;
        private System.Windows.Forms.Button btn_keyY;
        private System.Windows.Forms.Button btn_keyT;
        private System.Windows.Forms.Button btn_keyI;
        private System.Windows.Forms.Button btn_keyU;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button btn_keyO;
        private System.Windows.Forms.Button btn_keyL;
        private System.Windows.Forms.Button btn_keyK;
        private System.Windows.Forms.Button btn_keyJ;
        private System.Windows.Forms.Button btn_keyH;
        private System.Windows.Forms.Button btn_keyG;
        private System.Windows.Forms.Button btn_keyF;
        private System.Windows.Forms.Button btn_keyD;
        private System.Windows.Forms.Button btn_keyS;
        private System.Windows.Forms.Button btn_keyA;
        private System.Windows.Forms.Button btn_keyM;
        private System.Windows.Forms.Button btn_keyN;
        private System.Windows.Forms.Button btn_keyB;
        private System.Windows.Forms.Button btn_keyV;
        private System.Windows.Forms.Button btn_keyC;
        private System.Windows.Forms.Button btn_keyX;
        private System.Windows.Forms.Button btn_keyZ;
        private System.Windows.Forms.Panel panel_02;
        private System.Windows.Forms.Button btn_keyP;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Label lb_text;
        private System.Windows.Forms.Label lb_blank05;
        private System.Windows.Forms.Label lb_blank04;
        private System.Windows.Forms.Label lb_blank03;
        private System.Windows.Forms.Label lb_blank02;
        private System.Windows.Forms.Label lb_blank01;
    }
}

