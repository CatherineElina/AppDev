﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH01_Catherine_Elina
{
    public partial class form_01 : Form
    {
        List<char> hurufHuruf = new List<char>();
        List<char> tampilan = new List<char>() { '_', '_', '_', '_', '_' };
        public form_01()
        {
            InitializeComponent();
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
           string word1 = tb_01.Text;
            string word2 = tb_02.Text;
            string word3 = tb_03.Text;
            string word4 = tb_04.Text;
            string word5 = tb_05.Text;
            if (word1 == word2 || word1 == word3 || word1 == word4|| word1 == word5 || word2 == word3 || word2 == word4 || word2 == word5 ||
                word3 == word4 || word3 == word5 || word4 == word5)
            {
                MessageBox.Show("Error!");
            }
            else if (word1.Length != 5 || word2.Length != 5 || word3.Length != 5 || word4.Length != 5 || word5.Length != 5)
            {
                MessageBox.Show("Error!");
            }
            else
            {
                Random random = new Random();
                string[] words = { word1, word2, word3, word4, word5 };
                int randomIndex = random.Next(0, words.Length);
                lb_text.Text = words[randomIndex];
                string kataDitebak = words[randomIndex];
                MessageBox.Show("Good let's play the game!");
                panel_01.Visible = false;
                panel_02.Visible = true;

                

                foreach (char k in kataDitebak)
                {
                    hurufHuruf.Add(k);
                }
            }
        }

        private void btn_keyQ_Click(object sender, EventArgs e)
        {
            char huruf = 'Q';
            PeriksaHuruf(huruf);
        }

        private void btn_keyW_Click(object sender, EventArgs e)
        {
            char huruf = 'W';
            PeriksaHuruf(huruf);
        }

        private void btn_keyE_Click(object sender, EventArgs e)
        {
            char huruf = 'E';
            PeriksaHuruf(huruf);
        }

        private void btn_keyR_Click(object sender, EventArgs e)
        {
            char huruf = 'R';
            PeriksaHuruf(huruf);
        }

        private void btn_keyT_Click(object sender, EventArgs e)
        {
            char huruf = 'T';
            PeriksaHuruf(huruf);
        }

        private void btn_keyY_Click(object sender, EventArgs e)
        {
            char huruf = 'Y';
            PeriksaHuruf(huruf);
        }

        private void btn_keyU_Click(object sender, EventArgs e)
        {
            char huruf = 'U';
            PeriksaHuruf(huruf);
        }

        private void btn_keyI_Click(object sender, EventArgs e)
        {
            char huruf = 'I';
            PeriksaHuruf(huruf);
        }

        private void btn_keyO_Click(object sender, EventArgs e)
        {
            char huruf = 'O';
            PeriksaHuruf(huruf);
        }

        private void btn_keyP_Click(object sender, EventArgs e)
        {
            char huruf = 'P';
            PeriksaHuruf(huruf);
        }

        private void btn_keyA_Click(object sender, EventArgs e)
        {
            char huruf = 'A';
            PeriksaHuruf(huruf);
        }

        private void btn_keyS_Click(object sender, EventArgs e)
        {
            char huruf = 'S';
            PeriksaHuruf(huruf);
        }

        private void btn_keyD_Click(object sender, EventArgs e)
        {
            char huruf = 'D';
            PeriksaHuruf(huruf);
        }

        private void btn_keyF_Click(object sender, EventArgs e)
        {
            char huruf = 'F';
            PeriksaHuruf(huruf);
        }

        private void btn_keyG_Click(object sender, EventArgs e)
        {
            char huruf = 'G';
            PeriksaHuruf(huruf);
        }

        private void btn_keyH_Click(object sender, EventArgs e)
        {
            char huruf = 'H';
            PeriksaHuruf(huruf);
        }

        private void btn_keyJ_Click(object sender, EventArgs e)
        {
            char huruf = 'J';
            PeriksaHuruf(huruf);
        }

        private void btn_keyK_Click(object sender, EventArgs e)
        {
            char huruf = 'K';
            PeriksaHuruf(huruf);
        }

        private void btn_keyL_Click(object sender, EventArgs e)
        {
            char huruf = 'L';
            PeriksaHuruf(huruf);
        }

        private void btn_keyZ_Click(object sender, EventArgs e)
        {
            char huruf = 'Z';
            PeriksaHuruf(huruf);
        }

        private void btn_keyX_Click(object sender, EventArgs e)
        {
            char huruf = 'X';
            PeriksaHuruf(huruf);
        }

        private void btn_keyC_Click(object sender, EventArgs e)
        {
            char huruf = 'C';
            PeriksaHuruf(huruf);
        }

        private void btn_keyV_Click(object sender, EventArgs e)
        {
            char huruf = 'V';
            PeriksaHuruf(huruf);
        }

        private void btn_keyB_Click(object sender, EventArgs e)
        {
            char huruf = 'B';
            PeriksaHuruf(huruf);
        }

        private void btn_keyN_Click(object sender, EventArgs e)
        {
            char huruf = 'N';
            PeriksaHuruf(huruf);
        }

        private void btn_keyM_Click(object sender, EventArgs e)
        {
            char huruf = 'M';
            PeriksaHuruf(huruf);
        }
        private void PeriksaHuruf(char huruf)
        {
            huruf = char.ToUpper(huruf);
            for (int i = 0; i < hurufHuruf.Count; i++)
            {
                if (char.ToUpper(hurufHuruf[i]) == huruf && tampilan[i] == '_')
                {
                    tampilan[i] = huruf;
                    
                    if (i == 0)
                    {
                        lb_blank01.Text = huruf.ToString();
                    }
                    else if (i == 1)
                    {
                        lb_blank02.Text = huruf.ToString();
                    }
                    else if (i == 2)
                    {
                        lb_blank03.Text = huruf.ToString();
                    }
                    else if (i == 3)
                    {
                        lb_blank04.Text = huruf.ToString();
                    }
                    else if (i == 4)
                    {
                        lb_blank05.Text = huruf.ToString();
                    }
                }
            }
            bool selesai = !tampilan.Contains('_');
            if (selesai)
            {
                MessageBox.Show("Good Game!");
            }
        }

        
    }
}
