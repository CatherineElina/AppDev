﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;

namespace CAW14
{
    public partial class CAW14_FORM : Form
    {
        MySqlConnection MySqlConnection;
        MySqlCommand MySqlCommand;
        MySqlDataAdapter MySqlDataAdapter;
        DataTable mydata;
        DataTable mydata2;
        DataTable dtdataisi;
        DataTable dtMatch = new DataTable();
        string teamhome;
        string teamaway;
        public CAW14_FORM()
        {
            InitializeComponent();
        }

        private void CAW14_FORM_Load(object sender, EventArgs e)
        {
            mydata = new DataTable();
            mydata2 = new DataTable();
            MySqlConnection = new MySqlConnection("server=localhost;user=root;pwd=isbmantap;database=premier_league");
            MySqlConnection.Open();
            MySqlConnection.Close();
            string combobox = "SELECT team_name, team_id from team;";
            MySqlCommand = new MySqlCommand(combobox, MySqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
            MySqlDataAdapter.Fill(mydata);
            MySqlDataAdapter.Fill(mydata2);

            cb_TeamHome.DataSource = mydata;
            cb_TeamHome.DisplayMember = "team_name";
            cb_TeamHome.ValueMember = "team_id";
            cb_TeamHome.SelectedItem = null;

            cb_TeamAway.DataSource = mydata2;
            cb_TeamAway.DisplayMember = "team_name";
            cb_TeamAway.ValueMember = "team_id";
            cb_TeamAway.SelectedItem = null;

            dtMatch.Columns.Add("Minutes");
            dtMatch.Columns.Add("Team");
            dtMatch.Columns.Add("Player");
            dtMatch.Columns.Add("Type");

        }

        private void cb_TeamHome_SelectionChangeCommitted(object sender, EventArgs e)
        {
            DataTable dtMatchid = new DataTable();
            //DataTable dtMatch = new DataTable();
            if (cb_TeamHome.SelectedItem != null && cb_TeamAway.SelectedItem != null)
            {
                if (cb_TeamAway.SelectedValue.ToString() == cb_TeamHome.SelectedValue.ToString())
                {
                    MessageBox.Show("error");
                }
                else
                {
                    

                    string match = $"SELECT match_id , match_date from `match` WHERE team_home = '{cb_TeamAway.SelectedValue.ToString()}' AND team_away = '{cb_TeamHome.SelectedValue.ToString()}'";
                    MySqlCommand = new MySqlCommand(match, MySqlConnection);
                    MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
                    MySqlDataAdapter.Fill(dtMatchid);


                    if (dtMatchid.Rows.Count > 0)
                    {
                        tb_MatchID.Text = dtMatchid.Rows[0][0].ToString();
                        DTP_MatchDate.Text = dtMatchid.Rows[0][1].ToString();
                    }

                    DataTable dtnamateam = new DataTable();
                    teamaway = cb_TeamAway.SelectedValue.ToString();
                    teamhome = cb_TeamHome.SelectedValue.ToString();
                    string teamnames = $"SELECT team_id, team_name from team where team_id = '{teamhome}' or team_id = '{teamaway}'";
                    MySqlCommand = new MySqlCommand(teamnames, MySqlConnection);
                    MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
                    MySqlDataAdapter.Fill(dtnamateam);
                    cb_Team.DataSource = dtnamateam;
                    cb_Team.ValueMember = "team_id";
                    cb_Team.DisplayMember = "team_name";

                    DataTable dtnamaplayer = new DataTable();
                    string playername = $"SELECT player_id, player_name from player where team_id = '{teamhome}' or team_id = '{teamaway}'";
                    MySqlCommand = new MySqlCommand(playername, MySqlConnection);
                    MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
                    MySqlDataAdapter.Fill(dtnamaplayer);
                    cb_Player.DataSource = dtnamaplayer;
                    cb_Player.ValueMember = "player_id";
                    cb_Player.DisplayMember = "player_name";

                    cb_Type.Items.Add("GO");
                    cb_Type.Items.Add("GP");
                    cb_Type.Items.Add("GW");
                    cb_Type.Items.Add("CR");
                    cb_Type.Items.Add("CY");
                    cb_Type.Items.Add("PM");
                }
            }
        }

        private void cb_TeamAway_SelectionChangeCommitted(object sender, EventArgs e)
        {
            DataTable dtMatchid = new DataTable();
            //DataTable dtMatch = new DataTable();
            if (cb_TeamHome.SelectedItem != null && cb_TeamAway.SelectedItem != null)
            {
                
                if (cb_TeamAway.SelectedValue.ToString() == cb_TeamHome.SelectedValue.ToString())
                {
                    MessageBox.Show("error");
                }
                else
                {

                    //string dgv = $"SELECT d.minute, t.team_name, p.player_name, d.type FROM dmatch d, team t, player p, `match` m WHERE p.player_id = d.player_id AND d.team_id = t.team_id AND m.match_id = d.match_id and (m.team_home = '{cb_TeamAway.SelectedValue.ToString()}' AND m.team_away = '{cb_TeamHome.SelectedValue.ToString()}') order by 1";
                    //MySqlCommand = new MySqlCommand(dgv, MySqlConnection);
                    //MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
                    //MySqlDataAdapter.Fill(dtMatch);

                    string match = $"SELECT match_id , match_date from `match` WHERE team_home = '{cb_TeamAway.SelectedValue.ToString()}' AND team_away = '{cb_TeamHome.SelectedValue.ToString()}'";
                    MySqlCommand = new MySqlCommand(match, MySqlConnection);
                    MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
                    MySqlDataAdapter.Fill(dtMatchid);
                    tb_MatchID.Enabled = false;

                    dataGridView1.DataSource = dtMatch;
                    if (dtMatchid.Rows.Count > 0)
                    {
                        tb_MatchID.Text = dtMatchid.Rows[0][0].ToString();
                        DTP_MatchDate.Text = dtMatchid.Rows[0][1].ToString();
                    }
                    DataTable dtnamateam = new DataTable();
                    teamaway = cb_TeamAway.SelectedValue.ToString();
                    teamhome = cb_TeamHome.SelectedValue.ToString();
                    string teamnames = $"SELECT team_id, team_name from team where team_id = '{teamhome}' or team_id = '{teamaway}'";
                    MySqlCommand = new MySqlCommand(teamnames, MySqlConnection);
                    MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
                    MySqlDataAdapter.Fill(dtnamateam);
                    cb_Team.DataSource = dtnamateam;
                    cb_Team.ValueMember = "team_id";
                    cb_Team.DisplayMember = "team_name";

                    DataTable dtnamaplayer = new DataTable();
                    string playername = $"SELECT player_id, player_name from player where team_id = '{teamhome}' or team_id = '{teamaway}'";
                    MySqlCommand = new MySqlCommand(playername, MySqlConnection);
                    MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
                    MySqlDataAdapter.Fill(dtnamaplayer);
                    cb_Player.DataSource = dtnamaplayer;
                    cb_Player.ValueMember = "player_id";
                    cb_Player.DisplayMember = "player_name";

                    cb_Type.Items.Add("GO");
                    cb_Type.Items.Add("GP");
                    cb_Type.Items.Add("GW");
                    cb_Type.Items.Add("CR");
                    cb_Type.Items.Add("CY");
                    cb_Type.Items.Add("PM");
                }
            }
        }
        private void btn_Add_Click(object sender, EventArgs e)
        {
            if(tb_Minute.Text == "" || cb_Team.SelectedValue == null || cb_Player.SelectedValue == null|| cb_Type.SelectedItem == null)
            {
                MessageBox.Show("error");

            }
            else
            {
                dtMatch.Rows.Add(tb_Minute.Text,cb_Team.Text, cb_Player.Text,cb_Type.Text);
            }
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.RemoveAt(dataGridView1.CurrentCell.RowIndex);
        }

        private void btn_Insert_Click(object sender, EventArgs e)
        {
            //if (tb_Minute.Text == "" || tb.Text == "" || tb_Nim.Text == "")
            //{
            //    MessageBox.Show("Isi dulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //else
            //{
            //    dtdataisi = new DataTable();
            //    string dt = DateTime.Now.ToString("yyyy-MM-dd");
            //    query = "Insert Into Student values('" + tb_ID.Text + "','" + tb_Nama.Text + "','" + dt + "', '" + tb_Nim.Text + "')";
            //    mySqlConnection.Open();
            //    mySqlCommand = new MySqlCommand(query, mySqlConnection);
            //    mySqlCommand.ExecuteNonQuery();
            //    mySqlConnection.Close();
            //    query = "select * from student";
            //    mySqlCommand = new MySqlCommand(query, mySqlConnection);
            //    mySqlDataAdapter = new MySqlDataAdapter(mySqlCommand);
            //    mySqlDataAdapter.Fill(data);
            //    dataGridView1.DataSource = data;
            //}
        }

        private void DTP_MatchDate_ValueChanged(object sender, EventArgs e)
        {
           DateTime dt = new DateTime(2014,2,14);
            if (DTP_MatchDate.Value < dt)
            {
                MessageBox.Show("error");
            }
        }
    }
}
