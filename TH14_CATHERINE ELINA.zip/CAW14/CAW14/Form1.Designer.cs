﻿namespace CAW14
{
    partial class CAW14_FORM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_MatchID = new System.Windows.Forms.Label();
            this.lbl_TeamHome = new System.Windows.Forms.Label();
            this.tb_MatchID = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lbl_teamaway = new System.Windows.Forms.Label();
            this.lbl_MatchDate = new System.Windows.Forms.Label();
            this.cb_TeamAway = new System.Windows.Forms.ComboBox();
            this.btn_Insert = new System.Windows.Forms.Button();
            this.lbl_Minute = new System.Windows.Forms.Label();
            this.lbl_Team = new System.Windows.Forms.Label();
            this.lbl_Type = new System.Windows.Forms.Label();
            this.lbl_Player = new System.Windows.Forms.Label();
            this.tb_Minute = new System.Windows.Forms.TextBox();
            this.cb_Team = new System.Windows.Forms.ComboBox();
            this.cb_Player = new System.Windows.Forms.ComboBox();
            this.cb_Type = new System.Windows.Forms.ComboBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.cb_TeamHome = new System.Windows.Forms.ComboBox();
            this.DTP_MatchDate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_MatchID
            // 
            this.lbl_MatchID.AutoSize = true;
            this.lbl_MatchID.Location = new System.Drawing.Point(42, 65);
            this.lbl_MatchID.Name = "lbl_MatchID";
            this.lbl_MatchID.Size = new System.Drawing.Size(109, 25);
            this.lbl_MatchID.TabIndex = 0;
            this.lbl_MatchID.Text = "Match ID: ";
            // 
            // lbl_TeamHome
            // 
            this.lbl_TeamHome.AutoSize = true;
            this.lbl_TeamHome.Location = new System.Drawing.Point(41, 130);
            this.lbl_TeamHome.Name = "lbl_TeamHome";
            this.lbl_TeamHome.Size = new System.Drawing.Size(128, 25);
            this.lbl_TeamHome.TabIndex = 1;
            this.lbl_TeamHome.Text = "Team Home";
            // 
            // tb_MatchID
            // 
            this.tb_MatchID.Enabled = false;
            this.tb_MatchID.Location = new System.Drawing.Point(172, 59);
            this.tb_MatchID.Name = "tb_MatchID";
            this.tb_MatchID.Size = new System.Drawing.Size(205, 31);
            this.tb_MatchID.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(36, 195);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(810, 406);
            this.dataGridView1.TabIndex = 4;
            // 
            // lbl_teamaway
            // 
            this.lbl_teamaway.AutoSize = true;
            this.lbl_teamaway.Location = new System.Drawing.Point(635, 130);
            this.lbl_teamaway.Name = "lbl_teamaway";
            this.lbl_teamaway.Size = new System.Drawing.Size(124, 25);
            this.lbl_teamaway.TabIndex = 6;
            this.lbl_teamaway.Text = "Team Away";
            // 
            // lbl_MatchDate
            // 
            this.lbl_MatchDate.AutoSize = true;
            this.lbl_MatchDate.Location = new System.Drawing.Point(635, 65);
            this.lbl_MatchDate.Name = "lbl_MatchDate";
            this.lbl_MatchDate.Size = new System.Drawing.Size(122, 25);
            this.lbl_MatchDate.TabIndex = 5;
            this.lbl_MatchDate.Text = "Match Date";
            // 
            // cb_TeamAway
            // 
            this.cb_TeamAway.FormattingEnabled = true;
            this.cb_TeamAway.Location = new System.Drawing.Point(763, 122);
            this.cb_TeamAway.Name = "cb_TeamAway";
            this.cb_TeamAway.Size = new System.Drawing.Size(212, 33);
            this.cb_TeamAway.TabIndex = 8;
            this.cb_TeamAway.SelectionChangeCommitted += new System.EventHandler(this.cb_TeamAway_SelectionChangeCommitted);
            // 
            // btn_Insert
            // 
            this.btn_Insert.Location = new System.Drawing.Point(683, 649);
            this.btn_Insert.Name = "btn_Insert";
            this.btn_Insert.Size = new System.Drawing.Size(126, 39);
            this.btn_Insert.TabIndex = 9;
            this.btn_Insert.Text = "Insert";
            this.btn_Insert.UseVisualStyleBackColor = true;
            this.btn_Insert.Click += new System.EventHandler(this.btn_Insert_Click);
            // 
            // lbl_Minute
            // 
            this.lbl_Minute.AutoSize = true;
            this.lbl_Minute.Location = new System.Drawing.Point(886, 203);
            this.lbl_Minute.Name = "lbl_Minute";
            this.lbl_Minute.Size = new System.Drawing.Size(77, 25);
            this.lbl_Minute.TabIndex = 10;
            this.lbl_Minute.Text = "Minute";
            // 
            // lbl_Team
            // 
            this.lbl_Team.AutoSize = true;
            this.lbl_Team.Location = new System.Drawing.Point(886, 269);
            this.lbl_Team.Name = "lbl_Team";
            this.lbl_Team.Size = new System.Drawing.Size(66, 25);
            this.lbl_Team.TabIndex = 11;
            this.lbl_Team.Text = "Team";
            // 
            // lbl_Type
            // 
            this.lbl_Type.AutoSize = true;
            this.lbl_Type.Location = new System.Drawing.Point(886, 405);
            this.lbl_Type.Name = "lbl_Type";
            this.lbl_Type.Size = new System.Drawing.Size(60, 25);
            this.lbl_Type.TabIndex = 13;
            this.lbl_Type.Text = "Type";
            // 
            // lbl_Player
            // 
            this.lbl_Player.AutoSize = true;
            this.lbl_Player.Location = new System.Drawing.Point(886, 339);
            this.lbl_Player.Name = "lbl_Player";
            this.lbl_Player.Size = new System.Drawing.Size(73, 25);
            this.lbl_Player.TabIndex = 12;
            this.lbl_Player.Text = "Player";
            // 
            // tb_Minute
            // 
            this.tb_Minute.Location = new System.Drawing.Point(993, 200);
            this.tb_Minute.Name = "tb_Minute";
            this.tb_Minute.Size = new System.Drawing.Size(206, 31);
            this.tb_Minute.TabIndex = 14;
            // 
            // cb_Team
            // 
            this.cb_Team.FormattingEnabled = true;
            this.cb_Team.Location = new System.Drawing.Point(993, 261);
            this.cb_Team.Name = "cb_Team";
            this.cb_Team.Size = new System.Drawing.Size(206, 33);
            this.cb_Team.TabIndex = 15;
            // 
            // cb_Player
            // 
            this.cb_Player.FormattingEnabled = true;
            this.cb_Player.Location = new System.Drawing.Point(993, 331);
            this.cb_Player.Name = "cb_Player";
            this.cb_Player.Size = new System.Drawing.Size(206, 33);
            this.cb_Player.TabIndex = 16;
            // 
            // cb_Type
            // 
            this.cb_Type.FormattingEnabled = true;
            this.cb_Type.Location = new System.Drawing.Point(993, 397);
            this.cb_Type.Name = "cb_Type";
            this.cb_Type.Size = new System.Drawing.Size(206, 33);
            this.cb_Type.TabIndex = 17;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(891, 484);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(100, 44);
            this.btn_Add.TabIndex = 18;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(1038, 484);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(100, 44);
            this.btn_Remove.TabIndex = 19;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // cb_TeamHome
            // 
            this.cb_TeamHome.FormattingEnabled = true;
            this.cb_TeamHome.Location = new System.Drawing.Point(175, 127);
            this.cb_TeamHome.Name = "cb_TeamHome";
            this.cb_TeamHome.Size = new System.Drawing.Size(205, 33);
            this.cb_TeamHome.TabIndex = 20;
            this.cb_TeamHome.SelectionChangeCommitted += new System.EventHandler(this.cb_TeamHome_SelectionChangeCommitted);
            // 
            // DTP_MatchDate
            // 
            this.DTP_MatchDate.Location = new System.Drawing.Point(763, 65);
            this.DTP_MatchDate.Name = "DTP_MatchDate";
            this.DTP_MatchDate.Size = new System.Drawing.Size(393, 31);
            this.DTP_MatchDate.TabIndex = 21;
            this.DTP_MatchDate.ValueChanged += new System.EventHandler(this.DTP_MatchDate_ValueChanged);
            // 
            // CAW14_FORM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1304, 767);
            this.Controls.Add(this.DTP_MatchDate);
            this.Controls.Add(this.cb_TeamHome);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.cb_Type);
            this.Controls.Add(this.cb_Player);
            this.Controls.Add(this.cb_Team);
            this.Controls.Add(this.tb_Minute);
            this.Controls.Add(this.lbl_Type);
            this.Controls.Add(this.lbl_Player);
            this.Controls.Add(this.lbl_Team);
            this.Controls.Add(this.lbl_Minute);
            this.Controls.Add(this.btn_Insert);
            this.Controls.Add(this.cb_TeamAway);
            this.Controls.Add(this.lbl_teamaway);
            this.Controls.Add(this.lbl_MatchDate);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tb_MatchID);
            this.Controls.Add(this.lbl_TeamHome);
            this.Controls.Add(this.lbl_MatchID);
            this.Name = "CAW14_FORM";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.CAW14_FORM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_MatchID;
        private System.Windows.Forms.Label lbl_TeamHome;
        private System.Windows.Forms.TextBox tb_MatchID;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lbl_teamaway;
        private System.Windows.Forms.Label lbl_MatchDate;
        private System.Windows.Forms.ComboBox cb_TeamAway;
        private System.Windows.Forms.Button btn_Insert;
        private System.Windows.Forms.Label lbl_Minute;
        private System.Windows.Forms.Label lbl_Team;
        private System.Windows.Forms.Label lbl_Type;
        private System.Windows.Forms.Label lbl_Player;
        private System.Windows.Forms.TextBox tb_Minute;
        private System.Windows.Forms.ComboBox cb_Team;
        private System.Windows.Forms.ComboBox cb_Player;
        private System.Windows.Forms.ComboBox cb_Type;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.ComboBox cb_TeamHome;
        private System.Windows.Forms.DateTimePicker DTP_MatchDate;
    }
}

