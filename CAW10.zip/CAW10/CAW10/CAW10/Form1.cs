﻿using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace CAW10
{
    public partial class Main_Forms : Form
    {
        MySqlConnection MySqlConnection;
        MySqlCommand MySqlCommand;
        MySqlDataAdapter MySqlDataAdapter;
        DataTable dtPlayer, dtTeam, dtNationality;
       
        int playerCount = 0;
        public Main_Forms()
        {
            InitializeComponent();
            MySqlConnection = new MySqlConnection("server=localhost;uid=root;pwd=;database=premier_league");
            MySqlConnection.Open();
            MySqlConnection.Close();
            string sqlquerry = "Select * from Player";
            MySqlCommand = new MySqlCommand(sqlquerry, MySqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
            dtPlayer = new DataTable();
            MySqlDataAdapter.Fill(dtPlayer);


            string sqlquerry3 = "Select * from Nationality";
            MySqlCommand = new MySqlCommand(sqlquerry3, MySqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
            dtNationality = new DataTable();
            MySqlDataAdapter.Fill(dtNationality);

            playerCount = dtPlayer.Rows.Count;
            for (int i = 0; i < dtNationality.Rows.Count; i++)
            {
                if (dtPlayer.Rows[0][3].ToString() == dtNationality.Rows[i][0].ToString())
                {
                    tb_Nationality.Text = dtNationality.Rows[i][2].ToString();
                    break;
                }
            }

            string sqlquerry2 = "Select * from Team";
            MySqlCommand = new MySqlCommand(sqlquerry2, MySqlConnection);
            MySqlDataAdapter = new MySqlDataAdapter(MySqlCommand);
            dtTeam = new DataTable();
            MySqlDataAdapter.Fill(dtTeam);

            for (int i = 0; i < dtTeam.Rows.Count; i++)
            {
                CB_Team.Items.Add(dtTeam.Rows[i][1].ToString());
            }

            for (int i = 0; i < dtTeam.Rows.Count; i++)
            {
                if (dtPlayer.Rows[0][8].ToString() == dtTeam.Rows[i][0].ToString())
                {
                    CB_Team.SelectedItem = dtTeam.Rows[i][1].ToString();
                    break;
                }
            }

            Numeric_TeamNumber.Value = Convert.ToInt32(dtPlayer.Rows[0][1]);
        }

        private void isiData()
        {
            tb_PlayerID.Text = dtPlayer.Rows[playerCount][0].ToString();
            tb_PlayerName.Text = dtPlayer.Rows[playerCount][2].ToString();
            DateTime_Birthdate.Text = dtPlayer.Rows[playerCount][7].ToString();

            for (int i = 0; i < dtNationality.Rows.Count; i++)
            {
                if (dtPlayer.Rows[playerCount][3].ToString() == dtNationality.Rows[i][0].ToString())
                {
                    tb_Nationality.Text = dtNationality.Rows[i][2].ToString();
                    break;
                }
            }

            for (int i = 0; i < dtTeam.Rows.Count; i++)
            {
                if (dtPlayer.Rows[playerCount][8].ToString() == dtTeam.Rows[i][0].ToString())
                {
                    CB_Team.SelectedItem = dtTeam.Rows[i][1].ToString();
                    break;
                }
            }

            Numeric_TeamNumber.Value = Convert.ToInt32(dtPlayer.Rows[playerCount][1]);
        }



        private void Main_Forms_Load(object sender, EventArgs e)
        {

        }

        private void btn_PalingKiri_Click(object sender, EventArgs e)
        {
            playerCount = 0;

            isiData();
        }

        private void btn_kiri_Click(object sender, EventArgs e)
        {
            if (playerCount > 0)
            {
                playerCount--;

                isiData();
            }
        }

        private void btn_Kanan_Click(object sender, EventArgs e)
        {
            if (playerCount < dtPlayer.Rows.Count - 1)
            {
                playerCount++;

                isiData();
            }
        }

        private void btn_PalingKanan_Click(object sender, EventArgs e)
        {
            playerCount = dtPlayer.Rows.Count - 1;

            isiData();
        }
    }
}
