﻿namespace CAW10
{
    partial class Main_Forms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_PalingKiri = new System.Windows.Forms.Button();
            this.btn_kiri = new System.Windows.Forms.Button();
            this.btn_Kanan = new System.Windows.Forms.Button();
            this.btn_PalingKanan = new System.Windows.Forms.Button();
            this.lbl_PlayerID = new System.Windows.Forms.Label();
            this.lbl_Birthdate = new System.Windows.Forms.Label();
            this.lbl_PlayerName = new System.Windows.Forms.Label();
            this.lbl_Nationality = new System.Windows.Forms.Label();
            this.lbl_Team = new System.Windows.Forms.Label();
            this.lbl_TeamNumber = new System.Windows.Forms.Label();
            this.tb_PlayerID = new System.Windows.Forms.TextBox();
            this.tb_PlayerName = new System.Windows.Forms.TextBox();
            this.tb_Nationality = new System.Windows.Forms.TextBox();
            this.DateTime_Birthdate = new System.Windows.Forms.DateTimePicker();
            this.CB_Team = new System.Windows.Forms.ComboBox();
            this.Numeric_TeamNumber = new System.Windows.Forms.NumericUpDown();
            this.btn_save = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Numeric_TeamNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_PalingKiri
            // 
            this.btn_PalingKiri.Location = new System.Drawing.Point(81, 124);
            this.btn_PalingKiri.Name = "btn_PalingKiri";
            this.btn_PalingKiri.Size = new System.Drawing.Size(146, 112);
            this.btn_PalingKiri.TabIndex = 0;
            this.btn_PalingKiri.Text = "<<";
            this.btn_PalingKiri.UseVisualStyleBackColor = true;
            this.btn_PalingKiri.Click += new System.EventHandler(this.btn_PalingKiri_Click);
            // 
            // btn_kiri
            // 
            this.btn_kiri.Location = new System.Drawing.Point(291, 124);
            this.btn_kiri.Name = "btn_kiri";
            this.btn_kiri.Size = new System.Drawing.Size(146, 112);
            this.btn_kiri.TabIndex = 1;
            this.btn_kiri.Text = "<";
            this.btn_kiri.UseVisualStyleBackColor = true;
            this.btn_kiri.Click += new System.EventHandler(this.btn_kiri_Click);
            // 
            // btn_Kanan
            // 
            this.btn_Kanan.Location = new System.Drawing.Point(532, 124);
            this.btn_Kanan.Name = "btn_Kanan";
            this.btn_Kanan.Size = new System.Drawing.Size(146, 112);
            this.btn_Kanan.TabIndex = 2;
            this.btn_Kanan.Text = ">";
            this.btn_Kanan.UseVisualStyleBackColor = true;
            this.btn_Kanan.Click += new System.EventHandler(this.btn_Kanan_Click);
            // 
            // btn_PalingKanan
            // 
            this.btn_PalingKanan.Location = new System.Drawing.Point(784, 124);
            this.btn_PalingKanan.Name = "btn_PalingKanan";
            this.btn_PalingKanan.Size = new System.Drawing.Size(146, 112);
            this.btn_PalingKanan.TabIndex = 3;
            this.btn_PalingKanan.Text = ">>";
            this.btn_PalingKanan.UseVisualStyleBackColor = true;
            this.btn_PalingKanan.Click += new System.EventHandler(this.btn_PalingKanan_Click);
            // 
            // lbl_PlayerID
            // 
            this.lbl_PlayerID.AutoSize = true;
            this.lbl_PlayerID.Location = new System.Drawing.Point(103, 307);
            this.lbl_PlayerID.Name = "lbl_PlayerID";
            this.lbl_PlayerID.Size = new System.Drawing.Size(99, 25);
            this.lbl_PlayerID.TabIndex = 4;
            this.lbl_PlayerID.Text = "Player ID";
            // 
            // lbl_Birthdate
            // 
            this.lbl_Birthdate.AutoSize = true;
            this.lbl_Birthdate.Location = new System.Drawing.Point(103, 443);
            this.lbl_Birthdate.Name = "lbl_Birthdate";
            this.lbl_Birthdate.Size = new System.Drawing.Size(98, 25);
            this.lbl_Birthdate.TabIndex = 5;
            this.lbl_Birthdate.Text = "Birthdate";
            // 
            // lbl_PlayerName
            // 
            this.lbl_PlayerName.AutoSize = true;
            this.lbl_PlayerName.Location = new System.Drawing.Point(103, 372);
            this.lbl_PlayerName.Name = "lbl_PlayerName";
            this.lbl_PlayerName.Size = new System.Drawing.Size(135, 25);
            this.lbl_PlayerName.TabIndex = 6;
            this.lbl_PlayerName.Text = "Player Name";
            // 
            // lbl_Nationality
            // 
            this.lbl_Nationality.AutoSize = true;
            this.lbl_Nationality.Location = new System.Drawing.Point(103, 517);
            this.lbl_Nationality.Name = "lbl_Nationality";
            this.lbl_Nationality.Size = new System.Drawing.Size(113, 25);
            this.lbl_Nationality.TabIndex = 7;
            this.lbl_Nationality.Text = "Nationality";
            // 
            // lbl_Team
            // 
            this.lbl_Team.AutoSize = true;
            this.lbl_Team.Location = new System.Drawing.Point(103, 588);
            this.lbl_Team.Name = "lbl_Team";
            this.lbl_Team.Size = new System.Drawing.Size(66, 25);
            this.lbl_Team.TabIndex = 8;
            this.lbl_Team.Text = "Team";
            // 
            // lbl_TeamNumber
            // 
            this.lbl_TeamNumber.AutoSize = true;
            this.lbl_TeamNumber.Location = new System.Drawing.Point(103, 653);
            this.lbl_TeamNumber.Name = "lbl_TeamNumber";
            this.lbl_TeamNumber.Size = new System.Drawing.Size(147, 25);
            this.lbl_TeamNumber.TabIndex = 9;
            this.lbl_TeamNumber.Text = "Team Number";
            // 
            // tb_PlayerID
            // 
            this.tb_PlayerID.Location = new System.Drawing.Point(303, 307);
            this.tb_PlayerID.Name = "tb_PlayerID";
            this.tb_PlayerID.Size = new System.Drawing.Size(299, 31);
            this.tb_PlayerID.TabIndex = 10;
            // 
            // tb_PlayerName
            // 
            this.tb_PlayerName.Location = new System.Drawing.Point(303, 369);
            this.tb_PlayerName.Name = "tb_PlayerName";
            this.tb_PlayerName.Size = new System.Drawing.Size(299, 31);
            this.tb_PlayerName.TabIndex = 11;
            // 
            // tb_Nationality
            // 
            this.tb_Nationality.Location = new System.Drawing.Point(303, 511);
            this.tb_Nationality.Name = "tb_Nationality";
            this.tb_Nationality.Size = new System.Drawing.Size(299, 31);
            this.tb_Nationality.TabIndex = 12;
            // 
            // DateTime_Birthdate
            // 
            this.DateTime_Birthdate.Location = new System.Drawing.Point(303, 437);
            this.DateTime_Birthdate.Name = "DateTime_Birthdate";
            this.DateTime_Birthdate.Size = new System.Drawing.Size(375, 31);
            this.DateTime_Birthdate.TabIndex = 13;
            // 
            // CB_Team
            // 
            this.CB_Team.FormattingEnabled = true;
            this.CB_Team.Location = new System.Drawing.Point(303, 580);
            this.CB_Team.Name = "CB_Team";
            this.CB_Team.Size = new System.Drawing.Size(299, 33);
            this.CB_Team.TabIndex = 14;
            // 
            // Numeric_TeamNumber
            // 
            this.Numeric_TeamNumber.Location = new System.Drawing.Point(303, 651);
            this.Numeric_TeamNumber.Name = "Numeric_TeamNumber";
            this.Numeric_TeamNumber.Size = new System.Drawing.Size(299, 31);
            this.Numeric_TeamNumber.TabIndex = 15;
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(303, 713);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(102, 40);
            this.btn_save.TabIndex = 16;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            // 
            // Main_Forms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1634, 1051);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.Numeric_TeamNumber);
            this.Controls.Add(this.CB_Team);
            this.Controls.Add(this.DateTime_Birthdate);
            this.Controls.Add(this.tb_Nationality);
            this.Controls.Add(this.tb_PlayerName);
            this.Controls.Add(this.tb_PlayerID);
            this.Controls.Add(this.lbl_TeamNumber);
            this.Controls.Add(this.lbl_Team);
            this.Controls.Add(this.lbl_Nationality);
            this.Controls.Add(this.lbl_PlayerName);
            this.Controls.Add(this.lbl_Birthdate);
            this.Controls.Add(this.lbl_PlayerID);
            this.Controls.Add(this.btn_PalingKanan);
            this.Controls.Add(this.btn_Kanan);
            this.Controls.Add(this.btn_kiri);
            this.Controls.Add(this.btn_PalingKiri);
            this.Name = "Main_Forms";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Main_Forms_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Numeric_TeamNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_PalingKiri;
        private System.Windows.Forms.Button btn_kiri;
        private System.Windows.Forms.Button btn_Kanan;
        private System.Windows.Forms.Button btn_PalingKanan;
        private System.Windows.Forms.Label lbl_PlayerID;
        private System.Windows.Forms.Label lbl_Birthdate;
        private System.Windows.Forms.Label lbl_PlayerName;
        private System.Windows.Forms.Label lbl_Nationality;
        private System.Windows.Forms.Label lbl_Team;
        private System.Windows.Forms.Label lbl_TeamNumber;
        private System.Windows.Forms.TextBox tb_PlayerID;
        private System.Windows.Forms.TextBox tb_PlayerName;
        private System.Windows.Forms.TextBox tb_Nationality;
        private System.Windows.Forms.DateTimePicker DateTime_Birthdate;
        private System.Windows.Forms.ComboBox CB_Team;
        private System.Windows.Forms.NumericUpDown Numeric_TeamNumber;
        private System.Windows.Forms.Button btn_save;
    }
}

