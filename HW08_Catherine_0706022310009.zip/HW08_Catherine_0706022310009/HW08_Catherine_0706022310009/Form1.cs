﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW08_Catherine_0706022310009
{
    public partial class UNIQME : Form
    {
        bool imageUploaded = false;
        DataTable shoppingCart = new DataTable();

        public UNIQME()
        {
            InitializeComponent();
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelry.Visible = false;
            panel_AddProduct.Visible = false;
            tb_SubTotal.Enabled = false;
            tb_Total.Enabled = false;
            tb_AddNameItem.Enabled = false;
            tb_AddItemPrice.Enabled = false;
            shoppingCart.Columns.Add("Item Name", typeof(string));
            shoppingCart.Columns.Add("Quantity", typeof(int));
            shoppingCart.Columns.Add("Price", typeof(decimal));
            shoppingCart.Columns.Add("Total", typeof(decimal), "Price * Quantity");

        }

        private void btn_TshirtKerah_Click(object sender, EventArgs e)
        {
            AddToCart("T-Shirt Kerah Bulat", 120000);
        }

        private void btn_TshirtAIRism_Click(object sender, EventArgs e)
        {
            AddToCart("T-Shirt AIRism", 150000);
        }

        private void btn_TshirtVneck_Click(object sender, EventArgs e)
        {
            AddToCart("T-Shirt Vneck", 170000);
        }

        private void btn_ShirtRaph_Click(object sender, EventArgs e)
        {
            AddToCart("Shirt Ralph Lauren", 570000);
        }

        private void btn_ShirtZara_Click(object sender, EventArgs e)
        {
            AddToCart("Shirt Zara", 350000);
        }

        private void btn_ShirtHugo_Click(object sender, EventArgs e)
        {
            AddToCart("Shirt Hugo Boss", 870000);
        }

        private void btn_PantsHnM_Click(object sender, EventArgs e)
        {
            AddToCart("Pants HnM", 400000);
        }

        private void btn_pantsCalvinKlein_Click(object sender, EventArgs e)
        {
            AddToCart("Pants Calvin Klein", 900000);
        }

        private void btn_PantsLevis_Click(object sender, EventArgs e)
        {
            AddToCart("Pants Levis", 350000);
        }

        private void btn_LongTheory_Click(object sender, EventArgs e)
        {
            AddToCart("Long Theory", 350000);
        }

        private void btn_LongDKNY_Click(object sender, EventArgs e)
        {
            AddToCart("Long DKNY", 320000);
        }

        private void btn_LongNike_Click(object sender, EventArgs e)
        {
            AddToCart("Long Nike", 200000);
        }

        private void btn_ShoesNB_Click(object sender, EventArgs e)
        {
            AddToCart("Shoes New Balance", 1500000);
        }

        private void btn_ShoesAdidas_Click(object sender, EventArgs e)
        {
            AddToCart("Shoes Adidas", 3320000);
        }

        private void btn_ShoesNike_Click(object sender, EventArgs e)
        {
            AddToCart("Shoes Nike", 1650000);
        }

        private void btn_JewelCartier_Click(object sender, EventArgs e)
        {
            AddToCart("Jewel Cartier", 10500000);
        }

        private void btn_JewelBvlgari_Click(object sender, EventArgs e)
        {
            AddToCart("Jewel Bvlgari", 7320000);
        }

        private void btn_JewelChopard_Click(object sender, EventArgs e)
        {
            AddToCart("Jewel Chopard", 5650000);
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Shirt.Visible = true;
            panel_Tshirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelry.Visible = false;
            panel_AddProduct.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pants.Visible = true;
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelry.Visible = false;
            panel_AddProduct.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_longPants.Visible = true;
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_pants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelry.Visible = false;
            panel_AddProduct.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Shoes.Visible = true;
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_jewelry.Visible = false;
            panel_AddProduct.Visible = false;
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_jewelry.Visible = true;
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_AddProduct.Visible = false;

        }

        private void addProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PB_UploadImage.Image = null;
            tb_AddItemPrice.Clear();
            tb_AddNameItem.Clear();
            panel_AddProduct.Visible = true;
            panel_Tshirt.Visible = false;
            panel_Tshirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelry.Visible = false;
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Tshirt.Visible = true;
            panel_Shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelry.Visible = false;
            panel_AddProduct.Visible = false;
        }

        private void UNIQME_Load(object sender, EventArgs e)
        {
            DGV_Total.DataSource = shoppingCart;
        }

        private void AddToCart(string itemName, decimal price)
        {
            var existingItem = shoppingCart.AsEnumerable().FirstOrDefault(row => row.Field<string>("Item Name") == itemName);
            if (existingItem != null)
            {
                existingItem["Quantity"] = (int)existingItem["Quantity"] + 1;
            }
            else
            {
                shoppingCart.Rows.Add(itemName, 1, price, price);
            }

            UpdateSubtotalAndTotal();
        }

        private void UpdateSubtotalAndTotal()
        {
            decimal subtotal = 0;
            decimal tax = 0;
            decimal total = 0;

            foreach (DataRow row in shoppingCart.Rows)
            {
                subtotal += (decimal)row["Total"];
            }

            tax = subtotal * 0.1M; // 10% tax
            total = subtotal + tax;

            tb_SubTotal.Text = $"{subtotal:C}";
            tb_Total.Text = $"{total:C}";
        }

        private void btn_AddAddProduct_Click(object sender, EventArgs e)
        {
            AddToCart(tb_AddNameItem.Text,Convert.ToInt32(tb_AddItemPrice.Text));
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            string image;
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    image = openFileDialog.FileName;
                    PB_UploadImage.ImageLocation = image;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error!");
            }

            if (PB_UploadImage.ImageLocation != null)
            {
                tb_AddNameItem.Enabled = true;
                tb_AddItemPrice.Enabled = true;
            }
        }


        private void tb_AddItemPrice_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }

            // allow only one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void btn_remove_Click(object sender, EventArgs e)
        {
            if (DGV_Total.SelectedRows.Count > 0)
            {
                // get the selected row
                //DataGridViewRow selectedRow = DGV_Total.SelectedRows[0];
                DataGridViewRow dgvr = DGV_Total.CurrentRow;
                //MessageBox.Show(dgvr.Cells[0].Value.ToString());
                foreach (DataRow dr in shoppingCart.Rows)
                {
                    if (dr[0].ToString() == dgvr.Cells[0].Value.ToString())
                    {
                        shoppingCart.Rows.Remove(dr);
                        break;
                    }
                }
                // get the item name from the selected row
                //string itemName = selectedRow.Cells["Item Name"].Value.ToString();
                //MessageBox.Show(itemName);
                // remove the item from the shopping cart
                //DataRow[] rowsToDelete = shoppingCart.Select($"Item Name = {itemName}");
                
                //MessageBox.Show(rowsToDelete.Length.ToString());
                //foreach (DataRow row in rowsToDelete)
                //{
                //    row.Delete();
                //}

                // update the subtotal and total
                UpdateSubtotalAndTotal();

                // refresh the DataGridView
                DGV_Total.Refresh();
            }
        }
    }
}
