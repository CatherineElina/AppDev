﻿namespace HW08_Catherine_0706022310009
{
    partial class UNIQME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MenuStrip_UNIQME = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DGV_Total = new System.Windows.Forms.DataGridView();
            this.lbl_SubTotal = new System.Windows.Forms.Label();
            this.lbl_Total = new System.Windows.Forms.Label();
            this.tb_SubTotal = new System.Windows.Forms.TextBox();
            this.tb_Total = new System.Windows.Forms.TextBox();
            this.panel_Tshirt = new System.Windows.Forms.Panel();
            this.btn_TshirtVneck = new System.Windows.Forms.Button();
            this.btn_TshirtAIRism = new System.Windows.Forms.Button();
            this.btn_TshirtKerah = new System.Windows.Forms.Button();
            this.lblVneckHarga = new System.Windows.Forms.Label();
            this.lbl_TshirtVneck = new System.Windows.Forms.Label();
            this.lbl_AIRismHarga = new System.Windows.Forms.Label();
            this.lbl_AirismTshirt = new System.Windows.Forms.Label();
            this.lbl_hargaKerahBulat = new System.Windows.Forms.Label();
            this.lbl_TshirtKerahBulat = new System.Windows.Forms.Label();
            this.PB_TshirtVNeck = new System.Windows.Forms.PictureBox();
            this.PB_TShirtKerahBulat = new System.Windows.Forms.PictureBox();
            this.PB_TshirtAIRism = new System.Windows.Forms.PictureBox();
            this.panel_Shirt = new System.Windows.Forms.Panel();
            this.btn_ShirtHugo = new System.Windows.Forms.Button();
            this.btn_ShirtZara = new System.Windows.Forms.Button();
            this.btn_ShirtRaph = new System.Windows.Forms.Button();
            this.lbl_HargaHugoShirt = new System.Windows.Forms.Label();
            this.lbl_HugoShirt = new System.Windows.Forms.Label();
            this.lbl_HargaZarashirt = new System.Windows.Forms.Label();
            this.lblShirtZara = new System.Windows.Forms.Label();
            this.lbl_HargaRaphShirt = new System.Windows.Forms.Label();
            this.lbl_ShirtRaph = new System.Windows.Forms.Label();
            this.PB_ShirtHugoBoss = new System.Windows.Forms.PictureBox();
            this.PB_RalphLaurenShirt = new System.Windows.Forms.PictureBox();
            this.PB_ShirtZara = new System.Windows.Forms.PictureBox();
            this.panel_Shoes = new System.Windows.Forms.Panel();
            this.btn_ShoesNike = new System.Windows.Forms.Button();
            this.btn_ShoesAdidas = new System.Windows.Forms.Button();
            this.btn_ShoesNB = new System.Windows.Forms.Button();
            this.lbl_HargaShoesNike = new System.Windows.Forms.Label();
            this.lbl_ShoesNike = new System.Windows.Forms.Label();
            this.lbl_HargaShoesAdidas = new System.Windows.Forms.Label();
            this.lbl_ShoesAdidas = new System.Windows.Forms.Label();
            this.lbl_HargaShoesNB = new System.Windows.Forms.Label();
            this.lbl_ShoesNewBalance = new System.Windows.Forms.Label();
            this.PB_ShoesNike = new System.Windows.Forms.PictureBox();
            this.PB_ShoesNewBalances = new System.Windows.Forms.PictureBox();
            this.PB_ShoesAdidas = new System.Windows.Forms.PictureBox();
            this.panel_longPants = new System.Windows.Forms.Panel();
            this.btn_LongTheory = new System.Windows.Forms.Button();
            this.btn_LongDKNY = new System.Windows.Forms.Button();
            this.btn_LongNike = new System.Windows.Forms.Button();
            this.lbl_HargaLongTheory = new System.Windows.Forms.Label();
            this.lbl_LongPantsTheory = new System.Windows.Forms.Label();
            this.lbl_HargaLongDKNY = new System.Windows.Forms.Label();
            this.lbl_LongPantsDKNY = new System.Windows.Forms.Label();
            this.lbl_HargaLongNike = new System.Windows.Forms.Label();
            this.lbl_LongPantsJeans = new System.Windows.Forms.Label();
            this.PB_LongTheory = new System.Windows.Forms.PictureBox();
            this.PB_LongNike = new System.Windows.Forms.PictureBox();
            this.PB_LongDKNY = new System.Windows.Forms.PictureBox();
            this.panel_jewelry = new System.Windows.Forms.Panel();
            this.btn_JewelChopard = new System.Windows.Forms.Button();
            this.btn_JewelBvlgari = new System.Windows.Forms.Button();
            this.btn_JewelCartier = new System.Windows.Forms.Button();
            this.lbl_HargaJewelChopard = new System.Windows.Forms.Label();
            this.lbl_JewelChopard = new System.Windows.Forms.Label();
            this.lbl_HargaJewelBvlgari = new System.Windows.Forms.Label();
            this.lbl_JewelBvlgari = new System.Windows.Forms.Label();
            this.lbl_HargaJewelCartier = new System.Windows.Forms.Label();
            this.lbl_JewelCartier = new System.Windows.Forms.Label();
            this.PB_JewelChopard = new System.Windows.Forms.PictureBox();
            this.PB_JewelCartier = new System.Windows.Forms.PictureBox();
            this.PB_JewelBvlgari = new System.Windows.Forms.PictureBox();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.btn_PantsLevis = new System.Windows.Forms.Button();
            this.btn_pantsCalvinKlein = new System.Windows.Forms.Button();
            this.btn_PantsHnM = new System.Windows.Forms.Button();
            this.lbl_HargaPantsLevis = new System.Windows.Forms.Label();
            this.lbl_Pantslevis = new System.Windows.Forms.Label();
            this.lbl_HargaPantsCalvin = new System.Windows.Forms.Label();
            this.lbl_PantsCalvinKlein = new System.Windows.Forms.Label();
            this.lbl_HargaPantshnm = new System.Windows.Forms.Label();
            this.lbl_PantsHnM = new System.Windows.Forms.Label();
            this.PB_PantsLevis = new System.Windows.Forms.PictureBox();
            this.PB_PantsHNM = new System.Windows.Forms.PictureBox();
            this.PB_PantsCalvinKlein = new System.Windows.Forms.PictureBox();
            this.panel_AddProduct = new System.Windows.Forms.Panel();
            this.tb_AddItemPrice = new System.Windows.Forms.TextBox();
            this.tb_AddNameItem = new System.Windows.Forms.TextBox();
            this.lbl_AddItemPrice = new System.Windows.Forms.Label();
            this.btn_Upload = new System.Windows.Forms.Button();
            this.btn_AddAddProduct = new System.Windows.Forms.Button();
            this.lbl_AddNameItem = new System.Windows.Forms.Label();
            this.lbl_UploadImage = new System.Windows.Forms.Label();
            this.PB_UploadImage = new System.Windows.Forms.PictureBox();
            this.btn_remove = new System.Windows.Forms.Button();
            this.MenuStrip_UNIQME.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Total)).BeginInit();
            this.panel_Tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_TshirtVNeck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_TShirtKerahBulat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_TshirtAIRism)).BeginInit();
            this.panel_Shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShirtHugoBoss)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_RalphLaurenShirt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShirtZara)).BeginInit();
            this.panel_Shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShoesNike)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShoesNewBalances)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShoesAdidas)).BeginInit();
            this.panel_longPants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_LongTheory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_LongNike)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_LongDKNY)).BeginInit();
            this.panel_jewelry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_JewelChopard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_JewelCartier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_JewelBvlgari)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PantsLevis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PantsHNM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PantsCalvinKlein)).BeginInit();
            this.panel_AddProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_UploadImage)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuStrip_UNIQME
            // 
            this.MenuStrip_UNIQME.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.MenuStrip_UNIQME.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.MenuStrip_UNIQME.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.MenuStrip_UNIQME.Location = new System.Drawing.Point(0, 0);
            this.MenuStrip_UNIQME.Name = "MenuStrip_UNIQME";
            this.MenuStrip_UNIQME.Size = new System.Drawing.Size(1114, 33);
            this.MenuStrip_UNIQME.TabIndex = 3;
            this.MenuStrip_UNIQME.Text = "menuStrip2";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(102, 29);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(133, 29);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(119, 29);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addProductToolStripMenuItem});
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.othersToolStripMenuItem.Text = "Others";
            // 
            // addProductToolStripMenuItem
            // 
            this.addProductToolStripMenuItem.Name = "addProductToolStripMenuItem";
            this.addProductToolStripMenuItem.Size = new System.Drawing.Size(215, 34);
            this.addProductToolStripMenuItem.Text = "Add Product";
            this.addProductToolStripMenuItem.Click += new System.EventHandler(this.addProductToolStripMenuItem_Click);
            // 
            // DGV_Total
            // 
            this.DGV_Total.AllowUserToAddRows = false;
            this.DGV_Total.AllowUserToDeleteRows = false;
            this.DGV_Total.AllowUserToResizeColumns = false;
            this.DGV_Total.AllowUserToResizeRows = false;
            this.DGV_Total.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Total.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.DGV_Total.Location = new System.Drawing.Point(482, 60);
            this.DGV_Total.Name = "DGV_Total";
            this.DGV_Total.RowHeadersWidth = 62;
            this.DGV_Total.RowTemplate.Height = 28;
            this.DGV_Total.Size = new System.Drawing.Size(605, 237);
            this.DGV_Total.TabIndex = 4;
            // 
            // lbl_SubTotal
            // 
            this.lbl_SubTotal.AutoSize = true;
            this.lbl_SubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SubTotal.Location = new System.Drawing.Point(515, 316);
            this.lbl_SubTotal.Name = "lbl_SubTotal";
            this.lbl_SubTotal.Size = new System.Drawing.Size(121, 26);
            this.lbl_SubTotal.TabIndex = 5;
            this.lbl_SubTotal.Text = "Sub-Total:";
            // 
            // lbl_Total
            // 
            this.lbl_Total.AutoSize = true;
            this.lbl_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total.Location = new System.Drawing.Point(556, 361);
            this.lbl_Total.Name = "lbl_Total";
            this.lbl_Total.Size = new System.Drawing.Size(80, 29);
            this.lbl_Total.TabIndex = 6;
            this.lbl_Total.Text = "Total:";
            // 
            // tb_SubTotal
            // 
            this.tb_SubTotal.Location = new System.Drawing.Point(642, 318);
            this.tb_SubTotal.Name = "tb_SubTotal";
            this.tb_SubTotal.Size = new System.Drawing.Size(149, 26);
            this.tb_SubTotal.TabIndex = 7;
            // 
            // tb_Total
            // 
            this.tb_Total.Location = new System.Drawing.Point(642, 365);
            this.tb_Total.Name = "tb_Total";
            this.tb_Total.Size = new System.Drawing.Size(149, 26);
            this.tb_Total.TabIndex = 8;
            // 
            // panel_Tshirt
            // 
            this.panel_Tshirt.Controls.Add(this.btn_TshirtVneck);
            this.panel_Tshirt.Controls.Add(this.btn_TshirtAIRism);
            this.panel_Tshirt.Controls.Add(this.btn_TshirtKerah);
            this.panel_Tshirt.Controls.Add(this.lblVneckHarga);
            this.panel_Tshirt.Controls.Add(this.lbl_TshirtVneck);
            this.panel_Tshirt.Controls.Add(this.lbl_AIRismHarga);
            this.panel_Tshirt.Controls.Add(this.lbl_AirismTshirt);
            this.panel_Tshirt.Controls.Add(this.lbl_hargaKerahBulat);
            this.panel_Tshirt.Controls.Add(this.lbl_TshirtKerahBulat);
            this.panel_Tshirt.Controls.Add(this.PB_TshirtVNeck);
            this.panel_Tshirt.Controls.Add(this.PB_TShirtKerahBulat);
            this.panel_Tshirt.Controls.Add(this.PB_TshirtAIRism);
            this.panel_Tshirt.Location = new System.Drawing.Point(3, 50);
            this.panel_Tshirt.Name = "panel_Tshirt";
            this.panel_Tshirt.Size = new System.Drawing.Size(476, 351);
            this.panel_Tshirt.TabIndex = 12;
            // 
            // btn_TshirtVneck
            // 
            this.btn_TshirtVneck.Location = new System.Drawing.Point(315, 276);
            this.btn_TshirtVneck.Name = "btn_TshirtVneck";
            this.btn_TshirtVneck.Size = new System.Drawing.Size(122, 32);
            this.btn_TshirtVneck.TabIndex = 20;
            this.btn_TshirtVneck.Text = "Add To Cart";
            this.btn_TshirtVneck.UseVisualStyleBackColor = true;
            this.btn_TshirtVneck.Click += new System.EventHandler(this.btn_TshirtVneck_Click);
            // 
            // btn_TshirtAIRism
            // 
            this.btn_TshirtAIRism.Location = new System.Drawing.Point(162, 276);
            this.btn_TshirtAIRism.Name = "btn_TshirtAIRism";
            this.btn_TshirtAIRism.Size = new System.Drawing.Size(122, 32);
            this.btn_TshirtAIRism.TabIndex = 19;
            this.btn_TshirtAIRism.Text = "Add To Cart";
            this.btn_TshirtAIRism.UseVisualStyleBackColor = true;
            this.btn_TshirtAIRism.Click += new System.EventHandler(this.btn_TshirtAIRism_Click);
            // 
            // btn_TshirtKerah
            // 
            this.btn_TshirtKerah.Location = new System.Drawing.Point(12, 276);
            this.btn_TshirtKerah.Name = "btn_TshirtKerah";
            this.btn_TshirtKerah.Size = new System.Drawing.Size(122, 32);
            this.btn_TshirtKerah.TabIndex = 18;
            this.btn_TshirtKerah.Text = "Add To Cart";
            this.btn_TshirtKerah.UseVisualStyleBackColor = true;
            this.btn_TshirtKerah.Click += new System.EventHandler(this.btn_TshirtKerah_Click);
            // 
            // lblVneckHarga
            // 
            this.lblVneckHarga.AutoSize = true;
            this.lblVneckHarga.Location = new System.Drawing.Point(311, 239);
            this.lblVneckHarga.Name = "lblVneckHarga";
            this.lblVneckHarga.Size = new System.Drawing.Size(105, 20);
            this.lblVneckHarga.TabIndex = 17;
            this.lblVneckHarga.Text = "Rp. 170.000,-";
            // 
            // lbl_TshirtVneck
            // 
            this.lbl_TshirtVneck.AutoSize = true;
            this.lbl_TshirtVneck.Location = new System.Drawing.Point(311, 209);
            this.lbl_TshirtVneck.Name = "lbl_TshirtVneck";
            this.lbl_TshirtVneck.Size = new System.Drawing.Size(107, 20);
            this.lbl_TshirtVneck.TabIndex = 16;
            this.lbl_TshirtVneck.Text = "T-Shirt VNeck";
            // 
            // lbl_AIRismHarga
            // 
            this.lbl_AIRismHarga.AutoSize = true;
            this.lbl_AIRismHarga.Location = new System.Drawing.Point(158, 239);
            this.lbl_AIRismHarga.Name = "lbl_AIRismHarga";
            this.lbl_AIRismHarga.Size = new System.Drawing.Size(105, 20);
            this.lbl_AIRismHarga.TabIndex = 15;
            this.lbl_AIRismHarga.Text = "Rp. 150.000,-";
            // 
            // lbl_AirismTshirt
            // 
            this.lbl_AirismTshirt.AutoSize = true;
            this.lbl_AirismTshirt.Location = new System.Drawing.Point(158, 209);
            this.lbl_AirismTshirt.Name = "lbl_AirismTshirt";
            this.lbl_AirismTshirt.Size = new System.Drawing.Size(112, 20);
            this.lbl_AirismTshirt.TabIndex = 14;
            this.lbl_AirismTshirt.Text = "AIRism T-Shirt";
            // 
            // lbl_hargaKerahBulat
            // 
            this.lbl_hargaKerahBulat.AutoSize = true;
            this.lbl_hargaKerahBulat.Location = new System.Drawing.Point(5, 239);
            this.lbl_hargaKerahBulat.Name = "lbl_hargaKerahBulat";
            this.lbl_hargaKerahBulat.Size = new System.Drawing.Size(105, 20);
            this.lbl_hargaKerahBulat.TabIndex = 13;
            this.lbl_hargaKerahBulat.Text = "Rp. 120.000,-";
            // 
            // lbl_TshirtKerahBulat
            // 
            this.lbl_TshirtKerahBulat.AutoSize = true;
            this.lbl_TshirtKerahBulat.Location = new System.Drawing.Point(5, 209);
            this.lbl_TshirtKerahBulat.Name = "lbl_TshirtKerahBulat";
            this.lbl_TshirtKerahBulat.Size = new System.Drawing.Size(143, 20);
            this.lbl_TshirtKerahBulat.TabIndex = 12;
            this.lbl_TshirtKerahBulat.Text = "T-Shirt Kerah Bulat";
            // 
            // PB_TshirtVNeck
            // 
            this.PB_TshirtVNeck.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Tshirt_Vneck;
            this.PB_TshirtVNeck.Location = new System.Drawing.Point(315, 12);
            this.PB_TshirtVNeck.Name = "PB_TshirtVNeck";
            this.PB_TshirtVNeck.Size = new System.Drawing.Size(147, 194);
            this.PB_TshirtVNeck.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_TshirtVNeck.TabIndex = 11;
            this.PB_TshirtVNeck.TabStop = false;
            // 
            // PB_TShirtKerahBulat
            // 
            this.PB_TShirtKerahBulat.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Tshirt_Kerah_Bulat;
            this.PB_TShirtKerahBulat.Location = new System.Drawing.Point(9, 12);
            this.PB_TShirtKerahBulat.Name = "PB_TShirtKerahBulat";
            this.PB_TShirtKerahBulat.Size = new System.Drawing.Size(147, 194);
            this.PB_TShirtKerahBulat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_TShirtKerahBulat.TabIndex = 9;
            this.PB_TShirtKerahBulat.TabStop = false;
            // 
            // PB_TshirtAIRism
            // 
            this.PB_TshirtAIRism.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Tshirt_airism;
            this.PB_TshirtAIRism.Location = new System.Drawing.Point(162, 12);
            this.PB_TshirtAIRism.Name = "PB_TshirtAIRism";
            this.PB_TshirtAIRism.Size = new System.Drawing.Size(147, 194);
            this.PB_TshirtAIRism.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_TshirtAIRism.TabIndex = 10;
            this.PB_TshirtAIRism.TabStop = false;
            // 
            // panel_Shirt
            // 
            this.panel_Shirt.Controls.Add(this.btn_ShirtHugo);
            this.panel_Shirt.Controls.Add(this.btn_ShirtZara);
            this.panel_Shirt.Controls.Add(this.btn_ShirtRaph);
            this.panel_Shirt.Controls.Add(this.lbl_HargaHugoShirt);
            this.panel_Shirt.Controls.Add(this.lbl_HugoShirt);
            this.panel_Shirt.Controls.Add(this.lbl_HargaZarashirt);
            this.panel_Shirt.Controls.Add(this.lblShirtZara);
            this.panel_Shirt.Controls.Add(this.lbl_HargaRaphShirt);
            this.panel_Shirt.Controls.Add(this.lbl_ShirtRaph);
            this.panel_Shirt.Controls.Add(this.PB_ShirtHugoBoss);
            this.panel_Shirt.Controls.Add(this.PB_RalphLaurenShirt);
            this.panel_Shirt.Controls.Add(this.PB_ShirtZara);
            this.panel_Shirt.Location = new System.Drawing.Point(3, 47);
            this.panel_Shirt.Name = "panel_Shirt";
            this.panel_Shirt.Size = new System.Drawing.Size(476, 351);
            this.panel_Shirt.TabIndex = 21;
            // 
            // btn_ShirtHugo
            // 
            this.btn_ShirtHugo.Location = new System.Drawing.Point(315, 276);
            this.btn_ShirtHugo.Name = "btn_ShirtHugo";
            this.btn_ShirtHugo.Size = new System.Drawing.Size(122, 32);
            this.btn_ShirtHugo.TabIndex = 20;
            this.btn_ShirtHugo.Text = "Add To Cart";
            this.btn_ShirtHugo.UseVisualStyleBackColor = true;
            this.btn_ShirtHugo.Click += new System.EventHandler(this.btn_ShirtHugo_Click);
            // 
            // btn_ShirtZara
            // 
            this.btn_ShirtZara.Location = new System.Drawing.Point(162, 276);
            this.btn_ShirtZara.Name = "btn_ShirtZara";
            this.btn_ShirtZara.Size = new System.Drawing.Size(122, 32);
            this.btn_ShirtZara.TabIndex = 19;
            this.btn_ShirtZara.Text = "Add To Cart";
            this.btn_ShirtZara.UseVisualStyleBackColor = true;
            this.btn_ShirtZara.Click += new System.EventHandler(this.btn_ShirtZara_Click);
            // 
            // btn_ShirtRaph
            // 
            this.btn_ShirtRaph.Location = new System.Drawing.Point(12, 276);
            this.btn_ShirtRaph.Name = "btn_ShirtRaph";
            this.btn_ShirtRaph.Size = new System.Drawing.Size(122, 32);
            this.btn_ShirtRaph.TabIndex = 18;
            this.btn_ShirtRaph.Text = "Add To Cart";
            this.btn_ShirtRaph.UseVisualStyleBackColor = true;
            this.btn_ShirtRaph.Click += new System.EventHandler(this.btn_ShirtRaph_Click);
            // 
            // lbl_HargaHugoShirt
            // 
            this.lbl_HargaHugoShirt.AutoSize = true;
            this.lbl_HargaHugoShirt.Location = new System.Drawing.Point(311, 239);
            this.lbl_HargaHugoShirt.Name = "lbl_HargaHugoShirt";
            this.lbl_HargaHugoShirt.Size = new System.Drawing.Size(105, 20);
            this.lbl_HargaHugoShirt.TabIndex = 17;
            this.lbl_HargaHugoShirt.Text = "Rp. 870.000,-";
            // 
            // lbl_HugoShirt
            // 
            this.lbl_HugoShirt.AutoSize = true;
            this.lbl_HugoShirt.Location = new System.Drawing.Point(311, 209);
            this.lbl_HugoShirt.Name = "lbl_HugoShirt";
            this.lbl_HugoShirt.Size = new System.Drawing.Size(125, 20);
            this.lbl_HugoShirt.TabIndex = 16;
            this.lbl_HugoShirt.Text = "Hugo Boss Shirt";
            // 
            // lbl_HargaZarashirt
            // 
            this.lbl_HargaZarashirt.AutoSize = true;
            this.lbl_HargaZarashirt.Location = new System.Drawing.Point(158, 239);
            this.lbl_HargaZarashirt.Name = "lbl_HargaZarashirt";
            this.lbl_HargaZarashirt.Size = new System.Drawing.Size(105, 20);
            this.lbl_HargaZarashirt.TabIndex = 15;
            this.lbl_HargaZarashirt.Text = "Rp. 350.000,-";
            // 
            // lblShirtZara
            // 
            this.lblShirtZara.AutoSize = true;
            this.lblShirtZara.Location = new System.Drawing.Point(158, 209);
            this.lblShirtZara.Name = "lblShirtZara";
            this.lblShirtZara.Size = new System.Drawing.Size(79, 20);
            this.lblShirtZara.TabIndex = 14;
            this.lblShirtZara.Text = "Zara Shirt";
            // 
            // lbl_HargaRaphShirt
            // 
            this.lbl_HargaRaphShirt.AutoSize = true;
            this.lbl_HargaRaphShirt.Location = new System.Drawing.Point(5, 239);
            this.lbl_HargaRaphShirt.Name = "lbl_HargaRaphShirt";
            this.lbl_HargaRaphShirt.Size = new System.Drawing.Size(105, 20);
            this.lbl_HargaRaphShirt.TabIndex = 13;
            this.lbl_HargaRaphShirt.Text = "Rp. 570.000,-";
            // 
            // lbl_ShirtRaph
            // 
            this.lbl_ShirtRaph.AutoSize = true;
            this.lbl_ShirtRaph.Location = new System.Drawing.Point(5, 209);
            this.lbl_ShirtRaph.Name = "lbl_ShirtRaph";
            this.lbl_ShirtRaph.Size = new System.Drawing.Size(142, 20);
            this.lbl_ShirtRaph.TabIndex = 12;
            this.lbl_ShirtRaph.Text = "Ralph Lauren Shirt";
            // 
            // PB_ShirtHugoBoss
            // 
            this.PB_ShirtHugoBoss.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Shirt_Hugo_Boss;
            this.PB_ShirtHugoBoss.Location = new System.Drawing.Point(315, 12);
            this.PB_ShirtHugoBoss.Name = "PB_ShirtHugoBoss";
            this.PB_ShirtHugoBoss.Size = new System.Drawing.Size(147, 194);
            this.PB_ShirtHugoBoss.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_ShirtHugoBoss.TabIndex = 11;
            this.PB_ShirtHugoBoss.TabStop = false;
            // 
            // PB_RalphLaurenShirt
            // 
            this.PB_RalphLaurenShirt.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Shirt_Ralph_Lauren;
            this.PB_RalphLaurenShirt.Location = new System.Drawing.Point(9, 12);
            this.PB_RalphLaurenShirt.Name = "PB_RalphLaurenShirt";
            this.PB_RalphLaurenShirt.Size = new System.Drawing.Size(147, 194);
            this.PB_RalphLaurenShirt.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_RalphLaurenShirt.TabIndex = 9;
            this.PB_RalphLaurenShirt.TabStop = false;
            // 
            // PB_ShirtZara
            // 
            this.PB_ShirtZara.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Shirt_Zara;
            this.PB_ShirtZara.Location = new System.Drawing.Point(162, 12);
            this.PB_ShirtZara.Name = "PB_ShirtZara";
            this.PB_ShirtZara.Size = new System.Drawing.Size(147, 194);
            this.PB_ShirtZara.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_ShirtZara.TabIndex = 10;
            this.PB_ShirtZara.TabStop = false;
            // 
            // panel_Shoes
            // 
            this.panel_Shoes.Controls.Add(this.btn_ShoesNike);
            this.panel_Shoes.Controls.Add(this.btn_ShoesAdidas);
            this.panel_Shoes.Controls.Add(this.btn_ShoesNB);
            this.panel_Shoes.Controls.Add(this.lbl_HargaShoesNike);
            this.panel_Shoes.Controls.Add(this.lbl_ShoesNike);
            this.panel_Shoes.Controls.Add(this.lbl_HargaShoesAdidas);
            this.panel_Shoes.Controls.Add(this.lbl_ShoesAdidas);
            this.panel_Shoes.Controls.Add(this.lbl_HargaShoesNB);
            this.panel_Shoes.Controls.Add(this.lbl_ShoesNewBalance);
            this.panel_Shoes.Controls.Add(this.PB_ShoesNike);
            this.panel_Shoes.Controls.Add(this.PB_ShoesNewBalances);
            this.panel_Shoes.Controls.Add(this.PB_ShoesAdidas);
            this.panel_Shoes.Location = new System.Drawing.Point(5, 47);
            this.panel_Shoes.Name = "panel_Shoes";
            this.panel_Shoes.Size = new System.Drawing.Size(476, 351);
            this.panel_Shoes.TabIndex = 24;
            // 
            // btn_ShoesNike
            // 
            this.btn_ShoesNike.Location = new System.Drawing.Point(315, 276);
            this.btn_ShoesNike.Name = "btn_ShoesNike";
            this.btn_ShoesNike.Size = new System.Drawing.Size(122, 32);
            this.btn_ShoesNike.TabIndex = 20;
            this.btn_ShoesNike.Text = "Add To Cart";
            this.btn_ShoesNike.UseVisualStyleBackColor = true;
            this.btn_ShoesNike.Click += new System.EventHandler(this.btn_ShoesNike_Click);
            // 
            // btn_ShoesAdidas
            // 
            this.btn_ShoesAdidas.Location = new System.Drawing.Point(162, 276);
            this.btn_ShoesAdidas.Name = "btn_ShoesAdidas";
            this.btn_ShoesAdidas.Size = new System.Drawing.Size(122, 32);
            this.btn_ShoesAdidas.TabIndex = 19;
            this.btn_ShoesAdidas.Text = "Add To Cart";
            this.btn_ShoesAdidas.UseVisualStyleBackColor = true;
            this.btn_ShoesAdidas.Click += new System.EventHandler(this.btn_ShoesAdidas_Click);
            // 
            // btn_ShoesNB
            // 
            this.btn_ShoesNB.Location = new System.Drawing.Point(12, 276);
            this.btn_ShoesNB.Name = "btn_ShoesNB";
            this.btn_ShoesNB.Size = new System.Drawing.Size(122, 32);
            this.btn_ShoesNB.TabIndex = 18;
            this.btn_ShoesNB.Text = "Add To Cart";
            this.btn_ShoesNB.UseVisualStyleBackColor = true;
            this.btn_ShoesNB.Click += new System.EventHandler(this.btn_ShoesNB_Click);
            // 
            // lbl_HargaShoesNike
            // 
            this.lbl_HargaShoesNike.AutoSize = true;
            this.lbl_HargaShoesNike.Location = new System.Drawing.Point(311, 239);
            this.lbl_HargaShoesNike.Name = "lbl_HargaShoesNike";
            this.lbl_HargaShoesNike.Size = new System.Drawing.Size(118, 20);
            this.lbl_HargaShoesNike.TabIndex = 17;
            this.lbl_HargaShoesNike.Text = "Rp. 1.650.000,-";
            // 
            // lbl_ShoesNike
            // 
            this.lbl_ShoesNike.AutoSize = true;
            this.lbl_ShoesNike.Location = new System.Drawing.Point(311, 209);
            this.lbl_ShoesNike.Name = "lbl_ShoesNike";
            this.lbl_ShoesNike.Size = new System.Drawing.Size(90, 20);
            this.lbl_ShoesNike.TabIndex = 16;
            this.lbl_ShoesNike.Text = "Nike Shoes";
            // 
            // lbl_HargaShoesAdidas
            // 
            this.lbl_HargaShoesAdidas.AutoSize = true;
            this.lbl_HargaShoesAdidas.Location = new System.Drawing.Point(158, 239);
            this.lbl_HargaShoesAdidas.Name = "lbl_HargaShoesAdidas";
            this.lbl_HargaShoesAdidas.Size = new System.Drawing.Size(118, 20);
            this.lbl_HargaShoesAdidas.TabIndex = 15;
            this.lbl_HargaShoesAdidas.Text = "Rp. 3.320.000,-";
            // 
            // lbl_ShoesAdidas
            // 
            this.lbl_ShoesAdidas.AutoSize = true;
            this.lbl_ShoesAdidas.Location = new System.Drawing.Point(158, 209);
            this.lbl_ShoesAdidas.Name = "lbl_ShoesAdidas";
            this.lbl_ShoesAdidas.Size = new System.Drawing.Size(108, 20);
            this.lbl_ShoesAdidas.TabIndex = 14;
            this.lbl_ShoesAdidas.Text = "Adidas Shoes";
            // 
            // lbl_HargaShoesNB
            // 
            this.lbl_HargaShoesNB.AutoSize = true;
            this.lbl_HargaShoesNB.Location = new System.Drawing.Point(5, 239);
            this.lbl_HargaShoesNB.Name = "lbl_HargaShoesNB";
            this.lbl_HargaShoesNB.Size = new System.Drawing.Size(118, 20);
            this.lbl_HargaShoesNB.TabIndex = 13;
            this.lbl_HargaShoesNB.Text = "Rp. 1.500.000,-";
            // 
            // lbl_ShoesNewBalance
            // 
            this.lbl_ShoesNewBalance.AutoSize = true;
            this.lbl_ShoesNewBalance.Location = new System.Drawing.Point(5, 209);
            this.lbl_ShoesNewBalance.Name = "lbl_ShoesNewBalance";
            this.lbl_ShoesNewBalance.Size = new System.Drawing.Size(152, 20);
            this.lbl_ShoesNewBalance.TabIndex = 12;
            this.lbl_ShoesNewBalance.Text = "New Balance Shoes";
            // 
            // PB_ShoesNike
            // 
            this.PB_ShoesNike.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Shoes_Nike;
            this.PB_ShoesNike.Location = new System.Drawing.Point(315, 12);
            this.PB_ShoesNike.Name = "PB_ShoesNike";
            this.PB_ShoesNike.Size = new System.Drawing.Size(147, 194);
            this.PB_ShoesNike.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_ShoesNike.TabIndex = 11;
            this.PB_ShoesNike.TabStop = false;
            // 
            // PB_ShoesNewBalances
            // 
            this.PB_ShoesNewBalances.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Shoes_New_Balance;
            this.PB_ShoesNewBalances.Location = new System.Drawing.Point(9, 12);
            this.PB_ShoesNewBalances.Name = "PB_ShoesNewBalances";
            this.PB_ShoesNewBalances.Size = new System.Drawing.Size(147, 194);
            this.PB_ShoesNewBalances.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_ShoesNewBalances.TabIndex = 9;
            this.PB_ShoesNewBalances.TabStop = false;
            // 
            // PB_ShoesAdidas
            // 
            this.PB_ShoesAdidas.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Shoes_Adidas;
            this.PB_ShoesAdidas.Location = new System.Drawing.Point(162, 12);
            this.PB_ShoesAdidas.Name = "PB_ShoesAdidas";
            this.PB_ShoesAdidas.Size = new System.Drawing.Size(147, 194);
            this.PB_ShoesAdidas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_ShoesAdidas.TabIndex = 10;
            this.PB_ShoesAdidas.TabStop = false;
            // 
            // panel_longPants
            // 
            this.panel_longPants.Controls.Add(this.btn_LongTheory);
            this.panel_longPants.Controls.Add(this.btn_LongDKNY);
            this.panel_longPants.Controls.Add(this.btn_LongNike);
            this.panel_longPants.Controls.Add(this.lbl_HargaLongTheory);
            this.panel_longPants.Controls.Add(this.lbl_LongPantsTheory);
            this.panel_longPants.Controls.Add(this.lbl_HargaLongDKNY);
            this.panel_longPants.Controls.Add(this.lbl_LongPantsDKNY);
            this.panel_longPants.Controls.Add(this.lbl_HargaLongNike);
            this.panel_longPants.Controls.Add(this.lbl_LongPantsJeans);
            this.panel_longPants.Controls.Add(this.PB_LongTheory);
            this.panel_longPants.Controls.Add(this.PB_LongNike);
            this.panel_longPants.Controls.Add(this.PB_LongDKNY);
            this.panel_longPants.Location = new System.Drawing.Point(6, 40);
            this.panel_longPants.Name = "panel_longPants";
            this.panel_longPants.Size = new System.Drawing.Size(476, 351);
            this.panel_longPants.TabIndex = 23;
            // 
            // btn_LongTheory
            // 
            this.btn_LongTheory.Location = new System.Drawing.Point(315, 276);
            this.btn_LongTheory.Name = "btn_LongTheory";
            this.btn_LongTheory.Size = new System.Drawing.Size(122, 32);
            this.btn_LongTheory.TabIndex = 20;
            this.btn_LongTheory.Text = "Add To Cart";
            this.btn_LongTheory.UseVisualStyleBackColor = true;
            this.btn_LongTheory.Click += new System.EventHandler(this.btn_LongTheory_Click);
            // 
            // btn_LongDKNY
            // 
            this.btn_LongDKNY.Location = new System.Drawing.Point(162, 276);
            this.btn_LongDKNY.Name = "btn_LongDKNY";
            this.btn_LongDKNY.Size = new System.Drawing.Size(122, 32);
            this.btn_LongDKNY.TabIndex = 19;
            this.btn_LongDKNY.Text = "Add To Cart";
            this.btn_LongDKNY.UseVisualStyleBackColor = true;
            this.btn_LongDKNY.Click += new System.EventHandler(this.btn_LongDKNY_Click);
            // 
            // btn_LongNike
            // 
            this.btn_LongNike.Location = new System.Drawing.Point(12, 276);
            this.btn_LongNike.Name = "btn_LongNike";
            this.btn_LongNike.Size = new System.Drawing.Size(122, 32);
            this.btn_LongNike.TabIndex = 18;
            this.btn_LongNike.Text = "Add To Cart";
            this.btn_LongNike.UseVisualStyleBackColor = true;
            this.btn_LongNike.Click += new System.EventHandler(this.btn_LongNike_Click);
            // 
            // lbl_HargaLongTheory
            // 
            this.lbl_HargaLongTheory.AutoSize = true;
            this.lbl_HargaLongTheory.Location = new System.Drawing.Point(311, 239);
            this.lbl_HargaLongTheory.Name = "lbl_HargaLongTheory";
            this.lbl_HargaLongTheory.Size = new System.Drawing.Size(105, 20);
            this.lbl_HargaLongTheory.TabIndex = 17;
            this.lbl_HargaLongTheory.Text = "Rp. 350.000,-";
            // 
            // lbl_LongPantsTheory
            // 
            this.lbl_LongPantsTheory.AutoSize = true;
            this.lbl_LongPantsTheory.Location = new System.Drawing.Point(311, 209);
            this.lbl_LongPantsTheory.Name = "lbl_LongPantsTheory";
            this.lbl_LongPantsTheory.Size = new System.Drawing.Size(142, 20);
            this.lbl_LongPantsTheory.TabIndex = 16;
            this.lbl_LongPantsTheory.Text = "Theory Long Pants";
            // 
            // lbl_HargaLongDKNY
            // 
            this.lbl_HargaLongDKNY.AutoSize = true;
            this.lbl_HargaLongDKNY.Location = new System.Drawing.Point(158, 239);
            this.lbl_HargaLongDKNY.Name = "lbl_HargaLongDKNY";
            this.lbl_HargaLongDKNY.Size = new System.Drawing.Size(105, 20);
            this.lbl_HargaLongDKNY.TabIndex = 15;
            this.lbl_HargaLongDKNY.Text = "Rp. 320.000,-";
            // 
            // lbl_LongPantsDKNY
            // 
            this.lbl_LongPantsDKNY.AutoSize = true;
            this.lbl_LongPantsDKNY.Location = new System.Drawing.Point(158, 209);
            this.lbl_LongPantsDKNY.Name = "lbl_LongPantsDKNY";
            this.lbl_LongPantsDKNY.Size = new System.Drawing.Size(138, 20);
            this.lbl_LongPantsDKNY.TabIndex = 14;
            this.lbl_LongPantsDKNY.Text = "DKNY Long Pants";
            // 
            // lbl_HargaLongNike
            // 
            this.lbl_HargaLongNike.AutoSize = true;
            this.lbl_HargaLongNike.Location = new System.Drawing.Point(5, 239);
            this.lbl_HargaLongNike.Name = "lbl_HargaLongNike";
            this.lbl_HargaLongNike.Size = new System.Drawing.Size(105, 20);
            this.lbl_HargaLongNike.TabIndex = 13;
            this.lbl_HargaLongNike.Text = "Rp. 200.000,-";
            // 
            // lbl_LongPantsJeans
            // 
            this.lbl_LongPantsJeans.AutoSize = true;
            this.lbl_LongPantsJeans.Location = new System.Drawing.Point(5, 209);
            this.lbl_LongPantsJeans.Name = "lbl_LongPantsJeans";
            this.lbl_LongPantsJeans.Size = new System.Drawing.Size(125, 20);
            this.lbl_LongPantsJeans.TabIndex = 12;
            this.lbl_LongPantsJeans.Text = "Nike Long Pants";
            // 
            // PB_LongTheory
            // 
            this.PB_LongTheory.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Long_Pants_Theory;
            this.PB_LongTheory.Location = new System.Drawing.Point(315, 12);
            this.PB_LongTheory.Name = "PB_LongTheory";
            this.PB_LongTheory.Size = new System.Drawing.Size(147, 194);
            this.PB_LongTheory.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_LongTheory.TabIndex = 11;
            this.PB_LongTheory.TabStop = false;
            // 
            // PB_LongNike
            // 
            this.PB_LongNike.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Long_Pants_Nike;
            this.PB_LongNike.Location = new System.Drawing.Point(9, 12);
            this.PB_LongNike.Name = "PB_LongNike";
            this.PB_LongNike.Size = new System.Drawing.Size(147, 194);
            this.PB_LongNike.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_LongNike.TabIndex = 9;
            this.PB_LongNike.TabStop = false;
            // 
            // PB_LongDKNY
            // 
            this.PB_LongDKNY.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Long_Pants_DKNY;
            this.PB_LongDKNY.Location = new System.Drawing.Point(162, 12);
            this.PB_LongDKNY.Name = "PB_LongDKNY";
            this.PB_LongDKNY.Size = new System.Drawing.Size(147, 194);
            this.PB_LongDKNY.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_LongDKNY.TabIndex = 10;
            this.PB_LongDKNY.TabStop = false;
            // 
            // panel_jewelry
            // 
            this.panel_jewelry.Controls.Add(this.btn_JewelChopard);
            this.panel_jewelry.Controls.Add(this.btn_JewelBvlgari);
            this.panel_jewelry.Controls.Add(this.btn_JewelCartier);
            this.panel_jewelry.Controls.Add(this.lbl_HargaJewelChopard);
            this.panel_jewelry.Controls.Add(this.lbl_JewelChopard);
            this.panel_jewelry.Controls.Add(this.lbl_HargaJewelBvlgari);
            this.panel_jewelry.Controls.Add(this.lbl_JewelBvlgari);
            this.panel_jewelry.Controls.Add(this.lbl_HargaJewelCartier);
            this.panel_jewelry.Controls.Add(this.lbl_JewelCartier);
            this.panel_jewelry.Controls.Add(this.PB_JewelChopard);
            this.panel_jewelry.Controls.Add(this.PB_JewelCartier);
            this.panel_jewelry.Controls.Add(this.PB_JewelBvlgari);
            this.panel_jewelry.Location = new System.Drawing.Point(3, 44);
            this.panel_jewelry.Name = "panel_jewelry";
            this.panel_jewelry.Size = new System.Drawing.Size(476, 351);
            this.panel_jewelry.TabIndex = 25;
            // 
            // btn_JewelChopard
            // 
            this.btn_JewelChopard.Location = new System.Drawing.Point(315, 276);
            this.btn_JewelChopard.Name = "btn_JewelChopard";
            this.btn_JewelChopard.Size = new System.Drawing.Size(122, 32);
            this.btn_JewelChopard.TabIndex = 20;
            this.btn_JewelChopard.Text = "Add To Cart";
            this.btn_JewelChopard.UseVisualStyleBackColor = true;
            this.btn_JewelChopard.Click += new System.EventHandler(this.btn_JewelChopard_Click);
            // 
            // btn_JewelBvlgari
            // 
            this.btn_JewelBvlgari.Location = new System.Drawing.Point(162, 276);
            this.btn_JewelBvlgari.Name = "btn_JewelBvlgari";
            this.btn_JewelBvlgari.Size = new System.Drawing.Size(122, 32);
            this.btn_JewelBvlgari.TabIndex = 19;
            this.btn_JewelBvlgari.Text = "Add To Cart";
            this.btn_JewelBvlgari.UseVisualStyleBackColor = true;
            this.btn_JewelBvlgari.Click += new System.EventHandler(this.btn_JewelBvlgari_Click);
            // 
            // btn_JewelCartier
            // 
            this.btn_JewelCartier.Location = new System.Drawing.Point(12, 276);
            this.btn_JewelCartier.Name = "btn_JewelCartier";
            this.btn_JewelCartier.Size = new System.Drawing.Size(122, 32);
            this.btn_JewelCartier.TabIndex = 18;
            this.btn_JewelCartier.Text = "Add To Cart";
            this.btn_JewelCartier.UseVisualStyleBackColor = true;
            this.btn_JewelCartier.Click += new System.EventHandler(this.btn_JewelCartier_Click);
            // 
            // lbl_HargaJewelChopard
            // 
            this.lbl_HargaJewelChopard.AutoSize = true;
            this.lbl_HargaJewelChopard.Location = new System.Drawing.Point(311, 239);
            this.lbl_HargaJewelChopard.Name = "lbl_HargaJewelChopard";
            this.lbl_HargaJewelChopard.Size = new System.Drawing.Size(118, 20);
            this.lbl_HargaJewelChopard.TabIndex = 17;
            this.lbl_HargaJewelChopard.Text = "Rp. 5.650.000,-";
            // 
            // lbl_JewelChopard
            // 
            this.lbl_JewelChopard.AutoSize = true;
            this.lbl_JewelChopard.Location = new System.Drawing.Point(311, 209);
            this.lbl_JewelChopard.Name = "lbl_JewelChopard";
            this.lbl_JewelChopard.Size = new System.Drawing.Size(133, 20);
            this.lbl_JewelChopard.TabIndex = 16;
            this.lbl_JewelChopard.Text = "Chopard Earrings";
            // 
            // lbl_HargaJewelBvlgari
            // 
            this.lbl_HargaJewelBvlgari.AutoSize = true;
            this.lbl_HargaJewelBvlgari.Location = new System.Drawing.Point(158, 239);
            this.lbl_HargaJewelBvlgari.Name = "lbl_HargaJewelBvlgari";
            this.lbl_HargaJewelBvlgari.Size = new System.Drawing.Size(118, 20);
            this.lbl_HargaJewelBvlgari.TabIndex = 15;
            this.lbl_HargaJewelBvlgari.Text = "Rp. 7.320.000,-";
            // 
            // lbl_JewelBvlgari
            // 
            this.lbl_JewelBvlgari.AutoSize = true;
            this.lbl_JewelBvlgari.Location = new System.Drawing.Point(158, 209);
            this.lbl_JewelBvlgari.Name = "lbl_JewelBvlgari";
            this.lbl_JewelBvlgari.Size = new System.Drawing.Size(93, 20);
            this.lbl_JewelBvlgari.TabIndex = 14;
            this.lbl_JewelBvlgari.Text = "Bvlgari Ring";
            // 
            // lbl_HargaJewelCartier
            // 
            this.lbl_HargaJewelCartier.AutoSize = true;
            this.lbl_HargaJewelCartier.Location = new System.Drawing.Point(5, 239);
            this.lbl_HargaJewelCartier.Name = "lbl_HargaJewelCartier";
            this.lbl_HargaJewelCartier.Size = new System.Drawing.Size(127, 20);
            this.lbl_HargaJewelCartier.TabIndex = 13;
            this.lbl_HargaJewelCartier.Text = "Rp. 10.500.000,-";
            // 
            // lbl_JewelCartier
            // 
            this.lbl_JewelCartier.AutoSize = true;
            this.lbl_JewelCartier.Location = new System.Drawing.Point(5, 209);
            this.lbl_JewelCartier.Name = "lbl_JewelCartier";
            this.lbl_JewelCartier.Size = new System.Drawing.Size(119, 20);
            this.lbl_JewelCartier.TabIndex = 12;
            this.lbl_JewelCartier.Text = "Cartier Bracelet";
            // 
            // PB_JewelChopard
            // 
            this.PB_JewelChopard.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Jewel_Chopard;
            this.PB_JewelChopard.Location = new System.Drawing.Point(315, 12);
            this.PB_JewelChopard.Name = "PB_JewelChopard";
            this.PB_JewelChopard.Size = new System.Drawing.Size(147, 194);
            this.PB_JewelChopard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_JewelChopard.TabIndex = 11;
            this.PB_JewelChopard.TabStop = false;
            // 
            // PB_JewelCartier
            // 
            this.PB_JewelCartier.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Jewel_Cartier;
            this.PB_JewelCartier.Location = new System.Drawing.Point(9, 12);
            this.PB_JewelCartier.Name = "PB_JewelCartier";
            this.PB_JewelCartier.Size = new System.Drawing.Size(147, 194);
            this.PB_JewelCartier.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_JewelCartier.TabIndex = 9;
            this.PB_JewelCartier.TabStop = false;
            // 
            // PB_JewelBvlgari
            // 
            this.PB_JewelBvlgari.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Jewel_Bvlgari;
            this.PB_JewelBvlgari.Location = new System.Drawing.Point(162, 12);
            this.PB_JewelBvlgari.Name = "PB_JewelBvlgari";
            this.PB_JewelBvlgari.Size = new System.Drawing.Size(147, 194);
            this.PB_JewelBvlgari.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_JewelBvlgari.TabIndex = 10;
            this.PB_JewelBvlgari.TabStop = false;
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.btn_PantsLevis);
            this.panel_pants.Controls.Add(this.btn_pantsCalvinKlein);
            this.panel_pants.Controls.Add(this.btn_PantsHnM);
            this.panel_pants.Controls.Add(this.lbl_HargaPantsLevis);
            this.panel_pants.Controls.Add(this.lbl_Pantslevis);
            this.panel_pants.Controls.Add(this.lbl_HargaPantsCalvin);
            this.panel_pants.Controls.Add(this.lbl_PantsCalvinKlein);
            this.panel_pants.Controls.Add(this.lbl_HargaPantshnm);
            this.panel_pants.Controls.Add(this.lbl_PantsHnM);
            this.panel_pants.Controls.Add(this.PB_PantsLevis);
            this.panel_pants.Controls.Add(this.PB_PantsHNM);
            this.panel_pants.Controls.Add(this.PB_PantsCalvinKlein);
            this.panel_pants.Location = new System.Drawing.Point(3, 50);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(476, 351);
            this.panel_pants.TabIndex = 22;
            // 
            // btn_PantsLevis
            // 
            this.btn_PantsLevis.Location = new System.Drawing.Point(315, 276);
            this.btn_PantsLevis.Name = "btn_PantsLevis";
            this.btn_PantsLevis.Size = new System.Drawing.Size(122, 32);
            this.btn_PantsLevis.TabIndex = 20;
            this.btn_PantsLevis.Text = "Add To Cart";
            this.btn_PantsLevis.UseVisualStyleBackColor = true;
            this.btn_PantsLevis.Click += new System.EventHandler(this.btn_PantsLevis_Click);
            // 
            // btn_pantsCalvinKlein
            // 
            this.btn_pantsCalvinKlein.Location = new System.Drawing.Point(162, 276);
            this.btn_pantsCalvinKlein.Name = "btn_pantsCalvinKlein";
            this.btn_pantsCalvinKlein.Size = new System.Drawing.Size(122, 32);
            this.btn_pantsCalvinKlein.TabIndex = 19;
            this.btn_pantsCalvinKlein.Text = "Add To Cart";
            this.btn_pantsCalvinKlein.UseVisualStyleBackColor = true;
            this.btn_pantsCalvinKlein.Click += new System.EventHandler(this.btn_pantsCalvinKlein_Click);
            // 
            // btn_PantsHnM
            // 
            this.btn_PantsHnM.Location = new System.Drawing.Point(12, 276);
            this.btn_PantsHnM.Name = "btn_PantsHnM";
            this.btn_PantsHnM.Size = new System.Drawing.Size(122, 32);
            this.btn_PantsHnM.TabIndex = 18;
            this.btn_PantsHnM.Text = "Add To Cart";
            this.btn_PantsHnM.UseVisualStyleBackColor = true;
            this.btn_PantsHnM.Click += new System.EventHandler(this.btn_PantsHnM_Click);
            // 
            // lbl_HargaPantsLevis
            // 
            this.lbl_HargaPantsLevis.AutoSize = true;
            this.lbl_HargaPantsLevis.Location = new System.Drawing.Point(311, 239);
            this.lbl_HargaPantsLevis.Name = "lbl_HargaPantsLevis";
            this.lbl_HargaPantsLevis.Size = new System.Drawing.Size(105, 20);
            this.lbl_HargaPantsLevis.TabIndex = 17;
            this.lbl_HargaPantsLevis.Text = "Rp. 350.000,-";
            // 
            // lbl_Pantslevis
            // 
            this.lbl_Pantslevis.AutoSize = true;
            this.lbl_Pantslevis.Location = new System.Drawing.Point(311, 209);
            this.lbl_Pantslevis.Name = "lbl_Pantslevis";
            this.lbl_Pantslevis.Size = new System.Drawing.Size(93, 20);
            this.lbl_Pantslevis.TabIndex = 16;
            this.lbl_Pantslevis.Text = "Levi\'s Pants";
            // 
            // lbl_HargaPantsCalvin
            // 
            this.lbl_HargaPantsCalvin.AutoSize = true;
            this.lbl_HargaPantsCalvin.Location = new System.Drawing.Point(158, 239);
            this.lbl_HargaPantsCalvin.Name = "lbl_HargaPantsCalvin";
            this.lbl_HargaPantsCalvin.Size = new System.Drawing.Size(105, 20);
            this.lbl_HargaPantsCalvin.TabIndex = 15;
            this.lbl_HargaPantsCalvin.Text = "Rp. 900.000,-";
            // 
            // lbl_PantsCalvinKlein
            // 
            this.lbl_PantsCalvinKlein.AutoSize = true;
            this.lbl_PantsCalvinKlein.Location = new System.Drawing.Point(158, 209);
            this.lbl_PantsCalvinKlein.Name = "lbl_PantsCalvinKlein";
            this.lbl_PantsCalvinKlein.Size = new System.Drawing.Size(134, 20);
            this.lbl_PantsCalvinKlein.TabIndex = 14;
            this.lbl_PantsCalvinKlein.Text = "Calvin Klein Pants";
            // 
            // lbl_HargaPantshnm
            // 
            this.lbl_HargaPantshnm.AutoSize = true;
            this.lbl_HargaPantshnm.Location = new System.Drawing.Point(5, 239);
            this.lbl_HargaPantshnm.Name = "lbl_HargaPantshnm";
            this.lbl_HargaPantshnm.Size = new System.Drawing.Size(105, 20);
            this.lbl_HargaPantshnm.TabIndex = 13;
            this.lbl_HargaPantshnm.Text = "Rp. 400.000,-";
            // 
            // lbl_PantsHnM
            // 
            this.lbl_PantsHnM.AutoSize = true;
            this.lbl_PantsHnM.Location = new System.Drawing.Point(5, 209);
            this.lbl_PantsHnM.Name = "lbl_PantsHnM";
            this.lbl_PantsHnM.Size = new System.Drawing.Size(88, 20);
            this.lbl_PantsHnM.TabIndex = 12;
            this.lbl_PantsHnM.Text = "HnM Pants";
            // 
            // PB_PantsLevis
            // 
            this.PB_PantsLevis.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Pants_Levi_s;
            this.PB_PantsLevis.Location = new System.Drawing.Point(315, 12);
            this.PB_PantsLevis.Name = "PB_PantsLevis";
            this.PB_PantsLevis.Size = new System.Drawing.Size(147, 194);
            this.PB_PantsLevis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_PantsLevis.TabIndex = 11;
            this.PB_PantsLevis.TabStop = false;
            // 
            // PB_PantsHNM
            // 
            this.PB_PantsHNM.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Pants_HnM;
            this.PB_PantsHNM.Location = new System.Drawing.Point(9, 12);
            this.PB_PantsHNM.Name = "PB_PantsHNM";
            this.PB_PantsHNM.Size = new System.Drawing.Size(147, 194);
            this.PB_PantsHNM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_PantsHNM.TabIndex = 9;
            this.PB_PantsHNM.TabStop = false;
            // 
            // PB_PantsCalvinKlein
            // 
            this.PB_PantsCalvinKlein.Image = global::HW08_Catherine_0706022310009.Properties.Resources.Pants_Calvin_Klein;
            this.PB_PantsCalvinKlein.Location = new System.Drawing.Point(162, 12);
            this.PB_PantsCalvinKlein.Name = "PB_PantsCalvinKlein";
            this.PB_PantsCalvinKlein.Size = new System.Drawing.Size(147, 194);
            this.PB_PantsCalvinKlein.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_PantsCalvinKlein.TabIndex = 10;
            this.PB_PantsCalvinKlein.TabStop = false;
            // 
            // panel_AddProduct
            // 
            this.panel_AddProduct.Controls.Add(this.tb_AddItemPrice);
            this.panel_AddProduct.Controls.Add(this.tb_AddNameItem);
            this.panel_AddProduct.Controls.Add(this.lbl_AddItemPrice);
            this.panel_AddProduct.Controls.Add(this.btn_Upload);
            this.panel_AddProduct.Controls.Add(this.btn_AddAddProduct);
            this.panel_AddProduct.Controls.Add(this.lbl_AddNameItem);
            this.panel_AddProduct.Controls.Add(this.lbl_UploadImage);
            this.panel_AddProduct.Controls.Add(this.PB_UploadImage);
            this.panel_AddProduct.Location = new System.Drawing.Point(2, 40);
            this.panel_AddProduct.Name = "panel_AddProduct";
            this.panel_AddProduct.Size = new System.Drawing.Size(476, 351);
            this.panel_AddProduct.TabIndex = 26;
            // 
            // tb_AddItemPrice
            // 
            this.tb_AddItemPrice.Location = new System.Drawing.Point(226, 212);
            this.tb_AddItemPrice.Name = "tb_AddItemPrice";
            this.tb_AddItemPrice.Size = new System.Drawing.Size(157, 26);
            this.tb_AddItemPrice.TabIndex = 22;
            this.tb_AddItemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_AddItemPrice_KeyPress_1);
            // 
            // tb_AddNameItem
            // 
            this.tb_AddNameItem.Location = new System.Drawing.Point(226, 116);
            this.tb_AddNameItem.Name = "tb_AddNameItem";
            this.tb_AddNameItem.Size = new System.Drawing.Size(157, 26);
            this.tb_AddNameItem.TabIndex = 21;
            // 
            // lbl_AddItemPrice
            // 
            this.lbl_AddItemPrice.AutoSize = true;
            this.lbl_AddItemPrice.Location = new System.Drawing.Point(222, 172);
            this.lbl_AddItemPrice.Name = "lbl_AddItemPrice";
            this.lbl_AddItemPrice.Size = new System.Drawing.Size(88, 20);
            this.lbl_AddItemPrice.TabIndex = 20;
            this.lbl_AddItemPrice.Text = "Item Price: ";
            // 
            // btn_Upload
            // 
            this.btn_Upload.Location = new System.Drawing.Point(205, 12);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(122, 32);
            this.btn_Upload.TabIndex = 19;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.UseVisualStyleBackColor = true;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // btn_AddAddProduct
            // 
            this.btn_AddAddProduct.Location = new System.Drawing.Point(340, 262);
            this.btn_AddAddProduct.Name = "btn_AddAddProduct";
            this.btn_AddAddProduct.Size = new System.Drawing.Size(122, 32);
            this.btn_AddAddProduct.TabIndex = 18;
            this.btn_AddAddProduct.Text = "Add To Cart";
            this.btn_AddAddProduct.UseVisualStyleBackColor = true;
            this.btn_AddAddProduct.Click += new System.EventHandler(this.btn_AddAddProduct_Click);
            // 
            // lbl_AddNameItem
            // 
            this.lbl_AddNameItem.AutoSize = true;
            this.lbl_AddNameItem.Location = new System.Drawing.Point(222, 82);
            this.lbl_AddNameItem.Name = "lbl_AddNameItem";
            this.lbl_AddNameItem.Size = new System.Drawing.Size(95, 20);
            this.lbl_AddNameItem.TabIndex = 13;
            this.lbl_AddNameItem.Text = "Name Item: ";
            // 
            // lbl_UploadImage
            // 
            this.lbl_UploadImage.AutoSize = true;
            this.lbl_UploadImage.Location = new System.Drawing.Point(65, 18);
            this.lbl_UploadImage.Name = "lbl_UploadImage";
            this.lbl_UploadImage.Size = new System.Drawing.Size(109, 20);
            this.lbl_UploadImage.TabIndex = 12;
            this.lbl_UploadImage.Text = "Upload Image";
            // 
            // PB_UploadImage
            // 
            this.PB_UploadImage.Location = new System.Drawing.Point(69, 52);
            this.PB_UploadImage.Name = "PB_UploadImage";
            this.PB_UploadImage.Size = new System.Drawing.Size(147, 194);
            this.PB_UploadImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_UploadImage.TabIndex = 9;
            this.PB_UploadImage.TabStop = false;
            // 
            // btn_remove
            // 
            this.btn_remove.Location = new System.Drawing.Point(548, 442);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(88, 39);
            this.btn_remove.TabIndex = 27;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = true;
            this.btn_remove.Click += new System.EventHandler(this.btn_remove_Click);
            // 
            // UNIQME
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1114, 797);
            this.Controls.Add(this.btn_remove);
            this.Controls.Add(this.panel_jewelry);
            this.Controls.Add(this.panel_Shirt);
            this.Controls.Add(this.panel_longPants);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_Shoes);
            this.Controls.Add(this.panel_AddProduct);
            this.Controls.Add(this.panel_Tshirt);
            this.Controls.Add(this.tb_Total);
            this.Controls.Add(this.tb_SubTotal);
            this.Controls.Add(this.lbl_Total);
            this.Controls.Add(this.lbl_SubTotal);
            this.Controls.Add(this.DGV_Total);
            this.Controls.Add(this.MenuStrip_UNIQME);
            this.Name = "UNIQME";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.UNIQME_Load);
            this.MenuStrip_UNIQME.ResumeLayout(false);
            this.MenuStrip_UNIQME.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Total)).EndInit();
            this.panel_Tshirt.ResumeLayout(false);
            this.panel_Tshirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_TshirtVNeck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_TShirtKerahBulat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_TshirtAIRism)).EndInit();
            this.panel_Shirt.ResumeLayout(false);
            this.panel_Shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShirtHugoBoss)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_RalphLaurenShirt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShirtZara)).EndInit();
            this.panel_Shoes.ResumeLayout(false);
            this.panel_Shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShoesNike)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShoesNewBalances)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_ShoesAdidas)).EndInit();
            this.panel_longPants.ResumeLayout(false);
            this.panel_longPants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_LongTheory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_LongNike)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_LongDKNY)).EndInit();
            this.panel_jewelry.ResumeLayout(false);
            this.panel_jewelry.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_JewelChopard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_JewelCartier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_JewelBvlgari)).EndInit();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PantsLevis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PantsHNM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PB_PantsCalvinKlein)).EndInit();
            this.panel_AddProduct.ResumeLayout(false);
            this.panel_AddProduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_UploadImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip MenuStrip_UNIQME;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addProductToolStripMenuItem;
        private System.Windows.Forms.DataGridView DGV_Total;
        private System.Windows.Forms.Label lbl_SubTotal;
        private System.Windows.Forms.Label lbl_Total;
        private System.Windows.Forms.TextBox tb_SubTotal;
        private System.Windows.Forms.TextBox tb_Total;
        private System.Windows.Forms.PictureBox PB_TShirtKerahBulat;
        private System.Windows.Forms.PictureBox PB_TshirtAIRism;
        private System.Windows.Forms.PictureBox PB_TshirtVNeck;
        private System.Windows.Forms.Panel panel_Tshirt;
        private System.Windows.Forms.Label lbl_hargaKerahBulat;
        private System.Windows.Forms.Label lbl_TshirtKerahBulat;
        private System.Windows.Forms.Label lblVneckHarga;
        private System.Windows.Forms.Label lbl_TshirtVneck;
        private System.Windows.Forms.Label lbl_AIRismHarga;
        private System.Windows.Forms.Label lbl_AirismTshirt;
        private System.Windows.Forms.Button btn_TshirtKerah;
        private System.Windows.Forms.Button btn_TshirtVneck;
        private System.Windows.Forms.Button btn_TshirtAIRism;
        private System.Windows.Forms.Panel panel_Shirt;
        private System.Windows.Forms.Button btn_ShirtHugo;
        private System.Windows.Forms.Button btn_ShirtZara;
        private System.Windows.Forms.Button btn_ShirtRaph;
        private System.Windows.Forms.Label lbl_HargaHugoShirt;
        private System.Windows.Forms.Label lbl_HugoShirt;
        private System.Windows.Forms.Label lbl_HargaZarashirt;
        private System.Windows.Forms.Label lblShirtZara;
        private System.Windows.Forms.Label lbl_HargaRaphShirt;
        private System.Windows.Forms.Label lbl_ShirtRaph;
        private System.Windows.Forms.PictureBox PB_ShirtHugoBoss;
        private System.Windows.Forms.PictureBox PB_RalphLaurenShirt;
        private System.Windows.Forms.PictureBox PB_ShirtZara;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button btn_PantsLevis;
        private System.Windows.Forms.Button btn_pantsCalvinKlein;
        private System.Windows.Forms.Button btn_PantsHnM;
        private System.Windows.Forms.Label lbl_HargaPantsLevis;
        private System.Windows.Forms.Label lbl_Pantslevis;
        private System.Windows.Forms.Label lbl_HargaPantsCalvin;
        private System.Windows.Forms.Label lbl_PantsCalvinKlein;
        private System.Windows.Forms.Label lbl_HargaPantshnm;
        private System.Windows.Forms.Label lbl_PantsHnM;
        private System.Windows.Forms.PictureBox PB_PantsLevis;
        private System.Windows.Forms.PictureBox PB_PantsHNM;
        private System.Windows.Forms.PictureBox PB_PantsCalvinKlein;
        private System.Windows.Forms.Panel panel_longPants;
        private System.Windows.Forms.Button btn_LongTheory;
        private System.Windows.Forms.Button btn_LongDKNY;
        private System.Windows.Forms.Button btn_LongNike;
        private System.Windows.Forms.Label lbl_HargaLongTheory;
        private System.Windows.Forms.Label lbl_LongPantsTheory;
        private System.Windows.Forms.Label lbl_HargaLongDKNY;
        private System.Windows.Forms.Label lbl_LongPantsDKNY;
        private System.Windows.Forms.Label lbl_HargaLongNike;
        private System.Windows.Forms.Label lbl_LongPantsJeans;
        private System.Windows.Forms.PictureBox PB_LongTheory;
        private System.Windows.Forms.PictureBox PB_LongNike;
        private System.Windows.Forms.PictureBox PB_LongDKNY;
        private System.Windows.Forms.Panel panel_Shoes;
        private System.Windows.Forms.Button btn_ShoesNike;
        private System.Windows.Forms.Button btn_ShoesAdidas;
        private System.Windows.Forms.Button btn_ShoesNB;
        private System.Windows.Forms.Label lbl_HargaShoesNike;
        private System.Windows.Forms.Label lbl_ShoesNike;
        private System.Windows.Forms.Label lbl_HargaShoesAdidas;
        private System.Windows.Forms.Label lbl_ShoesAdidas;
        private System.Windows.Forms.Label lbl_HargaShoesNB;
        private System.Windows.Forms.Label lbl_ShoesNewBalance;
        private System.Windows.Forms.PictureBox PB_ShoesNike;
        private System.Windows.Forms.PictureBox PB_ShoesNewBalances;
        private System.Windows.Forms.PictureBox PB_ShoesAdidas;
        private System.Windows.Forms.Panel panel_jewelry;
        private System.Windows.Forms.Button btn_JewelChopard;
        private System.Windows.Forms.Button btn_JewelBvlgari;
        private System.Windows.Forms.Button btn_JewelCartier;
        private System.Windows.Forms.Label lbl_HargaJewelChopard;
        private System.Windows.Forms.Label lbl_JewelChopard;
        private System.Windows.Forms.Label lbl_HargaJewelBvlgari;
        private System.Windows.Forms.Label lbl_JewelBvlgari;
        private System.Windows.Forms.Label lbl_HargaJewelCartier;
        private System.Windows.Forms.Label lbl_JewelCartier;
        private System.Windows.Forms.PictureBox PB_JewelChopard;
        private System.Windows.Forms.PictureBox PB_JewelCartier;
        private System.Windows.Forms.PictureBox PB_JewelBvlgari;
        private System.Windows.Forms.Panel panel_AddProduct;
        private System.Windows.Forms.Button btn_Upload;
        private System.Windows.Forms.Button btn_AddAddProduct;
        private System.Windows.Forms.Label lbl_AddNameItem;
        private System.Windows.Forms.Label lbl_UploadImage;
        private System.Windows.Forms.PictureBox PB_UploadImage;
        private System.Windows.Forms.Label lbl_AddItemPrice;
        private System.Windows.Forms.TextBox tb_AddItemPrice;
        private System.Windows.Forms.TextBox tb_AddNameItem;
        private System.Windows.Forms.Button btn_remove;
    }
}

